// Copyright 2012 Google Inc. All rights reserved.

(function() {

    var data = {
        "resource": {
            "version": "1",

            "macros": [{
                "function": "__u",
                "vtp_component": "URL",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "HOST",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "PATH",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__f",
                "vtp_component": "URL"
            }, {
                "function": "__e"
            }],
            "tags": [],
            "predicates": [],
            "rules": []
        },
        "runtime": [
            [50, "__e", [46, "a"],
                [36, [13, [41, "$0"],
                    [3, "$0", ["require", "internal.getEventData"]],
                    ["$0", "event"]
                ]]
            ],
            [50, "__f", [46, "a"],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "getReferrerUrl"]],
                [52, "d", ["require", "makeString"]],
                [52, "e", ["require", "parseUrl"]],
                [52, "f", [15, "__module_legacyUrls"]],
                [52, "g", [30, ["b", "gtm.referrer", 1],
                    ["c"]
                ]],
                [22, [28, [15, "g"]],
                    [46, [36, ["d", [15, "g"]]]]
                ],
                [38, [17, [15, "a"], "component"],
                    [46, "PROTOCOL", "HOST", "PORT", "PATH", "QUERY", "FRAGMENT", "URL"],
                    [46, [5, [46, [36, [2, [15, "f"], "B", [7, [15, "g"]]]]]],
                        [5, [46, [36, [2, [15, "f"], "C", [7, [15, "g"],
                            [17, [15, "a"], "stripWww"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "f"], "D", [7, [15, "g"]]]]]],
                        [5, [46, [36, [2, [15, "f"], "E", [7, [15, "g"],
                            [17, [15, "a"], "defaultPages"]
                        ]]]]],
                        [5, [46, [22, [17, [15, "a"], "queryKey"],
                                [46, [53, [36, [2, [15, "f"], "H", [7, [15, "g"],
                                    [17, [15, "a"], "queryKey"]
                                ]]]]]
                            ],
                            [52, "h", ["e", [15, "g"]]],
                            [36, [2, [17, [15, "h"], "search"], "replace", [7, "?", ""]]]
                        ]],
                        [5, [46, [36, [2, [15, "f"], "G", [7, [15, "g"]]]]]],
                        [5, [46]],
                        [9, [46, [36, [2, [15, "f"], "A", [7, ["d", [15, "g"]]]]]]]
                    ]
                ]
            ],
            [50, "__u", [46, "a"],
                [50, "k", [46, "l", "m"],
                    [52, "n", [17, [15, "m"], "multiQueryKeys"]],
                    [52, "o", [30, [17, [15, "m"], "queryKey"], ""]],
                    [52, "p", [17, [15, "m"], "ignoreEmptyQueryParam"]],
                    [22, [20, [15, "o"], ""],
                        [46, [53, [52, "r", [2, [17, ["i", [15, "l"]], "search"], "replace", [7, "?", ""]]],
                            [36, [39, [1, [28, [15, "r"]],
                                    [15, "p"]
                                ],
                                [44],
                                [15, "r"]
                            ]]
                        ]]
                    ],
                    [41, "q"],
                    [22, [15, "n"],
                        [46, [53, [22, [20, ["e", [15, "o"]], "array"],
                            [46, [53, [3, "q", [15, "o"]]]],
                            [46, [53, [52, "r", ["c", "\\s+", "g"]],
                                [3, "q", [2, [2, ["f", [15, "o"]], "replace", [7, [15, "r"], ""]], "split", [7, ","]]]
                            ]]
                        ]]],
                        [46, [53, [3, "q", [7, ["f", [15, "o"]]]]]]
                    ],
                    [65, "r", [15, "q"],
                        [46, [53, [52, "s", [2, [15, "h"], "H", [7, [15, "l"],
                                [15, "r"]
                            ]]],
                            [22, [29, [15, "s"],
                                    [44]
                                ],
                                [46, [53, [22, [1, [15, "p"],
                                            [20, [15, "s"], ""]
                                        ],
                                        [46, [53, [6]]]
                                    ],
                                    [36, [15, "s"]]
                                ]]
                            ]
                        ]]
                    ],
                    [36, [44]]
                ],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "internal.createRegex"]],
                [52, "d", ["require", "getUrl"]],
                [52, "e", ["require", "getType"]],
                [52, "f", ["require", "makeString"]],
                [52, "g", ["require", "parseUrl"]],
                [52, "h", [15, "__module_legacyUrls"]],
                [52, "i", ["require", "internal.legacyParseUrl"]],
                [41, "j"],
                [22, [17, [15, "a"], "customUrlSource"],
                    [46, [53, [3, "j", [17, [15, "a"], "customUrlSource"]]]],
                    [46, [53, [3, "j", ["b", "gtm.url", 1]]]]
                ],
                [3, "j", [30, [15, "j"],
                    ["d"]
                ]],
                [38, [17, [15, "a"], "component"],
                    [46, "PROTOCOL", "HOST", "PORT", "PATH", "EXTENSION", "QUERY", "FRAGMENT", "URL"],
                    [46, [5, [46, [36, [2, [15, "h"], "B", [7, [15, "j"]]]]]],
                        [5, [46, [36, [2, [15, "h"], "C", [7, [15, "j"],
                            [17, [15, "a"], "stripWww"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "h"], "D", [7, [15, "j"]]]]]],
                        [5, [46, [36, [2, [15, "h"], "E", [7, [15, "j"],
                            [17, [15, "a"], "defaultPages"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "h"], "F", [7, [15, "j"]]]]]],
                        [5, [46, [36, ["k", [15, "j"],
                            [15, "a"]
                        ]]]],
                        [5, [46, [36, [2, [15, "h"], "G", [7, [15, "j"]]]]]],
                        [5, [46]],
                        [9, [46, [36, [2, [15, "h"], "A", [7, ["f", [15, "j"]]]]]]]
                    ]
                ]
            ],
            [52, "__module_legacyUrls", [13, [41, "$0"],
                [3, "$0", [51, "", [7],
                    [50, "a", [46],
                        [50, "h", [46, "p"],
                            [52, "q", [2, [15, "p"], "indexOf", [7, "#"]]],
                            [36, [39, [23, [15, "q"], 0],
                                [15, "p"],
                                [2, [15, "p"], "substring", [7, 0, [15, "q"]]]
                            ]]
                        ],
                        [50, "i", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "protocol"]],
                            [36, [39, [15, "q"],
                                [2, [15, "q"], "replace", [7, ":", ""]], ""
                            ]]
                        ],
                        [50, "j", [46, "p", "q"],
                            [41, "r"],
                            [3, "r", [17, ["e", [15, "p"]], "hostname"]],
                            [22, [28, [15, "r"]],
                                [46, [36, ""]]
                            ],
                            [52, "s", ["b", ":[0-9]+"]],
                            [3, "r", [2, [15, "r"], "replace", [7, [15, "s"], ""]]],
                            [22, [15, "q"],
                                [46, [53, [52, "t", ["b", "^www\\d*\\."]],
                                    [52, "u", [2, [15, "r"], "match", [7, [15, "t"]]]],
                                    [22, [1, [15, "u"],
                                            [16, [15, "u"], 0]
                                        ],
                                        [46, [3, "r", [2, [15, "r"], "substring", [7, [17, [16, [15, "u"], 0], "length"]]]]]
                                    ]
                                ]]
                            ],
                            [36, [15, "r"]]
                        ],
                        [50, "k", [46, "p"],
                            [52, "q", ["e", [15, "p"]]],
                            [41, "r"],
                            [3, "r", ["f", [17, [15, "q"], "port"]]],
                            [22, [28, [15, "r"]],
                                [46, [53, [22, [20, [17, [15, "q"], "protocol"], "http:"],
                                    [46, [53, [3, "r", 80]]],
                                    [46, [22, [20, [17, [15, "q"], "protocol"], "https:"],
                                        [46, [53, [3, "r", 443]]],
                                        [46, [53, [3, "r", ""]]]
                                    ]]
                                ]]]
                            ],
                            [36, ["g", [15, "r"]]]
                        ],
                        [50, "l", [46, "p", "q"],
                            [52, "r", ["e", [15, "p"]]],
                            [41, "s"],
                            [3, "s", [39, [20, [2, [17, [15, "r"], "pathname"], "indexOf", [7, "/"]], 0],
                                [17, [15, "r"], "pathname"],
                                [0, "/", [17, [15, "r"], "pathName"]]
                            ]],
                            [22, [20, ["d", [15, "q"]], "array"],
                                [46, [53, [52, "t", [2, [15, "s"], "split", [7, "/"]]],
                                    [22, [19, [2, [15, "q"], "indexOf", [7, [16, [15, "t"],
                                            [37, [17, [15, "t"], "length"], 1]
                                        ]]], 0],
                                        [46, [53, [43, [15, "t"],
                                                [37, [17, [15, "t"], "length"], 1], ""
                                            ],
                                            [3, "s", [2, [15, "t"], "join", [7, "/"]]]
                                        ]]
                                    ]
                                ]]
                            ],
                            [36, [15, "s"]]
                        ],
                        [50, "m", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "pathname"]],
                            [52, "r", [2, [15, "q"], "split", [7, "."]]],
                            [41, "s"],
                            [3, "s", [39, [18, [17, [15, "r"], "length"], 1],
                                [16, [15, "r"],
                                    [37, [17, [15, "r"], "length"], 1]
                                ], ""
                            ]],
                            [36, [16, [2, [15, "s"], "split", [7, "/"]], 0]]
                        ],
                        [50, "n", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "hash"]],
                            [36, [2, [15, "q"], "replace", [7, "#", ""]]]
                        ],
                        [50, "o", [46, "p", "q"],
                            [50, "s", [46, "t"],
                                [36, ["c", [2, [15, "t"], "replace", [7, ["b", "\\+", "g"], " "]]]]
                            ],
                            [52, "r", [2, [17, ["e", [15, "p"]], "search"], "replace", [7, "?", ""]]],
                            [65, "t", [2, [15, "r"], "split", [7, "&"]],
                                [46, [53, [52, "u", [2, [15, "t"], "split", [7, "="]]],
                                    [22, [21, ["s", [16, [15, "u"], 0]],
                                            [15, "q"]
                                        ],
                                        [46, [6]]
                                    ],
                                    [36, ["s", [2, [2, [15, "u"], "slice", [7, 1]], "join", [7, "="]]]]
                                ]]
                            ],
                            [36]
                        ],
                        [52, "b", ["require", "internal.createRegex"]],
                        [52, "c", ["require", "decodeUriComponent"]],
                        [52, "d", ["require", "getType"]],
                        [52, "e", ["require", "internal.legacyParseUrl"]],
                        [52, "f", ["require", "makeNumber"]],
                        [52, "g", ["require", "makeString"]],
                        [36, [8, "F", [15, "m"], "H", [15, "o"], "G", [15, "n"], "C", [15, "j"], "E", [15, "l"], "D", [15, "k"], "B", [15, "i"], "A", [15, "h"]]]
                    ],
                    [36, ["a"]]
                ]],
                ["$0"]
            ]]

        ],
        "entities": {
            "__e": {
                "2": true,
                "5": true
            },
            "__f": {
                "2": true,
                "5": true
            },
            "__u": {
                "2": true,
                "5": true
            }


        },
        "blob": {
            "1": "1",
            "10": "GTM-KWC3V6TH",
            "14": "5ae0",
            "15": "1",
            "16": "MTQ1MzU4NTcxODUwNzUwMTQ1MQ==",
            "19": "dataLayer",
            "2": true,
            "20": "",
            "21": "www.googletagmanager.com",
            "22": "eyIwIjoiQkQiLCIxIjoiQkQtRiIsIjIiOmZhbHNlLCIzIjoiZ29vZ2xlLmNvbS5iZCIsIjQiOiIiLCI1Ijp0cnVlLCI2IjpmYWxzZSwiNyI6ImFkX3N0b3JhZ2V8YW5hbHl0aWNzX3N0b3JhZ2V8YWRfdXNlcl9kYXRhfGFkX3BlcnNvbmFsaXphdGlvbiJ9",
            "23": "google.tagmanager.debugui2.queue",
            "24": "tagassistant.google.com",
            "27": 0.005,
            "3": "www.googletagmanager.com",
            "30": "BD",
            "31": "BD-F",
            "32": true,
            "36": "https://adservice.google.com/pagead/regclk",
            "37": "__TAGGY_INSTALLED",
            "38": "cct.google",
            "39": "googTaggyReferrer",
            "40": "https://cct.google/taggy/agent.js",
            "41": "google.tagmanager.ta.prodqueue",
            "42": 0.01,
            "43": "{\"keys\":[{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BBi23tP39H4WGhrt7/MAsImQEz6A8WSvBBfxcVlWBJZn9oWJ1yIiVxf3i3w2cOHnsPb0OHUlxHyGu+sMCFEw1Js=\",\"version\":0},\"id\":\"970077af-129d-45e5-b765-a4fdbb3cf8b7\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BB2RvJabQZYTqDnP/tg66gqf6u0p5bw7JtmuoNKfPkQub4pAuGbRkPs9l/o0/50alHnOrieMsOFCW7oerVRGbBM=\",\"version\":0},\"id\":\"8fc87393-975a-40c8-aafd-41298ce032a0\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BEL1K0H/xn5IqwaTIGfWAy3YXz6x3f1BdzDALHOc5nwV6XjFEdlVBS22FbuWXSN3KiOlmoLMtcujkWGt8/VZb/Y=\",\"version\":0},\"id\":\"485def5c-ac85-4abd-bd54-826f4acba22a\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BDmiWYAQBn+HCa3IfI8fobPXUJ4eQfQB7WvT9YUM2Lzu05Rg1lwPdJ7dh1jMpsn4tW0EmmqdxadzSK2qHs1FnTU=\",\"version\":0},\"id\":\"33198146-7f66-4387-b5e6-d18a03473a23\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BNuLHM5ZMnKXZLz6rR+ir6fhLXOHyFiizkVv4m3YjR5gerWcxoAwDisEolqek6sxwGwv7jlebrZyUJb4JfGw/jE=\",\"version\":0},\"id\":\"1af59f0c-7745-4be1-a241-5ae1cb775bc5\"}]}",
            "44": "101509157~103116026~103200004~103233427~104684208~104684211~115834636~115834638~115868795~115868797~115995680~115995682",
            "46": {
                "1": "1000",
                "10": "5a20",
                "11": "5a20",
                "14": "1000",
                "16": "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD",
                "17": "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD",
                "2": "9",
                "20": "5000",
                "21": "5000",
                "22": "3.2.0",
                "23": "0.0.0",
                "25": "1",
                "26": "4000",
                "27": "100",
                "3": "5",
                "4": "ad_storage|analytics_storage|ad_user_data|ad_personalization",
                "44": "15000",
                "48": "30000",
                "5": "ad_storage|analytics_storage|ad_user_data",
                "6": "1",
                "60": "0",
                "7": "10"
            },
            "48": true,
            "5": "GTM-KWC3V6TH",
            "55": ["GTM-KWC3V6TH"],
            "56": [{
                "1": 403,
                "3": 0.5,
                "4": 115938465,
                "5": 115938466,
                "6": 0,
                "7": 2
            }, {
                "1": 404,
                "3": 0.5,
                "4": 115938468,
                "5": 115938469,
                "6": 0,
                "7": 1
            }],
            "59": ["GTM-KWC3V6TH"],
            "6": "227541335",
            "8": "res_ts:1755443902467863,srv_cl:819051056,ds:live,cv:1",
            "9": "GTM-KWC3V6TH"
        },
        "permissions": {
            "__e": {
                "read_event_data": {
                    "eventDataAccess": "specific",
                    "keyPatterns": ["event"]
                }
            },
            "__f": {
                "read_data_layer": {
                    "keyPatterns": ["gtm.referrer"]
                },
                "get_referrer": {
                    "urlParts": "any"
                }
            },
            "__u": {
                "read_data_layer": {
                    "keyPatterns": ["gtm.url"]
                },
                "get_url": {
                    "urlParts": "any"
                }
            }


        }



        ,
        "security_groups": {
            "google": [
                "__e",
                "__f",
                "__u"

            ]


        }



    };




    var k, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        da = function(a) {
            for (var b = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global], c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d && d.Math == Math) return d
            }
            throw Error("Cannot find global object");
        },
        ea = da(this),
        fa = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        ha = {},
        ma = {},
        na = function(a, b, c) {
            if (!c || a != null) {
                var d = ma[b];
                if (d == null) return a[b];
                var e = a[d];
                return e !== void 0 ? e : a[b]
            }
        },
        oa = function(a, b, c) {
            if (b) a: {
                var d = a.split("."),
                    e = d.length === 1,
                    f = d[0],
                    g;!e && f in ha ? g = ha : g = ea;
                for (var h = 0; h < d.length - 1; h++) {
                    var l = d[h];
                    if (!(l in g)) break a;
                    g = g[l]
                }
                var n = d[d.length - 1],
                    p = fa && c === "es6" ? g[n] : null,
                    q = b(p);
                if (q != null)
                    if (e) ba(ha, n, {
                        configurable: !0,
                        writable: !0,
                        value: q
                    });
                    else if (q !== p) {
                    if (ma[n] === void 0) {
                        var r =
                            Math.random() * 1E9 >>> 0;
                        ma[n] = fa ? ea.Symbol(n) : "$jscp$" + r + "$" + n
                    }
                    ba(g, ma[n], {
                        configurable: !0,
                        writable: !0,
                        value: q
                    })
                }
            }
        };
    oa("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.C = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.C
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    var pa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        qa;
    if (fa && typeof Object.setPrototypeOf == "function") qa = Object.setPrototypeOf;
    else {
        var ra;
        a: {
            var sa = {
                    a: !0
                },
                wa = {};
            try {
                wa.__proto__ = sa;
                ra = wa.a;
                break a
            } catch (a) {}
            ra = !1
        }
        qa = ra ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var xa = qa,
        ya = function(a, b) {
            a.prototype = pa(b.prototype);
            a.prototype.constructor = a;
            if (xa) xa(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Hr = b.prototype
        },
        m = function(a) {
            var b = typeof ha.Symbol != "undefined" && ha.Symbol.iterator && a[ha.Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        za = function(a) {
            for (var b,
                    c = []; !(b = a.next()).done;) c.push(b.value);
            return c
        },
        Aa = function(a) {
            return a instanceof Array ? a : za(m(a))
        },
        Ca = function(a) {
            return Ba(a, a)
        },
        Ba = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        Da = fa && typeof na(Object, "assign") == "function" ? na(Object, "assign") : function(a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
            }
            return a
        };
    oa("Object.assign", function(a) {
        return a || Da
    }, "es6");
    var Ea = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Fa = this || self,
        Ga = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.Hr = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.Os = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
    var Ha = function(a, b) {
        this.type = a;
        this.data = b
    };
    var Ia = function() {
        this.map = {};
        this.C = {}
    };
    Ia.prototype.get = function(a) {
        return this.map["dust." + a]
    };
    Ia.prototype.set = function(a, b) {
        var c = "dust." + a;
        this.C.hasOwnProperty(c) || (this.map[c] = b)
    };
    Ia.prototype.has = function(a) {
        return this.map.hasOwnProperty("dust." + a)
    };
    Ia.prototype.remove = function(a) {
        var b = "dust." + a;
        this.C.hasOwnProperty(b) || delete this.map[b]
    };
    var Ja = function(a, b) {
        var c = [],
            d;
        for (d in a.map)
            if (a.map.hasOwnProperty(d)) {
                var e = d.substring(5);
                switch (b) {
                    case 1:
                        c.push(e);
                        break;
                    case 2:
                        c.push(a.map[d]);
                        break;
                    case 3:
                        c.push([e, a.map[d]])
                }
            }
        return c
    };
    Ia.prototype.Aa = function() {
        return Ja(this, 1)
    };
    Ia.prototype.rc = function() {
        return Ja(this, 2)
    };
    Ia.prototype.Yb = function() {
        return Ja(this, 3)
    };
    var Ka = function() {};
    Ka.prototype.reset = function() {};
    var La = function(a, b) {
        this.T = a;
        this.parent = b;
        this.P = this.C = void 0;
        this.zb = !1;
        this.H = function(c, d, e) {
            return c.apply(d, e)
        };
        this.values = new Ia
    };
    La.prototype.add = function(a, b) {
        Ma(this, a, b, !1)
    };
    La.prototype.zh = function(a, b) {
        Ma(this, a, b, !0)
    };
    var Ma = function(a, b, c, d) {
        if (!a.zb)
            if (d) {
                var e = a.values;
                e.set(b, c);
                e.C["dust." + b] = !0
            } else a.values.set(b, c)
    };
    k = La.prototype;
    k.set = function(a, b) {
        this.zb || (!this.values.has(a) && this.parent && this.parent.has(a) ? this.parent.set(a, b) : this.values.set(a, b))
    };
    k.get = function(a) {
        return this.values.has(a) ? this.values.get(a) : this.parent ? this.parent.get(a) : void 0
    };
    k.has = function(a) {
        return !!this.values.has(a) || !(!this.parent || !this.parent.has(a))
    };
    k.lb = function() {
        var a = new La(this.T, this);
        this.C && a.Lb(this.C);
        a.Yc(this.H);
        a.Rd(this.P);
        return a
    };
    k.Jd = function() {
        return this.T
    };
    k.Lb = function(a) {
        this.C = a
    };
    k.Ym = function() {
        return this.C
    };
    k.Yc = function(a) {
        this.H = a
    };
    k.pj = function() {
        return this.H
    };
    k.Ta = function() {
        this.zb = !0
    };
    k.Rd = function(a) {
        this.P = a
    };
    k.nb = function() {
        return this.P
    };
    var Na = function() {
        this.value = {};
        this.prefix = "gtm."
    };
    Na.prototype.set = function(a, b) {
        this.value[this.prefix + String(a)] = b
    };
    Na.prototype.get = function(a) {
        return this.value[this.prefix + String(a)]
    };
    Na.prototype.has = function(a) {
        return this.value.hasOwnProperty(this.prefix + String(a))
    };

    function Oa() {
        try {
            if (Map) return new Map
        } catch (a) {}
        return new Na
    };
    var Pa = function() {
        this.values = []
    };
    Pa.prototype.add = function(a) {
        this.values.indexOf(a) === -1 && this.values.push(a)
    };
    Pa.prototype.has = function(a) {
        return this.values.indexOf(a) > -1
    };
    var Qa = function(a, b) {
        this.la = a;
        this.parent = b;
        this.T = this.H = void 0;
        this.zb = !1;
        this.P = function(d, e, f) {
            return d.apply(e, f)
        };
        this.C = Oa();
        var c;
        a: {
            try {
                if (Set) {
                    c = new Set;
                    break a
                }
            } catch (d) {}
            c = new Pa
        }
        this.V = c
    };
    Qa.prototype.add = function(a, b) {
        Ra(this, a, b, !1)
    };
    Qa.prototype.zh = function(a, b) {
        Ra(this, a, b, !0)
    };
    var Ra = function(a, b, c, d) {
        a.zb || a.V.has(b) || (d && a.V.add(b), a.C.set(b, c))
    };
    k = Qa.prototype;
    k.set = function(a, b) {
        this.zb || (!this.C.has(a) && this.parent && this.parent.has(a) ? this.parent.set(a, b) : this.V.has(a) || this.C.set(a, b))
    };
    k.get = function(a) {
        return this.C.has(a) ? this.C.get(a) : this.parent ? this.parent.get(a) : void 0
    };
    k.has = function(a) {
        return !!this.C.has(a) || !(!this.parent || !this.parent.has(a))
    };
    k.lb = function() {
        var a = new Qa(this.la, this);
        this.H && a.Lb(this.H);
        a.Yc(this.P);
        a.Rd(this.T);
        return a
    };
    k.Jd = function() {
        return this.la
    };
    k.Lb = function(a) {
        this.H = a
    };
    k.Ym = function() {
        return this.H
    };
    k.Yc = function(a) {
        this.P = a
    };
    k.pj = function() {
        return this.P
    };
    k.Ta = function() {
        this.zb = !0
    };
    k.Rd = function(a) {
        this.T = a
    };
    k.nb = function() {
        return this.T
    };
    var Sa = function(a, b, c) {
        var d;
        d = Error.call(this, a.message);
        this.message = d.message;
        "stack" in d && (this.stack = d.stack);
        this.ln = a;
        this.Qm = c === void 0 ? !1 : c;
        this.debugInfo = [];
        this.C = b
    };
    ya(Sa, Error);
    var Ua = function(a) {
        return a instanceof Sa ? a : new Sa(a, void 0, !0)
    };
    var Va = [];

    function Wa(a) {
        return Va[a] === void 0 ? !1 : Va[a]
    };
    var Xa = Oa();

    function Za(a, b) {
        for (var c, d = m(b), e = d.next(); !e.done && !(c = $a(a, e.value), c instanceof Ha); e = d.next());
        return c
    }

    function $a(a, b) {
        try {
            if (Wa(17)) {
                var c = b[0],
                    d = b.slice(1),
                    e = String(c),
                    f = Xa.has(e) ? Xa.get(e) : a.get(e);
                if (!f || typeof f.invoke !== "function") throw Ua(Error("Attempting to execute non-function " + b[0] + "."));
                return f.apply(a, d)
            }
            var g = m(b),
                h = g.next().value,
                l = za(g),
                n = a.get(String(h));
            if (!n || typeof n.invoke !== "function") throw Ua(Error("Attempting to execute non-function " + b[0] + "."));
            return n.invoke.apply(n, [a].concat(Aa(l)))
        } catch (q) {
            var p = a.Ym();
            p && p(q, b.context ? {
                id: b[0],
                line: b.context.line
            } : null);
            throw q;
        }
    };
    var ab = function() {
        this.H = new Ka;
        this.C = Wa(17) ? new Qa(this.H) : new La(this.H)
    };
    k = ab.prototype;
    k.Jd = function() {
        return this.H
    };
    k.Lb = function(a) {
        this.C.Lb(a)
    };
    k.Yc = function(a) {
        this.C.Yc(a)
    };
    k.execute = function(a) {
        return this.Oj([a].concat(Aa(Ea.apply(1, arguments))))
    };
    k.Oj = function() {
        for (var a, b = m(Ea.apply(0, arguments)), c = b.next(); !c.done; c = b.next()) a = $a(this.C, c.value);
        return a
    };
    k.mp = function(a) {
        var b = Ea.apply(1, arguments),
            c = this.C.lb();
        c.Rd(a);
        for (var d, e = m(b), f = e.next(); !f.done; f = e.next()) d = $a(c, f.value);
        return d
    };
    k.Ta = function() {
        this.C.Ta()
    };
    var bb = function() {
        this.Ga = !1;
        this.da = new Ia
    };
    k = bb.prototype;
    k.get = function(a) {
        return this.da.get(a)
    };
    k.set = function(a, b) {
        this.Ga || this.da.set(a, b)
    };
    k.has = function(a) {
        return this.da.has(a)
    };
    k.remove = function(a) {
        this.Ga || this.da.remove(a)
    };
    k.Aa = function() {
        return this.da.Aa()
    };
    k.rc = function() {
        return this.da.rc()
    };
    k.Yb = function() {
        return this.da.Yb()
    };
    k.Ta = function() {
        this.Ga = !0
    };
    k.zb = function() {
        return this.Ga
    };

    function cb() {
        for (var a = db, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
        return b
    }

    function eb() {
        var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        a += a.toLowerCase() + "0123456789-_";
        return a + "."
    }
    var db, fb;

    function gb(a) {
        db = db || eb();
        fb = fb || cb();
        for (var b = [], c = 0; c < a.length; c += 3) {
            var d = c + 1 < a.length,
                e = c + 2 < a.length,
                f = a.charCodeAt(c),
                g = d ? a.charCodeAt(c + 1) : 0,
                h = e ? a.charCodeAt(c + 2) : 0,
                l = f >> 2,
                n = (f & 3) << 4 | g >> 4,
                p = (g & 15) << 2 | h >> 6,
                q = h & 63;
            e || (q = 64, d || (p = 64));
            b.push(db[l], db[n], db[p], db[q])
        }
        return b.join("")
    }

    function hb(a) {
        function b(l) {
            for (; d < a.length;) {
                var n = a.charAt(d++),
                    p = fb[n];
                if (p != null) return p;
                if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
            }
            return l
        }
        db = db || eb();
        fb = fb || cb();
        for (var c = "", d = 0;;) {
            var e = b(-1),
                f = b(0),
                g = b(64),
                h = b(64);
            if (h === 64 && e === -1) return c;
            c += String.fromCharCode(e << 2 | f >> 4);
            g !== 64 && (c += String.fromCharCode(f << 4 & 240 | g >> 2), h !== 64 && (c += String.fromCharCode(g << 6 & 192 | h)))
        }
    };
    var ib = {};

    function jb(a, b) {
        ib[a] = ib[a] || [];
        ib[a][b] = !0
    }

    function kb() {
        delete ib.GA4_EVENT
    }

    function lb() {
        var a = mb.slice();
        ib.GTAG_EVENT_FEATURE_CHANNEL = a
    }

    function nb(a) {
        var b = ib[a];
        if (!b || b.length === 0) return "";
        for (var c = [], d = 0, e = 0; e < b.length; e++) e % 8 === 0 && e > 0 && (c.push(String.fromCharCode(d)), d = 0), b[e] && (d |= 1 << e % 8);
        d > 0 && c.push(String.fromCharCode(d));
        return gb(c.join("")).replace(/\.+$/, "")
    };

    function ob() {}

    function pb(a) {
        return typeof a === "function"
    }

    function qb(a) {
        return typeof a === "string"
    }

    function rb(a) {
        return typeof a === "number" && !isNaN(a)
    }

    function sb(a) {
        return Array.isArray(a) ? a : [a]
    }

    function tb(a, b) {
        if (a && Array.isArray(a))
            for (var c = 0; c < a.length; c++)
                if (a[c] && b(a[c])) return a[c]
    }

    function ub(a, b) {
        if (!rb(a) || !rb(b) || a > b) a = 0, b = 2147483647;
        return Math.floor(Math.random() * (b - a + 1) + a)
    }

    function vb(a, b) {
        for (var c = new wb, d = 0; d < a.length; d++) c.set(a[d], !0);
        for (var e = 0; e < b.length; e++)
            if (c.get(b[e])) return !0;
        return !1
    }

    function xb(a, b) {
        for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
    }

    function yb(a) {
        return !!a && (Object.prototype.toString.call(a) === "[object Arguments]" || Object.prototype.hasOwnProperty.call(a, "callee"))
    }

    function zb(a) {
        return Math.round(Number(a)) || 0
    }

    function Ab(a) {
        return "false" === String(a).toLowerCase() ? !1 : !!a
    }

    function Bb(a) {
        var b = [];
        if (Array.isArray(a))
            for (var c = 0; c < a.length; c++) b.push(String(a[c]));
        return b
    }

    function Cb(a) {
        return a ? a.replace(/^\s+|\s+$/g, "") : ""
    }

    function Db() {
        return new Date(Date.now())
    }

    function Eb() {
        return Db().getTime()
    }
    var wb = function() {
        this.prefix = "gtm.";
        this.values = {}
    };
    wb.prototype.set = function(a, b) {
        this.values[this.prefix + a] = b
    };
    wb.prototype.get = function(a) {
        return this.values[this.prefix + a]
    };
    wb.prototype.contains = function(a) {
        return this.get(a) !== void 0
    };

    function Fb(a, b, c) {
        return a && a.hasOwnProperty(b) ? a[b] : c
    }

    function Gb(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = void 0;
                try {
                    c()
                } catch (d) {}
            }
        }
    }

    function Hb(a, b) {
        for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c])
    }

    function Ib(a, b) {
        for (var c = [], d = 0; d < a.length; d++) c.push(a[d]), c.push.apply(c, b[a[d]] || []);
        return c
    }

    function Jb(a, b) {
        return a.length >= b.length && a.substring(0, b.length) === b
    }

    function Kb(a, b, c) {
        c = c || [];
        for (var d = a, e = 0; e < b.length - 1; e++) {
            if (!d.hasOwnProperty(b[e])) return;
            d = d[b[e]];
            if (c.indexOf(d) >= 0) return
        }
        return d
    }

    function Nb(a, b) {
        for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++) d = d[e[f]] = {};
        d[e[e.length - 1]] = b;
        return c
    }
    var Ob = /^\w{1,9}$/;

    function Qb(a, b) {
        a = a || {};
        b = b || ",";
        var c = [];
        xb(a, function(d, e) {
            Ob.test(d) && e && c.push(d)
        });
        return c.join(b)
    }

    function Rb(a) {
        for (var b = [], c = 0; c < a.length; c++) {
            var d = a.charCodeAt(c);
            d < 128 ? b.push(d) : d < 2048 ? b.push(192 | d >> 6, 128 | d & 63) : d < 55296 || d >= 57344 ? b.push(224 | d >> 12, 128 | d >> 6 & 63, 128 | d & 63) : (d = 65536 + ((d & 1023) << 10 | a.charCodeAt(++c) & 1023), b.push(240 | d >> 18, 128 | d >> 12 & 63, 128 | d >> 6 & 63, 128 | d & 63))
        }
        return new Uint8Array(b)
    }

    function Sb(a, b) {
        function c() {
            e && ++d === b && (e(), e = null, c.done = !0)
        }
        var d = 0,
            e = a;
        c.done = !1;
        return c
    }

    function Tb(a) {
        if (!a) return a;
        var b = a;
        try {
            b = decodeURIComponent(a)
        } catch (d) {}
        var c = b.split(",");
        return c.length === 2 && c[0] === c[1] ? c[0] : a
    }

    function Ub(a, b, c) {
        function d(n) {
            var p = n.split("=")[0];
            if (a.indexOf(p) < 0) return n;
            if (c !== void 0) return p + "=" + c
        }

        function e(n) {
            return n.split("&").map(d).filter(function(p) {
                return p !== void 0
            }).join("&")
        }
        var f = b.href.split(/[?#]/)[0],
            g = b.search,
            h = b.hash;
        g[0] === "?" && (g = g.substring(1));
        h[0] === "#" && (h = h.substring(1));
        g = e(g);
        h = e(h);
        g !== "" && (g = "?" + g);
        h !== "" && (h = "#" + h);
        var l = "" + f + g + h;
        l[l.length - 1] === "/" && (l = l.substring(0, l.length - 1));
        return l
    }

    function Vb(a) {
        for (var b = 0; b < 3; ++b) try {
            var c = decodeURIComponent(a).replace(/\+/g, " ");
            if (c === a) break;
            a = c
        } catch (d) {
            return ""
        }
        return a
    }

    function Wb() {
        var a = w,
            b;
        a: {
            var c = a.crypto || a.msCrypto;
            if (c && c.getRandomValues) try {
                var d = new Uint8Array(25);
                c.getRandomValues(d);
                b = btoa(String.fromCharCode.apply(String, Aa(d))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
                break a
            } catch (e) {}
            b = void 0
        }
        return b
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var Xb = globalThis.trustedTypes,
        Yb;

    function Zb() {
        var a = null;
        if (!Xb) return a;
        try {
            var b = function(c) {
                return c
            };
            a = Xb.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    }

    function $b() {
        Yb === void 0 && (Yb = Zb());
        return Yb
    };
    var ac = function(a) {
        this.C = a
    };
    ac.prototype.toString = function() {
        return this.C + ""
    };

    function bc(a) {
        var b = a,
            c = $b(),
            d = c ? c.createScriptURL(b) : b;
        return new ac(d)
    }

    function cc(a) {
        if (a instanceof ac) return a.C;
        throw Error("");
    };
    var dc = Ca([""]),
        ec = Ba(["\x00"], ["\\0"]),
        fc = Ba(["\n"], ["\\n"]),
        hc = Ba(["\x00"], ["\\u0000"]);

    function ic(a) {
        return a.toString().indexOf("`") === -1
    }
    ic(function(a) {
        return a(dc)
    }) || ic(function(a) {
        return a(ec)
    }) || ic(function(a) {
        return a(fc)
    }) || ic(function(a) {
        return a(hc)
    });
    var jc = function(a) {
        this.C = a
    };
    jc.prototype.toString = function() {
        return this.C
    };
    var kc = function(a) {
        this.Rq = a
    };

    function lc(a) {
        return new kc(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    }
    var mc = [lc("data"), lc("http"), lc("https"), lc("mailto"), lc("ftp"), new kc(function(a) {
        return /^[^:]*([/?#]|$)/.test(a)
    })];

    function nc(a) {
        var b;
        b = b === void 0 ? mc : b;
        if (a instanceof jc) return a;
        for (var c = 0; c < b.length; ++c) {
            var d = b[c];
            if (d instanceof kc && d.Rq(a)) return new jc(a)
        }
    }
    var oc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function pc(a) {
        var b;
        if (a instanceof jc)
            if (a instanceof jc) b = a.C;
            else throw Error("");
        else b = oc.test(a) ? a : void 0;
        return b
    };

    function qc(a, b) {
        var c = pc(b);
        c !== void 0 && (a.action = c)
    };

    function rc(a, b) {
        throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
    };
    var sc = function(a) {
        this.C = a
    };
    sc.prototype.toString = function() {
        return this.C + ""
    };
    var uc = function() {
        this.C = tc[0].toLowerCase()
    };
    uc.prototype.toString = function() {
        return this.C
    };

    function vc(a, b) {
        var c = [new uc];
        if (c.length === 0) throw Error("");
        var d = c.map(function(f) {
                var g;
                if (f instanceof uc) g = f.C;
                else throw Error("");
                return g
            }),
            e = b.toLowerCase();
        if (d.every(function(f) {
                return e.indexOf(f) !== 0
            })) throw Error('Attribute "' + b + '" does not match any of the allowed prefixes.');
        a.setAttribute(b, "true")
    };
    var wc = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function xc(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a
    };
    var w = window,
        yc = window.history,
        A = document,
        zc = navigator;

    function Ac() {
        var a;
        try {
            a = zc.serviceWorker
        } catch (b) {
            return
        }
        return a
    }
    var Bc = A.currentScript,
        Cc = Bc && Bc.src;

    function Dc(a, b) {
        var c = w,
            d = c[a];
        c[a] = d === void 0 ? b : d;
        return c[a]
    }

    function Ec(a) {
        return (zc.userAgent || "").indexOf(a) !== -1
    }

    function Fc() {
        return Ec("Firefox") || Ec("FxiOS")
    }

    function Gc() {
        return (Ec("GSA") || Ec("GoogleApp")) && (Ec("iPhone") || Ec("iPad"))
    }

    function Hc() {
        return Ec("Edg/") || Ec("EdgA/") || Ec("EdgiOS/")
    }
    var Ic = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        Jc = {
            height: 1,
            onload: 1,
            src: 1,
            style: 1,
            width: 1
        };

    function Kc(a, b, c) {
        b && xb(b, function(d, e) {
            d = d.toLowerCase();
            c.hasOwnProperty(d) || a.setAttribute(d, e)
        })
    }

    function Lc(a, b, c, d, e) {
        var f = A.createElement("script");
        Kc(f, d, Ic);
        f.type = "text/javascript";
        f.async = d && d.async === !1 ? !1 : !0;
        var g;
        g = bc(xc(a));
        f.src = cc(g);
        var h, l = f.ownerDocument;
        l = l === void 0 ? document : l;
        var n, p, q = (p = (n = l).querySelector) == null ? void 0 : p.call(n, "script[nonce]");
        (h = q == null ? "" : q.nonce || q.getAttribute("nonce") || "") && f.setAttribute("nonce", h);
        b && (f.onload = b);
        c && (f.onerror = c);
        if (e) e.appendChild(f);
        else {
            var r = A.getElementsByTagName("script")[0] || A.body || A.head;
            r.parentNode.insertBefore(f, r)
        }
        return f
    }

    function Mc() {
        if (Cc) {
            var a = Cc.toLowerCase();
            if (a.indexOf("https://") === 0) return 2;
            if (a.indexOf("http://") === 0) return 3
        }
        return 1
    }

    function Nc(a, b, c, d, e, f) {
        f = f === void 0 ? !0 : f;
        var g = e,
            h = !1;
        g || (g = A.createElement("iframe"), h = !0);
        Kc(g, c, Jc);
        d && xb(d, function(n, p) {
            g.dataset[n] = p
        });
        f && (g.height = "0", g.width = "0", g.style.display = "none", g.style.visibility = "hidden");
        a !== void 0 && (g.src = a);
        if (h) {
            var l = A.body && A.body.lastChild || A.body || A.head;
            l.parentNode.insertBefore(g, l)
        }
        b && (g.onload = b);
        return g
    }

    function Oc(a, b, c, d) {
        return Pc(a, b, c, d)
    }

    function Qc(a, b, c, d) {
        a.addEventListener && a.addEventListener(b, c, !!d)
    }

    function Rc(a, b, c) {
        a.removeEventListener && a.removeEventListener(b, c, !1)
    }

    function Sc(a) {
        w.setTimeout(a, 0)
    }

    function Tc(a, b) {
        return a && b && a.attributes && a.attributes[b] ? a.attributes[b].value : null
    }

    function Uc(a) {
        var b = a.innerText || a.textContent || "";
        b && b !== " " && (b = b.replace(/^[\s\xa0]+/g, ""), b = b.replace(/[\s\xa0]+$/g, ""));
        b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
        return b
    }

    function Vc(a) {
        var b = A.createElement("div"),
            c = b,
            d, e = xc("A<div>" + a + "</div>"),
            f = $b(),
            g = f ? f.createHTML(e) : e;
        d = new sc(g);
        if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName)) throw Error("");
        var h;
        if (d instanceof sc) h = d.C;
        else throw Error("");
        c.innerHTML = h;
        b = b.lastChild;
        for (var l = []; b && b.firstChild;) l.push(b.removeChild(b.firstChild));
        return l
    }

    function Wc(a, b, c) {
        c = c || 100;
        for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
        for (var f = a, g = 0; f && g <= c; g++) {
            if (d[String(f.tagName).toLowerCase()]) return f;
            f = f.parentElement
        }
        return null
    }

    function Xc(a, b, c) {
        var d;
        try {
            d = zc.sendBeacon && zc.sendBeacon(a)
        } catch (e) {
            jb("TAGGING", 15)
        }
        d ? b == null || b() : Pc(a, b, c)
    }

    function Yc(a, b) {
        try {
            return zc.sendBeacon(a, b)
        } catch (c) {
            jb("TAGGING", 15)
        }
        return !1
    }
    var ad = {
        cache: "no-store",
        credentials: "include",
        keepalive: !0,
        method: "POST",
        mode: "no-cors",
        redirect: "follow"
    };

    function bd(a, b, c, d, e) {
        if (cd()) {
            var f = na(Object, "assign").call(Object, {}, ad);
            b && (f.body = b);
            c && (c.attributionReporting && (f.attributionReporting = c.attributionReporting), c.browsingTopics && (f.browsingTopics = c.browsingTopics), c.credentials && (f.credentials = c.credentials), c.mode && (f.mode = c.mode), c.method && (f.method = c.method));
            try {
                var g = w.fetch(a, f);
                if (g) return g.then(function(l) {
                    l && (l.ok || l.status === 0) ? d == null || d() : e == null || e()
                }).catch(function() {
                    e == null || e()
                }), !0
            } catch (l) {}
        }
        if (c && c.Pe) return e == null || e(), !1;
        if (b) {
            var h = Yc(a, b);
            h ? d == null || d() : e == null || e();
            return h
        }
        dd(a, d, e);
        return !0
    }

    function cd() {
        return typeof w.fetch === "function"
    }

    function ed(a, b) {
        var c = a[b];
        c && typeof c.animVal === "string" && (c = c.animVal);
        return c
    }

    function fd() {
        var a = w.performance;
        if (a && pb(a.now)) return a.now()
    }

    function gd() {
        var a, b = w.performance;
        if (b && b.getEntriesByType) try {
            var c = b.getEntriesByType("navigation");
            c && c.length > 0 && (a = c[0].type)
        } catch (d) {
            return "e"
        }
        if (!a) return "u";
        switch (a) {
            case "navigate":
                return "n";
            case "back_forward":
                return "h";
            case "reload":
                return "r";
            case "prerender":
                return "p";
            default:
                return "x"
        }
    }

    function hd() {
        return w.performance || void 0
    }

    function id() {
        var a = w.webPixelsManager;
        return a ? a.createShopifyExtend !== void 0 : !1
    }
    var Pc = function(a, b, c, d) {
            var e = new Image(1, 1);
            Kc(e, d, {});
            e.onload = function() {
                e.onload = null;
                b && b()
            };
            e.onerror = function() {
                e.onerror = null;
                c && c()
            };
            e.src = a;
            return e
        },
        dd = Xc;

    function jd(a, b) {
        return this.evaluate(a) && this.evaluate(b)
    }

    function kd(a, b) {
        return this.evaluate(a) === this.evaluate(b)
    }

    function ld(a, b) {
        return this.evaluate(a) || this.evaluate(b)
    }

    function md(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        return String(c).indexOf(String(d)) > -1
    }

    function nd(a, b) {
        var c = String(this.evaluate(a)),
            d = String(this.evaluate(b));
        return c.substring(0, d.length) === d
    }

    function od(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        switch (c) {
            case "pageLocation":
                var e = w.location.href;
                d instanceof bb && d.get("stripProtocol") && (e = e.replace(/^https?:\/\//, ""));
                return e
        }
    };
    /*
     jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
    */
    var pd = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
        qd = function(a) {
            if (a == null) return String(a);
            var b = pd.exec(Object.prototype.toString.call(Object(a)));
            return b ? b[1].toLowerCase() : "object"
        },
        rd = function(a, b) {
            return Object.prototype.hasOwnProperty.call(Object(a), b)
        },
        sd = function(a) {
            if (!a || qd(a) != "object" || a.nodeType || a == a.window) return !1;
            try {
                if (a.constructor && !rd(a, "constructor") && !rd(a.constructor.prototype, "isPrototypeOf")) return !1
            } catch (c) {
                return !1
            }
            for (var b in a);
            return b === void 0 ||
                rd(a, b)
        },
        td = function(a, b) {
            var c = b || (qd(a) == "array" ? [] : {}),
                d;
            for (d in a)
                if (rd(a, d)) {
                    var e = a[d];
                    qd(e) == "array" ? (qd(c[d]) != "array" && (c[d] = []), c[d] = td(e, c[d])) : sd(e) ? (sd(c[d]) || (c[d] = {}), c[d] = td(e, c[d])) : c[d] = e
                }
            return c
        };

    function ud(a) {
        if (a == void 0 || Array.isArray(a) || sd(a)) return !0;
        switch (typeof a) {
            case "boolean":
            case "number":
            case "string":
            case "function":
                return !0
        }
        return !1
    }

    function vd(a) {
        return typeof a === "number" && a >= 0 && isFinite(a) && a % 1 === 0 || typeof a === "string" && a[0] !== "-" && a === "" + parseInt(a)
    };
    var wd = function(a) {
        a = a === void 0 ? [] : a;
        this.da = new Ia;
        this.values = [];
        this.Ga = !1;
        for (var b in a) a.hasOwnProperty(b) && (vd(b) ? this.values[Number(b)] = a[Number(b)] : this.da.set(b, a[b]))
    };
    k = wd.prototype;
    k.toString = function(a) {
        if (a && a.indexOf(this) >= 0) return "";
        for (var b = [], c = 0; c < this.values.length; c++) {
            var d = this.values[c];
            d === null || d === void 0 ? b.push("") : d instanceof wd ? (a = a || [], a.push(this), b.push(d.toString(a)), a.pop()) : b.push(String(d))
        }
        return b.join(",")
    };
    k.set = function(a, b) {
        if (!this.Ga)
            if (a === "length") {
                if (!vd(b)) throw Ua(Error("RangeError: Length property must be a valid integer."));
                this.values.length = Number(b)
            } else vd(a) ? this.values[Number(a)] = b : this.da.set(a, b)
    };
    k.get = function(a) {
        return a === "length" ? this.length() : vd(a) ? this.values[Number(a)] : this.da.get(a)
    };
    k.length = function() {
        return this.values.length
    };
    k.Aa = function() {
        for (var a = this.da.Aa(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push(String(b));
        return a
    };
    k.rc = function() {
        for (var a = this.da.rc(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push(this.values[b]);
        return a
    };
    k.Yb = function() {
        for (var a = this.da.Yb(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push([String(b), this.values[b]]);
        return a
    };
    k.remove = function(a) {
        vd(a) ? delete this.values[Number(a)] : this.Ga || this.da.remove(a)
    };
    k.pop = function() {
        return this.values.pop()
    };
    k.push = function() {
        return this.values.push.apply(this.values, Aa(Ea.apply(0, arguments)))
    };
    k.shift = function() {
        return this.values.shift()
    };
    k.splice = function(a, b) {
        var c = Ea.apply(2, arguments);
        return b === void 0 && c.length === 0 ? new wd(this.values.splice(a)) : new wd(this.values.splice.apply(this.values, [a, b || 0].concat(Aa(c))))
    };
    k.unshift = function() {
        return this.values.unshift.apply(this.values, Aa(Ea.apply(0, arguments)))
    };
    k.has = function(a) {
        return vd(a) && this.values.hasOwnProperty(a) || this.da.has(a)
    };
    k.Ta = function() {
        this.Ga = !0;
        Object.freeze(this.values)
    };
    k.zb = function() {
        return this.Ga
    };

    function xd(a) {
        for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
        return b
    };
    var yd = function(a, b) {
        this.functionName = a;
        this.Id = b;
        this.da = new Ia;
        this.Ga = !1
    };
    k = yd.prototype;
    k.toString = function() {
        return this.functionName
    };
    k.getName = function() {
        return this.functionName
    };
    k.getKeys = function() {
        return new wd(this.Aa())
    };
    k.invoke = function(a) {
        return this.Id.call.apply(this.Id, [new zd(this, a)].concat(Aa(Ea.apply(1, arguments))))
    };
    k.apply = function(a, b) {
        return this.Id.apply(new zd(this, a), b)
    };
    k.Jb = function(a) {
        var b = Ea.apply(1, arguments);
        try {
            return this.invoke.apply(this, [a].concat(Aa(b)))
        } catch (c) {}
    };
    k.get = function(a) {
        return this.da.get(a)
    };
    k.set = function(a, b) {
        this.Ga || this.da.set(a, b)
    };
    k.has = function(a) {
        return this.da.has(a)
    };
    k.remove = function(a) {
        this.Ga || this.da.remove(a)
    };
    k.Aa = function() {
        return this.da.Aa()
    };
    k.rc = function() {
        return this.da.rc()
    };
    k.Yb = function() {
        return this.da.Yb()
    };
    k.Ta = function() {
        this.Ga = !0
    };
    k.zb = function() {
        return this.Ga
    };
    var Ad = function(a, b) {
        yd.call(this, a, b)
    };
    ya(Ad, yd);
    var Bd = function(a, b) {
        yd.call(this, a, b)
    };
    ya(Bd, yd);
    var zd = function(a, b) {
        this.Id = a;
        this.J = b
    };
    zd.prototype.evaluate = function(a) {
        var b = this.J;
        return Array.isArray(a) ? $a(b, a) : a
    };
    zd.prototype.getName = function() {
        return this.Id.getName()
    };
    zd.prototype.Jd = function() {
        return this.J.Jd()
    };
    var Cd = function() {
        this.map = new Map
    };
    Cd.prototype.set = function(a, b) {
        this.map.set(a, b)
    };
    Cd.prototype.get = function(a) {
        return this.map.get(a)
    };
    var Dd = function() {
        this.keys = [];
        this.values = []
    };
    Dd.prototype.set = function(a, b) {
        this.keys.push(a);
        this.values.push(b)
    };
    Dd.prototype.get = function(a) {
        var b = this.keys.indexOf(a);
        if (b > -1) return this.values[b]
    };

    function Ed() {
        try {
            return Map ? new Cd : new Dd
        } catch (a) {
            return new Dd
        }
    };
    var Fd = function(a) {
        if (a instanceof Fd) return a;
        if (ud(a)) throw Error("Type of given value has an equivalent Pixie type.");
        this.value = a
    };
    Fd.prototype.getValue = function() {
        return this.value
    };
    Fd.prototype.toString = function() {
        return String(this.value)
    };
    var Hd = function(a) {
        this.promise = a;
        this.Ga = !1;
        this.da = new Ia;
        this.da.set("then", Gd(this));
        this.da.set("catch", Gd(this, !0));
        this.da.set("finally", Gd(this, !1, !0))
    };
    k = Hd.prototype;
    k.get = function(a) {
        return this.da.get(a)
    };
    k.set = function(a, b) {
        this.Ga || this.da.set(a, b)
    };
    k.has = function(a) {
        return this.da.has(a)
    };
    k.remove = function(a) {
        this.Ga || this.da.remove(a)
    };
    k.Aa = function() {
        return this.da.Aa()
    };
    k.rc = function() {
        return this.da.rc()
    };
    k.Yb = function() {
        return this.da.Yb()
    };
    var Gd = function(a, b, c) {
        b = b === void 0 ? !1 : b;
        c = c === void 0 ? !1 : c;
        return new Ad("", function(d, e) {
            b && (e = d, d = void 0);
            c && (e = d);
            d instanceof Ad || (d = void 0);
            e instanceof Ad || (e = void 0);
            var f = this.J.lb(),
                g = function(l) {
                    return function(n) {
                        try {
                            return c ? (l.invoke(f), a.promise) : l.invoke(f, n)
                        } catch (p) {
                            return Promise.reject(p instanceof Error ? new Fd(p) : String(p))
                        }
                    }
                },
                h = a.promise.then(d && g(d), e && g(e));
            return new Hd(h)
        })
    };
    Hd.prototype.Ta = function() {
        this.Ga = !0
    };
    Hd.prototype.zb = function() {
        return this.Ga
    };

    function B(a, b, c) {
        var d = Ed(),
            e = function(g, h) {
                for (var l = g.Aa(), n = 0; n < l.length; n++) h[l[n]] = f(g.get(l[n]))
            },
            f = function(g) {
                if (g === null || g === void 0) return g;
                var h = d.get(g);
                if (h) return h;
                if (g instanceof wd) {
                    var l = [];
                    d.set(g, l);
                    for (var n = g.Aa(), p = 0; p < n.length; p++) l[n[p]] = f(g.get(n[p]));
                    return l
                }
                if (g instanceof Hd) return g.promise.then(function(t) {
                    return B(t, b, 1)
                }, function(t) {
                    return Promise.reject(B(t, b, 1))
                });
                if (g instanceof bb) {
                    var q = {};
                    d.set(g, q);
                    e(g, q);
                    return q
                }
                if (g instanceof Ad) {
                    var r = function() {
                        for (var t = [], u = 0; u < arguments.length; u++) t[u] = Id(arguments[u], b, c);
                        var x = new La(b ? b.Jd() : new Ka);
                        b && x.Rd(b.nb());
                        return f(Wa(17) ? g.apply(x, t) : g.invoke.apply(g, [x].concat(Aa(t))))
                    };
                    d.set(g, r);
                    e(g, r);
                    return r
                }
                var v = !1;
                switch (c) {
                    case 1:
                        v = !0;
                        break;
                    case 2:
                        v = !1;
                        break;
                    case 3:
                        v = !1;
                        break;
                    default:
                }
                if (g instanceof Fd && v) return g.getValue();
                switch (typeof g) {
                    case "boolean":
                    case "number":
                    case "string":
                    case "undefined":
                        return g;
                    case "object":
                        if (g === null) return null
                }
            };
        return f(a)
    }

    function Id(a, b, c) {
        var d = Ed(),
            e = function(g, h) {
                for (var l in g) g.hasOwnProperty(l) && h.set(l, f(g[l]))
            },
            f = function(g) {
                var h = d.get(g);
                if (h) return h;
                if (Array.isArray(g) || yb(g)) {
                    var l = new wd;
                    d.set(g, l);
                    for (var n in g) g.hasOwnProperty(n) && l.set(n, f(g[n]));
                    return l
                }
                if (sd(g)) {
                    var p = new bb;
                    d.set(g, p);
                    e(g, p);
                    return p
                }
                if (typeof g === "function") {
                    var q = new Ad("", function() {
                        for (var t = Ea.apply(0, arguments), u = [], x = 0; x < t.length; x++) u[x] = B(this.evaluate(t[x]), b, c);
                        return f(this.J.pj()(g, g, u))
                    });
                    d.set(g, q);
                    e(g, q);
                    return q
                }
                var r = typeof g;
                if (g === null || r === "string" || r === "number" || r === "boolean") return g;
                var v = !1;
                switch (c) {
                    case 1:
                        v = !0;
                        break;
                    case 2:
                        v = !1;
                        break;
                    default:
                }
                if (g !== void 0 && v) return new Fd(g)
            };
        return f(a)
    };
    var Jd = {
        supportedMethods: "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(" "),
        concat: function(a) {
            for (var b = [], c = 0; c < this.length(); c++) b.push(this.get(c));
            for (var d = 1; d < arguments.length; d++)
                if (arguments[d] instanceof wd)
                    for (var e = arguments[d], f = 0; f < e.length(); f++) b.push(e.get(f));
                else b.push(arguments[d]);
            return new wd(b)
        },
        every: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() &&
                d < c; d++)
                if (this.has(d) && !b.invoke(a, this.get(d), d, this)) return !1;
            return !0
        },
        filter: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && b.invoke(a, this.get(e), e, this) && d.push(this.get(e));
            return new wd(d)
        },
        forEach: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++) this.has(d) && b.invoke(a, this.get(d), d, this)
        },
        hasOwnProperty: function(a, b) {
            return this.has(b)
        },
        indexOf: function(a, b, c) {
            var d = this.length(),
                e = c === void 0 ? 0 : Number(c);
            e < 0 && (e = Math.max(d + e, 0));
            for (var f =
                    e; f < d; f++)
                if (this.has(f) && this.get(f) === b) return f;
            return -1
        },
        join: function(a, b) {
            for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
            return c.join(b)
        },
        lastIndexOf: function(a, b, c) {
            var d = this.length(),
                e = d - 1;
            c !== void 0 && (e = c < 0 ? d + c : Math.min(c, e));
            for (var f = e; f >= 0; f--)
                if (this.has(f) && this.get(f) === b) return f;
            return -1
        },
        map: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && (d[e] = b.invoke(a, this.get(e), e, this));
            return new wd(d)
        },
        pop: function() {
            return this.pop()
        },
        push: function(a) {
            return this.push.apply(this,
                Aa(Ea.apply(1, arguments)))
        },
        reduce: function(a, b, c) {
            var d = this.length(),
                e, f = 0;
            if (c !== void 0) e = c;
            else {
                if (d === 0) throw Ua(Error("TypeError: Reduce on List with no elements."));
                for (var g = 0; g < d; g++)
                    if (this.has(g)) {
                        e = this.get(g);
                        f = g + 1;
                        break
                    }
                if (g === d) throw Ua(Error("TypeError: Reduce on List with no elements."));
            }
            for (var h = f; h < d; h++) this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
            return e
        },
        reduceRight: function(a, b, c) {
            var d = this.length(),
                e, f = d - 1;
            if (c !== void 0) e = c;
            else {
                if (d === 0) throw Ua(Error("TypeError: ReduceRight on List with no elements."));
                for (var g = 1; g <= d; g++)
                    if (this.has(d - g)) {
                        e = this.get(d - g);
                        f = d - (g + 1);
                        break
                    }
                if (g > d) throw Ua(Error("TypeError: ReduceRight on List with no elements."));
            }
            for (var h = f; h >= 0; h--) this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
            return e
        },
        reverse: function() {
            for (var a = xd(this), b = a.length - 1, c = 0; b >= 0; b--, c++) a.hasOwnProperty(b) ? this.set(c, a[b]) : this.remove(c);
            return this
        },
        shift: function() {
            return this.shift()
        },
        slice: function(a, b, c) {
            var d = this.length();
            b === void 0 && (b = 0);
            b = b < 0 ? Math.max(d + b, 0) : Math.min(b, d);
            c = c ===
                void 0 ? d : c < 0 ? Math.max(d + c, 0) : Math.min(c, d);
            c = Math.max(b, c);
            for (var e = [], f = b; f < c; f++) e.push(this.get(f));
            return new wd(e)
        },
        some: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
                if (this.has(d) && b.invoke(a, this.get(d), d, this)) return !0;
            return !1
        },
        sort: function(a, b) {
            var c = xd(this);
            b === void 0 ? c.sort() : c.sort(function(e, f) {
                return Number(b.invoke(a, e, f))
            });
            for (var d = 0; d < c.length; d++) c.hasOwnProperty(d) ? this.set(d, c[d]) : this.remove(d);
            return this
        },
        splice: function(a, b, c) {
            return this.splice.apply(this, [b, c].concat(Aa(Ea.apply(3, arguments))))
        },
        toString: function() {
            return this.toString()
        },
        unshift: function(a) {
            return this.unshift.apply(this, Aa(Ea.apply(1, arguments)))
        }
    };
    var Kd = {
            charAt: 1,
            concat: 1,
            indexOf: 1,
            lastIndexOf: 1,
            match: 1,
            replace: 1,
            search: 1,
            slice: 1,
            split: 1,
            substring: 1,
            toLowerCase: 1,
            toLocaleLowerCase: 1,
            toString: 1,
            toUpperCase: 1,
            toLocaleUpperCase: 1,
            trim: 1
        },
        Ld = new Ha("break"),
        Md = new Ha("continue");

    function Nd(a, b) {
        return this.evaluate(a) + this.evaluate(b)
    }

    function Od(a, b) {
        return this.evaluate(a) && this.evaluate(b)
    }

    function Pd(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (!(f instanceof wd)) throw Error("Error: Non-List argument given to Apply instruction.");
        if (d === null || d === void 0) throw Ua(Error("TypeError: Can't read property " + e + " of " + d + "."));
        var g = typeof d === "number";
        if (typeof d === "boolean" || g) {
            if (e === "toString") {
                if (g && f.length()) {
                    var h = B(f.get(0));
                    try {
                        return d.toString(h)
                    } catch (u) {}
                }
                return d.toString()
            }
            throw Ua(Error("TypeError: " + d + "." + e + " is not a function."));
        }
        if (typeof d ===
            "string") {
            if (Kd.hasOwnProperty(e)) {
                var l = 2;
                l = 1;
                var n = B(f, void 0, l);
                return Id(d[e].apply(d, n), this.J)
            }
            throw Ua(Error("TypeError: " + e + " is not a function"));
        }
        if (d instanceof wd) {
            if (d.has(e)) {
                var p = d.get(String(e));
                if (p instanceof Ad) {
                    var q = xd(f);
                    return Wa(17) ? p.apply(this.J, q) : p.invoke.apply(p, [this.J].concat(Aa(q)))
                }
                throw Ua(Error("TypeError: " + e + " is not a function"));
            }
            if (Jd.supportedMethods.indexOf(e) >= 0) {
                var r = xd(f);
                return Jd[e].call.apply(Jd[e], [d, this.J].concat(Aa(r)))
            }
        }
        if (d instanceof Ad || d instanceof bb || d instanceof Hd) {
            if (d.has(e)) {
                var v = d.get(e);
                if (v instanceof Ad) {
                    var t = xd(f);
                    return Wa(17) ? v.apply(this.J, t) : v.invoke.apply(v, [this.J].concat(Aa(t)))
                }
                throw Ua(Error("TypeError: " + e + " is not a function"));
            }
            if (e === "toString") return d instanceof Ad ? d.getName() : d.toString();
            if (e === "hasOwnProperty") return d.has(f.get(0))
        }
        if (d instanceof Fd && e === "toString") return d.toString();
        throw Ua(Error("TypeError: Object has no '" + e + "' property."));
    }

    function Qd(a, b) {
        a = this.evaluate(a);
        if (typeof a !== "string") throw Error("Invalid key name given for assignment.");
        var c = this.J;
        if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
        var d = this.evaluate(b);
        c.set(a, d);
        return d
    }

    function Rd() {
        var a = Ea.apply(0, arguments),
            b = this.J.lb(),
            c = Za(b, a);
        if (c instanceof Ha) return c
    }

    function Sd() {
        return Ld
    }

    function Td(a) {
        for (var b = this.evaluate(a), c = 0; c < b.length; c++) {
            var d = this.evaluate(b[c]);
            if (d instanceof Ha) return d
        }
    }

    function Ud() {
        for (var a = this.J, b = 0; b < arguments.length - 1; b += 2) {
            var c = arguments[b];
            if (typeof c === "string") {
                var d = this.evaluate(arguments[b + 1]);
                a.zh(c, d)
            }
        }
    }

    function Vd() {
        return Md
    }

    function Wd(a, b) {
        return new Ha(a, this.evaluate(b))
    }

    function Xd(a, b) {
        var c = Ea.apply(2, arguments),
            d;
        d = new wd;
        for (var e = this.evaluate(b), f = 0; f < e.length; f++) d.push(e[f]);
        var g = [51, a, d].concat(Aa(c));
        this.J.add(a, this.evaluate(g))
    }

    function Yd(a, b) {
        return this.evaluate(a) / this.evaluate(b)
    }

    function Zd(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b),
            e = c instanceof Fd,
            f = d instanceof Fd;
        return e || f ? e && f ? c.getValue() === d.getValue() : !1 : c == d
    }

    function $d() {
        for (var a, b = 0; b < arguments.length; b++) a = this.evaluate(arguments[b]);
        return a
    }

    function ae(a, b, c, d) {
        for (var e = 0; e < b(); e++) {
            var f = a(c(e)),
                g = Za(f, d);
            if (g instanceof Ha) {
                if (g.type === "break") break;
                if (g.type === "return") return g
            }
        }
    }

    function be(a, b, c) {
        if (typeof b === "string") return ae(a, function() {
            return b.length
        }, function(f) {
            return f
        }, c);
        if (b instanceof bb || b instanceof Hd || b instanceof wd || b instanceof Ad) {
            var d = b.Aa(),
                e = d.length;
            return ae(a, function() {
                return e
            }, function(f) {
                return d[f]
            }, c)
        }
    }

    function ce(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return be(function(h) {
            g.set(d, h);
            return g
        }, e, f)
    }

    function de(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return be(function(h) {
            var l = g.lb();
            l.zh(d, h);
            return l
        }, e, f)
    }

    function ee(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return be(function(h) {
            var l = g.lb();
            l.add(d, h);
            return l
        }, e, f)
    }

    function fe(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return ge(function(h) {
            g.set(d, h);
            return g
        }, e, f)
    }

    function he(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return ge(function(h) {
            var l = g.lb();
            l.zh(d, h);
            return l
        }, e, f)
    }

    function ie(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return ge(function(h) {
            var l = g.lb();
            l.add(d, h);
            return l
        }, e, f)
    }

    function ge(a, b, c) {
        if (typeof b === "string") return ae(a, function() {
            return b.length
        }, function(d) {
            return b[d]
        }, c);
        if (b instanceof wd) return ae(a, function() {
            return b.length()
        }, function(d) {
            return b.get(d)
        }, c);
        throw Ua(Error("The value is not iterable."));
    }

    function je(a, b, c, d) {
        function e(q, r) {
            for (var v = 0; v < f.length(); v++) {
                var t = f.get(v);
                r.add(t, q.get(t))
            }
        }
        var f = this.evaluate(a);
        if (!(f instanceof wd)) throw Error("TypeError: Non-List argument given to ForLet instruction.");
        var g = this.J,
            h = this.evaluate(d),
            l = g.lb();
        for (e(g, l); $a(l, b);) {
            var n = Za(l, h);
            if (n instanceof Ha) {
                if (n.type === "break") break;
                if (n.type === "return") return n
            }
            var p = g.lb();
            e(l, p);
            $a(p, c);
            l = p
        }
    }

    function ke(a, b) {
        var c = Ea.apply(2, arguments),
            d = this.J,
            e = this.evaluate(b);
        if (!(e instanceof wd)) throw Error("Error: non-List value given for Fn argument names.");
        return new Ad(a, function() {
            return function() {
                var f = Ea.apply(0, arguments),
                    g = d.lb();
                g.nb() === void 0 && g.Rd(this.J.nb());
                for (var h = [], l = 0; l < f.length; l++) {
                    var n = this.evaluate(f[l]);
                    h[l] = n
                }
                for (var p = e.get("length"), q = 0; q < p; q++) q < h.length ? g.add(e.get(q), h[q]) : g.add(e.get(q), void 0);
                g.add("arguments", new wd(h));
                var r = Za(g, c);
                if (r instanceof Ha) return r.type ===
                    "return" ? r.data : r
            }
        }())
    }

    function le(a) {
        var b = this.evaluate(a),
            c = this.J;
        if (me && !c.has(b)) throw new ReferenceError(b + " is not defined.");
        return c.get(b)
    }

    function ne(a, b) {
        var c, d = this.evaluate(a),
            e = this.evaluate(b);
        if (d === void 0 || d === null) throw Ua(Error("TypeError: Cannot read properties of " + d + " (reading '" + e + "')"));
        if (d instanceof bb || d instanceof Hd || d instanceof wd || d instanceof Ad) c = d.get(e);
        else if (typeof d === "string") e === "length" ? c = d.length : vd(e) && (c = d[e]);
        else if (d instanceof Fd) return;
        return c
    }

    function oe(a, b) {
        return this.evaluate(a) > this.evaluate(b)
    }

    function pe(a, b) {
        return this.evaluate(a) >= this.evaluate(b)
    }

    function qe(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        c instanceof Fd && (c = c.getValue());
        d instanceof Fd && (d = d.getValue());
        return c === d
    }

    function re(a, b) {
        return !qe.call(this, a, b)
    }

    function se(a, b, c) {
        var d = [];
        this.evaluate(a) ? d = this.evaluate(b) : c && (d = this.evaluate(c));
        var e = Za(this.J, d);
        if (e instanceof Ha) return e
    }
    var me = !1;

    function te(a, b) {
        return this.evaluate(a) < this.evaluate(b)
    }

    function ue(a, b) {
        return this.evaluate(a) <= this.evaluate(b)
    }

    function ve() {
        for (var a = new wd, b = 0; b < arguments.length; b++) {
            var c = this.evaluate(arguments[b]);
            a.push(c)
        }
        return a
    }

    function we() {
        for (var a = new bb, b = 0; b < arguments.length - 1; b += 2) {
            var c = String(this.evaluate(arguments[b])),
                d = this.evaluate(arguments[b + 1]);
            a.set(c, d)
        }
        return a
    }

    function xe(a, b) {
        return this.evaluate(a) % this.evaluate(b)
    }

    function ye(a, b) {
        return this.evaluate(a) * this.evaluate(b)
    }

    function ze(a) {
        return -this.evaluate(a)
    }

    function Ae(a) {
        return !this.evaluate(a)
    }

    function Be(a, b) {
        return !Zd.call(this, a, b)
    }

    function Ce() {
        return null
    }

    function De(a, b) {
        return this.evaluate(a) || this.evaluate(b)
    }

    function Ee(a, b) {
        var c = this.evaluate(a);
        this.evaluate(b);
        return c
    }

    function Fe(a) {
        return this.evaluate(a)
    }

    function Ge() {
        return Ea.apply(0, arguments)
    }

    function He(a) {
        return new Ha("return", this.evaluate(a))
    }

    function Ie(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (d === null || d === void 0) throw Ua(Error("TypeError: Can't set property " + e + " of " + d + "."));
        (d instanceof Ad || d instanceof wd || d instanceof bb) && d.set(String(e), f);
        return f
    }

    function Je(a, b) {
        return this.evaluate(a) - this.evaluate(b)
    }

    function Ke(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (!Array.isArray(e) || !Array.isArray(f)) throw Error("Error: Malformed switch instruction.");
        for (var g, h = !1, l = 0; l < e.length; l++)
            if (h || d === this.evaluate(e[l]))
                if (g = this.evaluate(f[l]), g instanceof Ha) {
                    var n = g.type;
                    if (n === "break") return;
                    if (n === "return" || n === "continue") return g
                } else h = !0;
        if (f.length === e.length + 1 && (g = this.evaluate(f[f.length - 1]), g instanceof Ha && (g.type === "return" || g.type === "continue"))) return g
    }

    function Le(a, b, c) {
        return this.evaluate(a) ? this.evaluate(b) : this.evaluate(c)
    }

    function Me(a) {
        var b = this.evaluate(a);
        return b instanceof Ad ? "function" : typeof b
    }

    function Ne() {
        for (var a = this.J, b = 0; b < arguments.length; b++) {
            var c = arguments[b];
            typeof c !== "string" || a.add(c, void 0)
        }
    }

    function Oe(a, b, c, d) {
        var e = this.evaluate(d);
        if (this.evaluate(c)) {
            var f = Za(this.J, e);
            if (f instanceof Ha) {
                if (f.type === "break") return;
                if (f.type === "return") return f
            }
        }
        for (; this.evaluate(a);) {
            var g = Za(this.J, e);
            if (g instanceof Ha) {
                if (g.type === "break") break;
                if (g.type === "return") return g
            }
            this.evaluate(b)
        }
    }

    function Pe(a) {
        return ~Number(this.evaluate(a))
    }

    function Qe(a, b) {
        return Number(this.evaluate(a)) << Number(this.evaluate(b))
    }

    function Re(a, b) {
        return Number(this.evaluate(a)) >> Number(this.evaluate(b))
    }

    function Se(a, b) {
        return Number(this.evaluate(a)) >>> Number(this.evaluate(b))
    }

    function Te(a, b) {
        return Number(this.evaluate(a)) & Number(this.evaluate(b))
    }

    function Ue(a, b) {
        return Number(this.evaluate(a)) ^ Number(this.evaluate(b))
    }

    function Ve(a, b) {
        return Number(this.evaluate(a)) | Number(this.evaluate(b))
    }

    function We() {}

    function Xe(a, b, c) {
        try {
            var d = this.evaluate(b);
            if (d instanceof Ha) return d
        } catch (h) {
            if (!(h instanceof Sa && h.Qm)) throw h;
            var e = this.J.lb();
            a !== "" && (h instanceof Sa && (h = h.ln), e.add(a, new Fd(h)));
            var f = this.evaluate(c),
                g = Za(e, f);
            if (g instanceof Ha) return g
        }
    }

    function Ye(a, b) {
        var c, d;
        try {
            d = this.evaluate(a)
        } catch (f) {
            if (!(f instanceof Sa && f.Qm)) throw f;
            c = f
        }
        var e = this.evaluate(b);
        if (e instanceof Ha) return e;
        if (c) throw c;
        if (d instanceof Ha) return d
    };
    var $e = function() {
        this.C = new ab;
        Ze(this)
    };
    $e.prototype.execute = function(a) {
        return this.C.Oj(a)
    };
    var Ze = function(a) {
        var b = function(c, d) {
            var e = new Bd(String(c), d);
            e.Ta();
            var f = String(c);
            a.C.C.set(f, e);
            Xa.set(f, e)
        };
        b("map", we);
        b("and", jd);
        b("contains", md);
        b("equals", kd);
        b("or", ld);
        b("startsWith", nd);
        b("variable", od)
    };
    $e.prototype.Lb = function(a) {
        this.C.Lb(a)
    };
    var bf = function() {
        this.H = !1;
        this.C = new ab;
        af(this);
        this.H = !0
    };
    bf.prototype.execute = function(a) {
        return cf(this.C.Oj(a))
    };
    var df = function(a, b, c) {
        return cf(a.C.mp(b, c))
    };
    bf.prototype.Ta = function() {
        this.C.Ta()
    };
    var af = function(a) {
        var b = function(c, d) {
            var e = String(c),
                f = new Bd(e, d);
            f.Ta();
            a.C.C.set(e, f);
            Xa.set(e, f)
        };
        b(0, Nd);
        b(1, Od);
        b(2, Pd);
        b(3, Qd);
        b(56, Te);
        b(57, Qe);
        b(58, Pe);
        b(59, Ve);
        b(60, Re);
        b(61, Se);
        b(62, Ue);
        b(53, Rd);
        b(4, Sd);
        b(5, Td);
        b(68, Xe);
        b(52, Ud);
        b(6, Vd);
        b(49, Wd);
        b(7, ve);
        b(8, we);
        b(9, Td);
        b(50, Xd);
        b(10, Yd);
        b(12, Zd);
        b(13, $d);
        b(67, Ye);
        b(51, ke);
        b(47, ce);
        b(54, de);
        b(55, ee);
        b(63, je);
        b(64, fe);
        b(65, he);
        b(66, ie);
        b(15, le);
        b(16, ne);
        b(17, ne);
        b(18, oe);
        b(19, pe);
        b(20, qe);
        b(21, re);
        b(22, se);
        b(23, te);
        b(24, ue);
        b(25, xe);
        b(26,
            ye);
        b(27, ze);
        b(28, Ae);
        b(29, Be);
        b(45, Ce);
        b(30, De);
        b(32, Ee);
        b(33, Ee);
        b(34, Fe);
        b(35, Fe);
        b(46, Ge);
        b(36, He);
        b(43, Ie);
        b(37, Je);
        b(38, Ke);
        b(39, Le);
        b(40, Me);
        b(44, We);
        b(41, Ne);
        b(42, Oe)
    };
    bf.prototype.Jd = function() {
        return this.C.Jd()
    };
    bf.prototype.Lb = function(a) {
        this.C.Lb(a)
    };
    bf.prototype.Yc = function(a) {
        this.C.Yc(a)
    };

    function cf(a) {
        if (a instanceof Ha || a instanceof Ad || a instanceof wd || a instanceof bb || a instanceof Hd || a instanceof Fd || a === null || a === void 0 || typeof a === "string" || typeof a === "number" || typeof a === "boolean") return a
    };
    var ef = function(a) {
        this.message = a
    };

    function ff(a) {
        a.Us = !0;
        return a
    };
    var gf = ff(function(a) {
        return typeof a === "string"
    });

    function hf(a) {
        var b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [a];
        return b === void 0 ? new ef("Value " + a + " can not be encoded in web-safe base64 dictionary.") : b
    };

    function jf(a) {
        switch (a) {
            case 1:
                return "1";
            case 2:
            case 4:
                return "0";
            default:
                return "-"
        }
    };
    var kf = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;

    function lf(a, b) {
        for (var c = "", d = !0; a > 7;) {
            var e = a & 31;
            a >>= 5;
            d ? d = !1 : e |= 32;
            c = "" + hf(e) + c
        }
        a <<= 2;
        d || (a |= 32);
        return c = "" + hf(a | b) + c
    }

    function mf(a, b) {
        var c;
        var d = a.Ph,
            e = a.Dj;
        d === void 0 ? c = "" : (e || (e = 0), c = "" + lf(1, 1) + hf(d << 2 | e));
        var f = a.Rp,
            g = "4" + c + (f ? "" + lf(2, 1) + hf(f) : ""),
            h, l = a.xn;
        h = l && kf.test(l) ? "" + lf(3, 2) + l : "";
        var n, p = a.un;
        n = p ? "" + lf(4, 1) + hf(p) : "";
        var q;
        var r = a.ctid;
        if (r && b) {
            var v = lf(5, 3),
                t = r.split("-"),
                u = t[0].toUpperCase();
            if (u !== "GTM" && u !== "OPT") q = "";
            else {
                var x = t[1];
                q = "" + v + hf(1 + x.length) + (a.Sq || 0) + x
            }
        } else q = "";
        var y = a.Fr,
            z = a.canonicalId,
            D = a.Pa,
            E = a.Ys,
            L = g + h + n + q + (y ? "" + lf(6, 1) + hf(y) : "") + (z ? "" + lf(7, 3) + hf(z.length) + z : "") + (D ? "" + lf(8, 3) +
                hf(D.length) + D : "") + (E ? "" + lf(9, 3) + hf(E.length) + E : ""),
            G;
        var O = a.Xp;
        O = O === void 0 ? {} : O;
        for (var W = [], ia = m(Object.keys(O)), T = ia.next(); !T.done; T = ia.next()) {
            var ca = T.value;
            W[Number(ca)] = O[ca]
        }
        if (W.length) {
            var va = lf(10, 3),
                ka;
            if (W.length === 0) ka = hf(0);
            else {
                for (var Z = [], V = 0, ja = !1, ta = 0; ta < W.length; ta++) {
                    ja = !0;
                    var ua = ta % 6;
                    W[ta] && (V |= 1 << ua);
                    ua === 5 && (Z.push(hf(V)), V = 0, ja = !1)
                }
                ja && Z.push(hf(V));
                ka = Z.join("")
            }
            var Ta = ka;
            G = "" + va + hf(Ta.length) + Ta
        } else G = "";
        var Ya = a.Zq,
            Lb = a.vr,
            Mb = a.Gr;
        return L + G + (Ya ? "" + lf(11, 3) + hf(Ya.length) +
            Ya : "") + (Lb ? "" + lf(13, 3) + hf(Lb.length) + Lb : "") + (Mb ? "" + lf(14, 1) + hf(Mb) : "")
    };
    var nf = function() {
        function a(b) {
            return {
                toString: function() {
                    return b
                }
            }
        }
        return {
            Pn: a("consent"),
            mk: a("convert_case_to"),
            nk: a("convert_false_to"),
            pk: a("convert_null_to"),
            qk: a("convert_true_to"),
            rk: a("convert_undefined_to"),
            Ur: a("debug_mode_metadata"),
            Ra: a("function"),
            oh: a("instance_name"),
            qp: a("live_only"),
            rp: a("malware_disabled"),
            METADATA: a("metadata"),
            vp: a("original_activity_id"),
            As: a("original_vendor_template_id"),
            zs: a("once_on_load"),
            up: a("once_per_event"),
            om: a("once_per_load"),
            Cs: a("priority_override"),
            Fs: a("respected_consent_types"),
            xm: a("setup_tags"),
            yh: a("tag_id"),
            Hm: a("teardown_tags")
        }
    }();
    var Jf;
    var Kf = [],
        Lf = [],
        Mf = [],
        Nf = [],
        Of = [],
        Pf, Qf, Rf;

    function Sf(a) {
        Rf = Rf || a
    }

    function Tf() {
        for (var a = data.resource || {}, b = a.macros || [], c = 0; c < b.length; c++) Kf.push(b[c]);
        for (var d = a.tags || [], e = 0; e < d.length; e++) Nf.push(d[e]);
        for (var f = a.predicates || [], g = 0; g < f.length; g++) Mf.push(f[g]);
        for (var h = a.rules || [], l = 0; l < h.length; l++) {
            for (var n = h[l], p = {}, q = 0; q < n.length; q++) {
                var r = n[q][0];
                p[r] = Array.prototype.slice.call(n[q], 1);
                r !== "if" && r !== "unless" || Uf(p[r])
            }
            Lf.push(p)
        }
    }

    function Uf(a) {}
    var Vf, Wf = [],
        Xf = [];

    function Yf(a, b) {
        var c = {};
        c[nf.Ra] = "__" + a;
        for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
        return c
    }

    function Zf(a, b, c) {
        try {
            return Qf($f(a, b, c))
        } catch (d) {
            JSON.stringify(a)
        }
        return 2
    }
    var $f = function(a, b, c) {
            c = c || [];
            var d = {},
                e;
            for (e in a) a.hasOwnProperty(e) && (d[e] = ag(a[e], b, c));
            return d
        },
        ag = function(a, b, c) {
            if (Array.isArray(a)) {
                var d;
                switch (a[0]) {
                    case "function_id":
                        return a[1];
                    case "list":
                        d = [];
                        for (var e = 1; e < a.length; e++) d.push(ag(a[e], b, c));
                        return d;
                    case "macro":
                        var f = a[1];
                        if (c[f]) return;
                        var g = Kf[f];
                        if (!g || b.isBlocked(g)) return;
                        c[f] = !0;
                        var h = String(g[nf.oh]);
                        try {
                            var l = $f(g, b, c);
                            l.vtp_gtmEventId = b.id;
                            b.priorityId && (l.vtp_gtmPriorityId = b.priorityId);
                            d = bg(l, {
                                event: b,
                                index: f,
                                type: 2,
                                name: h
                            });
                            Vf && (d = Vf.Yp(d, l))
                        } catch (z) {
                            b.logMacroError && b.logMacroError(z, Number(f), h), d = !1
                        }
                        c[f] = !1;
                        return d;
                    case "map":
                        d = {};
                        for (var n = 1; n < a.length; n += 2) d[ag(a[n], b, c)] = ag(a[n + 1], b, c);
                        return d;
                    case "template":
                        d = [];
                        for (var p = !1, q = 1; q < a.length; q++) {
                            var r = ag(a[q], b, c);
                            Rf && (p = p || Rf.Oq(r));
                            d.push(r)
                        }
                        return Rf && p ? Rf.fq(d) : d.join("");
                    case "escape":
                        d = ag(a[1], b, c);
                        if (Rf && Array.isArray(a[1]) && a[1][0] === "macro" && Rf.Pq(a)) return Rf.jr(d);
                        d = String(d);
                        for (var v = 2; v < a.length; v++) uf[a[v]] && (d = uf[a[v]](d));
                        return d;
                    case "tag":
                        var t = a[1];
                        if (!Nf[t]) throw Error("Unable to resolve tag reference " + t + ".");
                        return {
                            Vm: a[2],
                            index: t
                        };
                    case "zb":
                        var u = {
                            arg0: a[2],
                            arg1: a[3],
                            ignore_case: a[5]
                        };
                        u[nf.Ra] = a[1];
                        var x = Zf(u, b, c),
                            y = !!a[4];
                        return y || x !== 2 ? y !== (x === 1) : null;
                    default:
                        throw Error("Attempting to expand unknown Value type: " + a[0] + ".");
                }
            }
            return a
        },
        bg = function(a, b) {
            var c = a[nf.Ra],
                d = b && b.event;
            if (!c) throw Error("Error: No function name given for function call.");
            var e = Pf[c],
                f = b && b.type === 2 && (d == null ? void 0 : d.reportMacroDiscrepancy) &&
                e && Wf.indexOf(c) !== -1,
                g = {},
                h = {},
                l;
            for (l in a) a.hasOwnProperty(l) && Jb(l, "vtp_") && (e && (g[l] = a[l]), !e || f) && (h[l.substring(4)] = a[l]);
            e && d && d.cachedModelValues && (g.vtp_gtmCachedValues = d.cachedModelValues);
            if (b) {
                if (b.name == null) {
                    var n;
                    a: {
                        var p = b.type,
                            q = b.index;
                        if (q == null) n = "";
                        else {
                            var r;
                            switch (p) {
                                case 2:
                                    r = Kf[q];
                                    break;
                                case 1:
                                    r = Nf[q];
                                    break;
                                default:
                                    n = "";
                                    break a
                            }
                            var v = r && r[nf.oh];
                            n = v ? String(v) : ""
                        }
                    }
                    b.name = n
                }
                e && (g.vtp_gtmEntityIndex = b.index, g.vtp_gtmEntityName = b.name)
            }
            var t, u, x;
            if (f && Xf.indexOf(c) === -1) {
                Xf.push(c);
                var y = Eb();
                t = e(g);
                var z = Eb() - y,
                    D = Eb();
                u = Jf(c, h, b);
                x = z - (Eb() - D)
            } else if (e && (t = e(g)), !e || f) u = Jf(c, h, b);
            f && d && (d.reportMacroDiscrepancy(d.id, c, void 0, !0), ud(t) ? (Array.isArray(t) ? Array.isArray(u) : sd(t) ? sd(u) : typeof t === "function" ? typeof u === "function" : t === u) || d.reportMacroDiscrepancy(d.id, c) : t !== u && d.reportMacroDiscrepancy(d.id, c), x !== void 0 && d.reportMacroDiscrepancy(d.id, c, x));
            return e ? t : u
        };

    function cg(a) {
        var b;
        b = b === void 0 ? !1 : b;
        var c, d;
        return ((c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)) ? !!data.blob[a] : b
    }

    function C(a) {
        var b;
        b = b === void 0 ? "" : b;
        var c, d;
        return ((c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)) ? String(data.blob[a]) : b
    }

    function dg(a) {
        var b, c;
        return ((b = data) == null ? 0 : (c = b.blob) == null ? 0 : c.hasOwnProperty(a)) ? Number(data.blob[a]) : 0
    }

    function eg(a) {
        var b;
        b = b === void 0 ? "" : b;
        var c = fg(46);
        return c && (c == null ? 0 : c.hasOwnProperty(a)) ? String(c[a]) : b
    }

    function gg(a, b) {
        var c = fg(46);
        return c && (c == null ? 0 : c.hasOwnProperty(a)) ? Number(c[a]) : b
    }

    function fg(a) {
        var b, c;
        return (b = data) == null ? void 0 : (c = b.blob) == null ? void 0 : c[a]
    };
    var hg = function(a, b, c) {
        var d;
        d = Error.call(this, c);
        this.message = d.message;
        "stack" in d && (this.stack = d.stack);
        this.permissionId = a;
        this.parameters = b;
        this.name = "PermissionError"
    };
    ya(hg, Error);
    hg.prototype.getMessage = function() {
        return this.message
    };

    function ig(a, b) {
        if (Array.isArray(a)) {
            Object.defineProperty(a, "context", {
                value: {
                    line: b[0]
                }
            });
            for (var c = 1; c < a.length; c++) ig(a[c], b[c])
        }
    };

    function jg() {
        return function(a, b) {
            var c;
            var d = kg;
            a instanceof Sa ? (a.C = d, c = a) : c = new Sa(a, d);
            var e = c;
            b && e.debugInfo.push(b);
            throw e;
        }
    }

    function kg(a) {
        if (!a.length) return a;
        a.push({
            id: "main",
            line: 0
        });
        for (var b = a.length - 1; b > 0; b--) rb(a[b].id) && a.splice(b++, 1);
        for (var c = a.length - 1; c > 0; c--) a[c].line = a[c - 1].line;
        a.splice(0, 1);
        return a
    };

    function lg(a) {
        function b(r) {
            for (var v = 0; v < r.length; v++) d[r[v]] = !0
        }
        for (var c = [], d = [], e = mg(a), f = 0; f < Lf.length; f++) {
            var g = Lf[f],
                h = ng(g, e);
            if (h) {
                for (var l = g.add || [], n = 0; n < l.length; n++) c[l[n]] = !0;
                b(g.block || [])
            } else h === null && b(g.block || []);
        }
        for (var p = [], q = 0; q < Nf.length; q++) c[q] && !d[q] && (p[q] = !0);
        return p
    }

    function ng(a, b) {
        for (var c = a["if"] || [], d = 0; d < c.length; d++) {
            var e = b(c[d]);
            if (e === 0) return !1;
            if (e === 2) return null
        }
        for (var f = a.unless || [], g = 0; g < f.length; g++) {
            var h = b(f[g]);
            if (h === 2) return null;
            if (h === 1) return !1
        }
        return !0
    }

    function mg(a) {
        var b = [];
        return function(c) {
            b[c] === void 0 && (b[c] = Zf(Mf[c], a));
            return b[c]
        }
    };

    function og(a, b) {
        b[nf.mk] && typeof a === "string" && (a = b[nf.mk] === 1 ? a.toLowerCase() : a.toUpperCase());
        b.hasOwnProperty(nf.pk) && a === null && (a = b[nf.pk]);
        b.hasOwnProperty(nf.rk) && a === void 0 && (a = b[nf.rk]);
        b.hasOwnProperty(nf.qk) && a === !0 && (a = b[nf.qk]);
        b.hasOwnProperty(nf.nk) && a === !1 && (a = b[nf.nk]);
        return a
    };
    var pg = function() {
            this.C = {}
        },
        rg = function(a, b) {
            var c = qg.C,
                d;
            (d = c.C)[a] != null || (d[a] = []);
            c.C[a].push(function() {
                return b.apply(null, Aa(Ea.apply(0, arguments)))
            })
        };

    function sg(a, b, c, d) {
        if (a)
            for (var e = 0; e < a.length; e++) {
                var f = void 0,
                    g = "A policy function denied the permission request";
                try {
                    f = a[e](b, c, d), g += "."
                } catch (h) {
                    g = typeof h === "string" ? g + (": " + h) : h instanceof Error ? g + (": " + h.message) : g + "."
                }
                if (!f) throw new hg(c, d, g);
            }
    }

    function tg(a, b, c) {
        return function(d) {
            if (d) {
                var e = a.C[d],
                    f = a.C.all;
                if (e || f) {
                    var g = c.apply(void 0, [d].concat(Aa(Ea.apply(1, arguments))));
                    sg(e, b, d, g);
                    sg(f, b, d, g)
                }
            }
        }
    };
    var wg = function(a, b) {
            var c = this;
            this.H = {};
            this.C = new pg;
            var d = {},
                e = {},
                f = tg(this.C, a, function(g) {
                    return g && d[g] ? d[g].apply(void 0, [g].concat(Aa(Ea.apply(1, arguments)))) : {}
                });
            xb(b, function(g, h) {
                function l(p) {
                    var q = Ea.apply(1, arguments);
                    if (!n[p]) throw ug(p, {}, "The requested additional permission " + p + " is not configured.");
                    f.apply(null, [p].concat(Aa(q)))
                }
                var n = {};
                xb(h, function(p, q) {
                    var r = vg(p, q);
                    n[p] = r.assert;
                    d[p] || (d[p] = r.U);
                    r.Om && !e[p] && (e[p] = r.Om)
                });
                c.H[g] = function(p, q) {
                    var r = n[p];
                    if (!r) throw ug(p, {}, "The requested permission " + p + " is not configured.");
                    var v = Array.prototype.slice.call(arguments, 0);
                    r.apply(void 0, v);
                    f.apply(void 0, v);
                    var t = e[p];
                    t && t.apply(null, [l].concat(Aa(v.slice(1))))
                }
            })
        },
        xg = function(a) {
            return qg.H[a] || function() {}
        };

    function vg(a, b) {
        var c = Yf(a, b);
        c.vtp_permissionName = a;
        c.vtp_createPermissionError = ug;
        try {
            return bg(c)
        } catch (d) {
            return {
                assert: function(e) {
                    throw new hg(e, {}, "Permission " + e + " is unknown.");
                },
                U: function() {
                    throw new hg(a, {}, "Permission " + a + " is unknown.");
                }
            }
        }
    }

    function ug(a, b, c) {
        return new hg(a, b, c)
    };
    var yg = !1;
    var zg = {};
    zg.Pr = Ab('');
    zg.Ss = Ab('');
    var Eg = [];

    function Fg(a) {
        switch (a) {
            case 1:
                return 0;
            case 235:
                return 18;
            case 38:
                return 13;
            case 256:
                return 11;
            case 257:
                return 12;
            case 219:
                return 9;
            case 220:
                return 10;
            case 53:
                return 1;
            case 54:
                return 2;
            case 52:
                return 6;
            case 203:
                return 17;
            case 75:
                return 3;
            case 103:
                return 14;
            case 197:
                return 15;
            case 109:
                return 19;
            case 269:
                return 20;
            case 116:
                return 4;
            case 135:
                return 8;
            case 136:
                return 5
        }
    }

    function Gg(a, b) {
        Eg[a] = b;
        var c = Fg(a);
        c !== void 0 && (Va[c] = b)
    }

    function F(a) {
        Gg(a, !0)
    }
    F(39);
    F(145);
    F(153);
    F(144);
    F(120);
    F(5);
    F(111);
    F(139);
    F(87);
    F(92);
    F(159);
    F(132);
    F(20);
    F(72);
    F(113);
    F(154);
    F(116);
    Gg(23, !1), F(24);
    gg(6, 6E4);
    gg(7, 1);
    gg(35, 50);
    F(29);
    Hg(26, 25);
    F(37);
    F(9);
    F(91);
    F(123);
    F(158);
    F(71);
    F(136);
    F(127);
    F(27);
    F(69);
    F(135);
    F(95);
    F(38);
    F(103);
    F(112);
    F(101);
    F(122);
    F(121);
    F(21);
    F(134);
    F(22);
    F(141);
    F(90);
    F(59);
    F(175);
    F(177);
    F(185);
    F(197);
    F(200);
    F(206);
    F(218);
    F(231);
    F(232);
    F(241);
    F(250), F(241);
    F(260);
    F(269);

    function H(a) {
        return !!Eg[a]
    }

    function Hg(a, b) {
        for (var c = !1, d = !1, e = 0; c === d;)
            if (c = ((Math.random() * 4294967296 | 0) & 1) === 0, d = ((Math.random() * 4294967296 | 0) & 1) === 0, e++, e > 30) return;
        c ? F(b) : F(a)
    };
    var Jg = {
        O: {
            Xn: 1,
            ao: 2,
            Im: 3,
            rm: 4,
            xk: 5,
            yk: 6,
            hp: 7,
            bo: 8,
            fp: 9,
            Wn: 10,
            Vn: 11,
            Bm: 12,
            ym: 13,
            gk: 14,
            Jn: 15,
            Ln: 16,
            km: 17,
            zk: 18,
            im: 19,
            Yn: 20,
            tp: 21,
            On: 22,
            Kn: 23,
            Mn: 24,
            wk: 25,
            ek: 26,
            Bp: 27,
            Ql: 28,
            Yl: 29,
            Xl: 30,
            Wl: 31,
            Tl: 32,
            Rl: 33,
            Sl: 34,
            Pl: 35,
            Ol: 36
        }
    };
    Jg.O[Jg.O.Xn] = "CREATE_EVENT_SOURCE";
    Jg.O[Jg.O.ao] = "EDIT_EVENT";
    Jg.O[Jg.O.Im] = "TRAFFIC_TYPE";
    Jg.O[Jg.O.rm] = "REFERRAL_EXCLUSION";
    Jg.O[Jg.O.xk] = "ECOMMERCE_FROM_GTM_TAG";
    Jg.O[Jg.O.yk] = "ECOMMERCE_FROM_GTM_UA_SCHEMA";
    Jg.O[Jg.O.hp] = "GA_SEND";
    Jg.O[Jg.O.bo] = "EM_FORM";
    Jg.O[Jg.O.fp] = "GA_GAM_LINK";
    Jg.O[Jg.O.Wn] = "CREATE_EVENT_AUTO_PAGE_PATH";
    Jg.O[Jg.O.Vn] = "CREATED_EVENT";
    Jg.O[Jg.O.Bm] = "SIDELOADED";
    Jg.O[Jg.O.ym] = "SGTM_LEGACY_CONFIGURATION";
    Jg.O[Jg.O.gk] = "CCD_EM_EVENT";
    Jg.O[Jg.O.Jn] = "AUTO_REDACT_EMAIL";
    Jg.O[Jg.O.Ln] = "AUTO_REDACT_QUERY_PARAM";
    Jg.O[Jg.O.km] = "MULTIPLE_PAGEVIEW_FROM_CONFIG";
    Jg.O[Jg.O.zk] = "EM_EVENT_SENT_BEFORE_CONFIG";
    Jg.O[Jg.O.im] = "LOADED_VIA_CST_OR_SIDELOADING";
    Jg.O[Jg.O.Yn] = "DECODED_PARAM_MATCH";
    Jg.O[Jg.O.tp] = "NON_DECODED_PARAM_MATCH";
    Jg.O[Jg.O.On] = "CCD_EVENT_SGTM";
    Jg.O[Jg.O.Kn] = "AUTO_REDACT_EMAIL_SGTM";
    Jg.O[Jg.O.Mn] = "AUTO_REDACT_QUERY_PARAM_SGTM";
    Jg.O[Jg.O.wk] = "DAILY_LIMIT_REACHED";
    Jg.O[Jg.O.ek] = "BURST_LIMIT_REACHED";
    Jg.O[Jg.O.Bp] = "SHARED_USER_ID_SET_AFTER_REQUEST";
    Jg.O[Jg.O.Ql] = "GA4_MULTIPLE_SESSION_COOKIES";
    Jg.O[Jg.O.Yl] = "INVALID_GA4_SESSION_COUNT";
    Jg.O[Jg.O.Xl] = "INVALID_GA4_LAST_EVENT_TIMESTAMP";
    Jg.O[Jg.O.Wl] = "INVALID_GA4_JOIN_TIMER";
    Jg.O[Jg.O.Tl] = "GA4_STALE_SESSION_COOKIE_SELECTED";
    Jg.O[Jg.O.Rl] = "GA4_SESSION_COOKIE_GS1_READ";
    Jg.O[Jg.O.Sl] = "GA4_SESSION_COOKIE_GS2_READ";
    Jg.O[Jg.O.Pl] = "GA4_DL_PARAM_RECOVERY_AVAILABLE";
    Jg.O[Jg.O.Ol] = "GA4_DL_PARAM_RECOVERY_APPLIED";
    var Kg = {},
        Lg = (Kg.uaa = !0, Kg.uab = !0, Kg.uafvl = !0, Kg.uamb = !0, Kg.uam = !0, Kg.uap = !0, Kg.uapv = !0, Kg.uaw = !0, Kg);
    var Tg = function(a, b) {
            for (var c = 0; c < b.length; c++) {
                var d = a,
                    e = b[c];
                if (!Rg.exec(e)) throw Error("Invalid key wildcard");
                var f = e.indexOf(".*"),
                    g = f !== -1 && f === e.length - 2,
                    h = g ? e.slice(0, e.length - 2) : e,
                    l;
                a: if (d.length === 0) l = !1;
                    else {
                        for (var n = d.split("."), p = 0; p < n.length; p++)
                            if (!Sg.exec(n[p])) {
                                l = !1;
                                break a
                            }
                        l = !0
                    }
                if (!l || h.length > d.length || !g && d.length !== e.length ? 0 : g ? Jb(d, h) && (d === h || d.charAt(h.length) === ".") : d === h) return !0
            }
            return !1
        },
        Sg = /^[a-z$_][\w-$]*$/i,
        Rg = /^(?:[a-z_$][a-z-_$0-9]*\.)*[a-z_$][a-z-_$0-9]*(?:\.\*)?$/i;
    var Ug = ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"];

    function Vg(a, b) {
        var c = String(a),
            d = String(b),
            e = c.length - d.length;
        return e >= 0 && c.indexOf(d, e) === e
    }

    function Wg(a, b) {
        return String(a).split(",").indexOf(String(b)) >= 0
    }
    var Xg = new wb;

    function Yg(a, b, c) {
        var d = c ? "i" : void 0;
        try {
            var e = String(b) + String(d),
                f = Xg.get(e);
            f || (f = new RegExp(b, d), Xg.set(e, f));
            return f.test(a)
        } catch (g) {
            return !1
        }
    }

    function Zg(a, b) {
        return String(a).indexOf(String(b)) >= 0
    }

    function $g(a, b) {
        return String(a) === String(b)
    }

    function ah(a, b) {
        return Number(a) >= Number(b)
    }

    function bh(a, b) {
        return Number(a) <= Number(b)
    }

    function ch(a, b) {
        return Number(a) > Number(b)
    }

    function dh(a, b) {
        return Number(a) < Number(b)
    }

    function eh(a, b) {
        return Jb(String(a), String(b))
    };
    var lh = /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|PixieMap|List|OpaqueValue)$/i,
        mh = {
            Fn: "function",
            PixieMap: "Object",
            List: "Array"
        };

    function nh(a, b) {
        for (var c = ["input:!*"], d = 0; d < c.length; d++) {
            var e = lh.exec(c[d]);
            if (!e) throw Error("Internal Error in " + a);
            var f = e[1],
                g = e[2] === "!",
                h = e[3],
                l = b[d];
            if (l == null) {
                if (g) throw Error("Error in " + a + ". Required argument " + f + " not supplied.");
            } else if (h !== "*") {
                var n = typeof l;
                l instanceof Ad ? n = "Fn" : l instanceof wd ? n = "List" : l instanceof bb ? n = "PixieMap" : l instanceof Hd ? n = "PixiePromise" : l instanceof Fd && (n = "OpaqueValue");
                if (n !== h) throw Error("Error in " + a + ". Argument " + f + " has type " + ((mh[n] || n) + ", which does not match required type ") +
                    ((mh[h] || h) + "."));
            }
        }
    }

    function I(a, b, c) {
        for (var d = [], e = m(c), f = e.next(); !f.done; f = e.next()) {
            var g = f.value;
            g instanceof Ad ? d.push("function") : g instanceof wd ? d.push("Array") : g instanceof bb ? d.push("Object") : g instanceof Hd ? d.push("Promise") : g instanceof Fd ? d.push("OpaqueValue") : d.push(typeof g)
        }
        return Error("Argument error in " + a + ". Expected argument types [" + (b.join(",") + "], but received [") + (d.join(",") + "]."))
    }

    function oh(a) {
        return a instanceof bb
    }

    function ph(a) {
        return oh(a) || a === null || qh(a)
    }

    function rh(a) {
        return a instanceof Ad
    }

    function sh(a) {
        return rh(a) || a === null || qh(a)
    }

    function th(a) {
        return a instanceof wd
    }

    function uh(a) {
        return a instanceof Fd
    }

    function vh(a) {
        return typeof a === "string"
    }

    function wh(a) {
        return vh(a) || a === null || qh(a)
    }

    function xh(a) {
        return typeof a === "boolean"
    }

    function yh(a) {
        return xh(a) || qh(a)
    }

    function zh(a) {
        return xh(a) || a === null || qh(a)
    }

    function Ah(a) {
        return typeof a === "number"
    }

    function qh(a) {
        return a === void 0
    };

    function Bh(a) {
        return "" + a
    }

    function Ch(a, b) {
        var c = [];
        return c
    };

    function Dh(a, b) {
        var c = new Ad(a, function() {
            for (var d = Array.prototype.slice.call(arguments, 0), e = 0; e < d.length; e++) d[e] = this.evaluate(d[e]);
            try {
                return b.apply(this, d)
            } catch (g) {
                throw Ua(g);
            }
        });
        c.Ta();
        return c
    }

    function Eh(a, b) {
        var c = new bb,
            d;
        for (d in b)
            if (b.hasOwnProperty(d)) {
                var e = b[d];
                pb(e) ? c.set(d, Dh(a + "_" + d, e)) : sd(e) ? c.set(d, Eh(a + "_" + d, e)) : (rb(e) || qb(e) || typeof e === "boolean") && c.set(d, e)
            }
        c.Ta();
        return c
    };

    function Fh(a, b) {
        if (!vh(a)) throw I(this.getName(), ["string"], arguments);
        if (!wh(b)) throw I(this.getName(), ["string", "undefined"], arguments);
        var c = {},
            d = new bb;
        return d = Eh("AssertApiSubject",
            c)
    };

    function Gh(a, b) {
        if (!wh(b)) throw I(this.getName(), ["string", "undefined"], arguments);
        if (a instanceof Hd) throw Error("Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported.");
        var c = {},
            d = new bb;
        return d = Eh("AssertThatSubject", c)
    };

    function Hh(a) {
        return function() {
            for (var b = Ea.apply(0, arguments), c = [], d = this.J, e = 0; e < b.length; ++e) c.push(B(b[e], d));
            return Id(a.apply(null, c))
        }
    }

    function Ih() {
        for (var a = Math, b = Jh, c = {}, d = 0; d < b.length; d++) {
            var e = b[d];
            a.hasOwnProperty(e) && (c[e] = Hh(a[e].bind(a)))
        }
        return c
    };

    function Kh(a) {
        return a != null && Jb(a, "__cvt_")
    };

    function Lh(a) {
        var b;
        return b
    };

    function Mh(a) {
        var b;
        if (!vh(a)) throw I(this.getName(), ["string"], arguments);
        try {
            b = decodeURIComponent(a)
        } catch (c) {}
        return b
    };

    function Nh(a) {
        try {
            return encodeURI(a)
        } catch (b) {}
    };

    function Oh(a) {
        try {
            return encodeURIComponent(String(a))
        } catch (b) {}
    };

    function Uh(a) {
        if (!wh(a)) throw I(this.getName(), ["string|undefined"], arguments);
    };

    function Vh(a) {
        var b = 1,
            c, d, e;
        if (a)
            for (b = 0, d = a.length - 1; d >= 0; d--) e = a.charCodeAt(d), b = (b << 6 & 268435455) + e + (e << 14), c = b & 266338304, b = c !== 0 ? b ^ c >> 21 : b;
        return b
    };

    function Wh(a) {
        var b = B(a);
        return Vh(b ? "" + b : "")
    };

    function Xh(a, b) {
        if (!Ah(a) || !Ah(b)) throw I(this.getName(), ["number", "number"], arguments);
        return ub(a, b)
    };

    function Yh() {
        return (new Date).getTime()
    };

    function Zh(a) {
        if (a === null) return "null";
        if (a instanceof wd) return "array";
        if (a instanceof Ad) return "function";
        if (a instanceof Fd) {
            var b = a.getValue();
            if ((b == null ? void 0 : b.constructor) === void 0 || b.constructor.name === void 0) {
                var c = String(b);
                return c.substring(8, c.length - 1)
            }
            return String(b.constructor.name)
        }
        return typeof a
    };

    function $h(a) {
        function b(c) {
            return function(d) {
                try {
                    return c(d)
                } catch (e) {
                    (yg || zg.Pr) && a.call(this, e.message)
                }
            }
        }
        return {
            parse: b(function(c) {
                return Id(JSON.parse(c))
            }),
            stringify: b(function(c) {
                return JSON.stringify(B(c))
            }),
            publicName: "JSON"
        }
    };

    function ai(a) {
        return zb(B(a, this.J))
    };

    function bi(a) {
        return Number(B(a, this.J))
    };

    function ci(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a.toString()
    };

    function di(a, b, c) {
        var d = null,
            e = !1;
        return e ? d : null
    };
    var Jh = "floor ceil round max min abs pow sqrt".split(" ");

    function ei() {
        var a = {};
        return {
            uq: function(b) {
                return a.hasOwnProperty(b) ? a[b] : void 0
            },
            An: function(b, c) {
                a[b] = c
            },
            reset: function() {
                a = {}
            }
        }
    }

    function fi(a, b) {
        return function() {
            return Ad.prototype.invoke.apply(a, [b].concat(Aa(Ea.apply(0, arguments))))
        }
    }

    function gi(a, b) {
        if (!vh(a)) throw I(this.getName(), ["string", "any"], arguments);
    }

    function hi(a, b) {
        if (!vh(a) || !oh(b)) throw I(this.getName(), ["string", "PixieMap"], arguments);
    };
    var ii = {};
    ii.keys = function(a) {
        return new wd
    };
    ii.values = function(a) {
        return new wd
    };
    ii.entries = function(a) {
        return new wd
    };
    ii.freeze = function(a) {
        return a
    };
    ii.delete = function(a, b) {
        return !1
    };

    function J(a, b) {
        var c = Ea.apply(2, arguments),
            d = a.J.nb();
        if (!d) throw Error("Missing program state.");
        if (d.rr) {
            try {
                d.Pm.apply(null, [b].concat(Aa(c)))
            } catch (e) {
                throw jb("TAGGING", 21), e;
            }
            return
        }
        d.Pm.apply(null, [b].concat(Aa(c)))
    };
    var ki = function() {
        this.H = {};
        this.C = {};
        this.P = !0;
    };
    ki.prototype.get = function(a, b) {
        var c = this.contains(a) ? this.H[a] : void 0;
        return c
    };
    ki.prototype.contains = function(a) {
        return this.H.hasOwnProperty(a)
    };
    ki.prototype.add = function(a, b, c) {
        if (this.contains(a)) throw Error("Attempting to add a function which already exists: " + a + ".");
        if (this.C.hasOwnProperty(a)) throw Error("Attempting to add an API with an existing private API name: " + a + ".");
        this.H[a] = c ? void 0 : pb(b) ? Dh(a, b) : Eh(a, b)
    };

    function li(a, b) {
        var c = void 0;
        return c
    };

    function mi() {
        var a = {};
        return a
    };
    var K = {
        m: {
            La: "ad_personalization",
            X: "ad_storage",
            W: "ad_user_data",
            ja: "analytics_storage",
            fc: "region",
            fa: "consent_updated",
            Gg: "wait_for_update",
            co: "app_remove",
            eo: "app_store_refund",
            fo: "app_store_subscription_cancel",
            ho: "app_store_subscription_convert",
            io: "app_store_subscription_renew",
            jo: "consent_update",
            Bk: "add_payment_info",
            Ck: "add_shipping_info",
            be: "add_to_cart",
            ce: "remove_from_cart",
            Dk: "view_cart",
            fd: "begin_checkout",
            de: "select_item",
            hc: "view_item_list",
            wc: "select_promotion",
            jc: "view_promotion",
            Ab: "purchase",
            ee: "refund",
            kc: "view_item",
            Ek: "add_to_wishlist",
            ko: "exception",
            lo: "first_open",
            mo: "first_visit",
            ma: "gtag.config",
            mc: "gtag.get",
            no: "in_app_purchase",
            gd: "page_view",
            oo: "screen_view",
            po: "session_start",
            qo: "source_update",
            ro: "timing_complete",
            so: "track_social",
            fe: "user_engagement",
            uo: "user_id_update",
            Xe: "gclid_link_decoration_source",
            Ye: "gclid_storage_source",
            nc: "gclgb",
            qb: "gclid",
            Fk: "gclid_len",
            he: "gclgs",
            ie: "gcllp",
            je: "gclst",
            Ha: "ads_data_redaction",
            Ze: "gad_source",
            af: "gad_source_src",
            hd: "gclid_url",
            Gk: "gclsrc",
            bf: "gbraid",
            ke: "wbraid",
            Nb: "allow_ad_personalization_signals",
            cf: "allow_custom_scripts",
            df: "allow_direct_google_requests",
            Mg: "allow_display_features",
            Yh: "allow_enhanced_conversions",
            Ob: "allow_google_signals",
            Zh: "allow_interest_groups",
            vo: "app_id",
            wo: "app_installer_id",
            xo: "app_name",
            yo: "app_version",
            jd: "auid",
            Yr: "auto_detection_enabled",
            Hk: "aw_remarketing",
            ai: "aw_remarketing_only",
            ef: "discount",
            ff: "aw_feed_country",
            hf: "aw_feed_language",
            Ca: "items",
            jf: "aw_merchant_id",
            bi: "aw_basket_type",
            kf: "campaign_content",
            lf: "campaign_id",
            nf: "campaign_medium",
            pf: "campaign_name",
            qf: "campaign",
            rf: "campaign_source",
            tf: "campaign_term",
            Pb: "client_id",
            Ik: "rnd",
            di: "consent_update_type",
            zo: "content_group",
            Ao: "content_type",
            Bb: "conversion_cookie_prefix",
            ei: "conversion_id",
            rb: "conversion_linker",
            fi: "conversion_linker_disabled",
            kd: "conversion_api",
            Ng: "cookie_deprecation",
            sb: "cookie_domain",
            tb: "cookie_expires",
            Cb: "cookie_flags",
            ld: "cookie_name",
            Qb: "cookie_path",
            Wa: "cookie_prefix",
            xc: "cookie_update",
            yc: "country",
            jb: "currency",
            Og: "customer_buyer_stage",
            ne: "customer_lifetime_value",
            Pg: "customer_loyalty",
            Qg: "customer_ltv_bucket",
            oe: "custom_map",
            Rg: "gcldc",
            md: "dclid",
            Jk: "debug_mode",
            Fa: "developer_id",
            Bo: "disable_merchant_reported_purchases",
            zc: "dc_custom_params",
            Kk: "dc_natural_search",
            Lk: "dynamic_event_settings",
            Mk: "affiliation",
            Sg: "checkout_option",
            gi: "checkout_step",
            Nk: "coupon",
            uf: "item_list_name",
            hi: "list_name",
            Co: "promotions",
            nd: "shipping",
            Ok: "tax",
            Tg: "engagement_time_msec",
            Ug: "enhanced_client_id",
            Do: "enhanced_conversions",
            Zr: "enhanced_conversions_automatic_settings",
            pe: "estimated_delivery_date",
            vf: "event_callback",
            Eo: "event_category",
            Ac: "event_developer_id_string",
            Fo: "event_label",
            Bc: "event",
            Vg: "event_settings",
            Wg: "event_timeout",
            Go: "description",
            Ho: "fatal",
            Io: "experiments",
            ji: "firebase_id",
            qe: "first_party_collection",
            Xg: "_x_20",
            oc: "_x_19",
            Jo: "flight_error_code",
            Ko: "flight_error_message",
            Pk: "fl_activity_category",
            Qk: "fl_activity_group",
            ki: "fl_advertiser_id",
            Rk: "fl_ar_dedupe",
            wf: "match_id",
            Sk: "fl_random_number",
            Tk: "tran",
            Uk: "u",
            Yg: "gac_gclid",
            se: "gac_wbraid",
            Vk: "gac_wbraid_multiple_conversions",
            Wk: "ga_restrict_domain",
            Xk: "ga_temp_client_id",
            Lo: "ga_temp_ecid",
            te: "gdpr_applies",
            Yk: "geo_granularity",
            xf: "value_callback",
            yf: "value_key",
            Dc: "google_analysis_params",
            ue: "_google_ng",
            ve: "google_signals",
            Zk: "google_tld",
            zf: "gpp_sid",
            Af: "gpp_string",
            Zg: "groups",
            al: "gsa_experiment_id",
            Bf: "gtag_event_feature_usage",
            bl: "gtm_up",
            Ec: "iframe_state",
            Cf: "ignore_referrer",
            li: "internal_traffic_results",
            fl: "_is_fpm",
            Fc: "is_legacy_converted",
            Gc: "is_legacy_loaded",
            mi: "is_passthrough",
            od: "_lps",
            kb: "language",
            ah: "legacy_developer_id_string",
            Xa: "linker",
            Df: "accept_incoming",
            Hc: "decorate_forms",
            na: "domains",
            pd: "url_position",
            Ic: "merchant_feed_label",
            Jc: "merchant_feed_language",
            Kc: "merchant_id",
            il: "method",
            Mo: "name",
            jl: "navigation_type",
            we: "new_customer",
            bh: "non_interaction",
            No: "optimize_id",
            kl: "page_hostname",
            Ef: "page_path",
            Ya: "page_referrer",
            Db: "page_title",
            Oo: "passengers",
            ml: "phone_conversion_callback",
            Po: "phone_conversion_country_code",
            nl: "phone_conversion_css_class",
            Qo: "phone_conversion_ids",
            ol: "phone_conversion_number",
            pl: "phone_conversion_options",
            Ro: "_platinum_request_status",
            So: "_protected_audience_enabled",
            xe: "quantity",
            eh: "redact_device_info",
            ni: "referral_exclusion_definition",
            bs: "_request_start_time",
            Rb: "restricted_data_processing",
            To: "retoken",
            Uo: "sample_rate",
            oi: "screen_name",
            Lc: "screen_resolution",
            ql: "_script_source",
            Vo: "search_term",
            rd: "send_page_view",
            sd: "send_to",
            ud: "server_container_url",
            Wo: "session_attributes_encoded",
            Ff: "session_duration",
            fh: "session_engaged",
            ri: "session_engaged_time",
            Sb: "session_id",
            gh: "session_number",
            Gf: "_shared_user_id",
            vd: "delivery_postal_code",
            ds: "_tag_firing_delay",
            es: "_tag_firing_time",
            hs: "temporary_client_id",
            si: "_timezone",
            ui: "topmost_url",
            hh: "tracking_id",
            wi: "traffic_type",
            Ma: "transaction_id",
            qc: "transport_url",
            Xo: "trip_type",
            wd: "update",
            Eb: "url_passthrough",
            rl: "uptgs",
            Hf: "_user_agent_architecture",
            If: "_user_agent_bitness",
            Jf: "_user_agent_full_version_list",
            Kf: "_user_agent_mobile",
            Lf: "_user_agent_model",
            Mf: "_user_agent_platform",
            Nf: "_user_agent_platform_version",
            Of: "_user_agent_wow64",
            ub: "user_data",
            sl: "user_data_auto_latency",
            tl: "user_data_auto_meta",
            vl: "user_data_auto_multi",
            wl: "user_data_auto_selectors",
            xl: "user_data_auto_status",
            Fb: "user_data_mode",
            yl: "user_data_settings",
            Na: "user_id",
            Tb: "user_properties",
            zl: "_user_region",
            Pf: "us_privacy_string",
            Ia: "value",
            Al: "wbraid_multiple_conversions",
            Mc: "_fpm_parameters",
            Ci: "_host_name",
            Zl: "_in_page_command",
            Ei: "_ip_override",
            fm: "_is_passthrough_cid",
            Li: "_measurement_type",
            Fd: "non_personalized_ads",
            Ti: "_sst_parameters",
            Ap: "sgtm_geo_user_country",
            me: "conversion_label",
            za: "page_location",
            ii: "_extracted_data",
            Cc: "global_developer_id_string",
            ye: "tc_privacy_string"
        }
    };
    var ni = {},
        oi = (ni[K.m.fa] = "gcu", ni[K.m.nc] = "gclgb", ni[K.m.qb] = "gclaw", ni[K.m.Fk] = "gclid_len", ni[K.m.he] = "gclgs", ni[K.m.ie] = "gcllp", ni[K.m.je] = "gclst", ni[K.m.jd] = "auid", ni[K.m.ef] = "dscnt", ni[K.m.ff] = "fcntr", ni[K.m.hf] = "flng", ni[K.m.jf] = "mid", ni[K.m.bi] = "bttype", ni[K.m.Pb] = "gacid", ni[K.m.me] = "label", ni[K.m.kd] = "capi", ni[K.m.Ng] = "pscdl", ni[K.m.jb] = "currency_code", ni[K.m.Og] = "clobs", ni[K.m.ne] = "vdltv", ni[K.m.Pg] = "clolo", ni[K.m.Qg] = "clolb", ni[K.m.Jk] = "_dbg", ni[K.m.pe] = "oedeld", ni[K.m.Ac] = "edid", ni[K.m.Yg] =
            "gac", ni[K.m.se] = "gacgb", ni[K.m.Vk] = "gacmcov", ni[K.m.te] = "gdpr", ni[K.m.Cc] = "gdid", ni[K.m.ue] = "_ng", ni[K.m.zf] = "gpp_sid", ni[K.m.Af] = "gpp", ni[K.m.al] = "gsaexp", ni[K.m.Bf] = "_tu", ni[K.m.Ec] = "frm", ni[K.m.mi] = "gtm_up", ni[K.m.od] = "lps", ni[K.m.ah] = "did", ni[K.m.Ic] = "fcntr", ni[K.m.Jc] = "flng", ni[K.m.Kc] = "mid", ni[K.m.we] = void 0, ni[K.m.Db] = "tiba", ni[K.m.Rb] = "rdp", ni[K.m.Sb] = "ecsid", ni[K.m.Gf] = "ga_uid", ni[K.m.vd] = "delopc", ni[K.m.ye] = "gdpr_consent", ni[K.m.Ma] = "oid", ni[K.m.rl] = "uptgs", ni[K.m.Hf] = "uaa", ni[K.m.If] =
            "uab", ni[K.m.Jf] = "uafvl", ni[K.m.Kf] = "uamb", ni[K.m.Lf] = "uam", ni[K.m.Mf] = "uap", ni[K.m.Nf] = "uapv", ni[K.m.Of] = "uaw", ni[K.m.sl] = "ec_lat", ni[K.m.tl] = "ec_meta", ni[K.m.vl] = "ec_m", ni[K.m.wl] = "ec_sel", ni[K.m.xl] = "ec_s", ni[K.m.Fb] = "ec_mode", ni[K.m.Na] = "userId", ni[K.m.Pf] = "us_privacy", ni[K.m.Ia] = "value", ni[K.m.Al] = "mcov", ni[K.m.Ci] = "hn", ni[K.m.Zl] = "gtm_ee", ni[K.m.Ei] = "uip", ni[K.m.Li] = "mt", ni[K.m.Fd] = "npa", ni[K.m.Ap] = "sg_uc", ni[K.m.ei] = null, ni[K.m.Lc] = null, ni[K.m.kb] = null, ni[K.m.Ca] = null, ni[K.m.za] = null, ni[K.m.Ya] =
            null, ni[K.m.ui] = null, ni[K.m.Mc] = null, ni[K.m.Xe] = null, ni[K.m.Ye] = null, ni[K.m.Dc] = null, ni[K.m.ii] = null, ni);

    function pi(a, b) {
        if (a) {
            var c = a.split("x");
            c.length === 2 && (qi(b, "u_w", c[0]), qi(b, "u_h", c[1]))
        }
    }

    function ri(a) {
        var b = si;
        b = b === void 0 ? ti : b;
        var c;
        var d = b;
        if (a && a.length) {
            for (var e = [], f = 0; f < a.length; ++f) {
                var g = a[f];
                g && e.push({
                    item_id: d(g),
                    quantity: g.quantity,
                    value: g.price,
                    start_date: g.start_date,
                    end_date: g.end_date
                })
            }
            c = e
        } else c = [];
        var h;
        var l = c;
        if (l) {
            for (var n = [], p = 0; p < l.length; p++) {
                var q = l[p],
                    r = [];
                q && (r.push(ui(q.value)), r.push(ui(q.quantity)), r.push(ui(q.item_id)), r.push(ui(q.start_date)), r.push(ui(q.end_date)), n.push("(" + r.join("*") + ")"))
            }
            h = n.length > 0 ? n.join("") : ""
        } else h = "";
        return h
    }

    function ti(a) {
        return vi(a.item_id, a.id, a.item_name)
    }

    function vi() {
        for (var a = m(Ea.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            var c = b.value;
            if (c !== null && c !== void 0) return c
        }
    }

    function wi(a) {
        if (a && a.length) {
            for (var b = [], c = 0; c < a.length; ++c) {
                var d = a[c];
                d && d.estimated_delivery_date ? b.push("" + d.estimated_delivery_date) : b.push("")
            }
            return b.join(",")
        }
    }

    function qi(a, b, c) {
        c === void 0 || c === null || c === "" && !Lg[b] || (a[b] = c)
    }

    function ui(a) {
        return typeof a !== "number" && typeof a !== "string" ? "" : a.toString()
    };
    var xi = {},
        yi = function() {
            for (var a = !1, b = !1, c = 0; a === b;)
                if (a = ub(0, 1) === 0, b = ub(0, 1) === 0, c++, c > 30) return;
            return a
        },
        Ai = {
            yr: zi
        };

    function zi(a, b) {
        var c = xi[b];
        if (!(ub(0, 9999) < c.probability * (c.controlId2 ? 4 : 2) * 1E4)) return a;
        var d = c.studyId,
            e = c.experimentId,
            f = c.controlId,
            g = c.controlId2;
        if (!((a.exp || {})[e] || (a.exp || {})[f] || g && (a.exp || {})[g])) {
            var h = yi() ? 0 : 1;
            g && (h |= (yi() ? 0 : 1) << 1);
            h === 0 ? Bi(a, e, d) : h === 1 ? Bi(a, f, d) : h === 2 && Bi(a, g, d)
        }
        return a
    }

    function Ci(a, b) {
        return xi[b] ? !!xi[b].active || xi[b].probability > .5 || !!(a.exp || {})[xi[b].experimentId] : !1
    }

    function Di(a, b) {
        for (var c = a.exp || {}, d = m(Object.keys(c).map(Number)), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            if (c[f] === b) return f
        }
    }

    function Bi(a, b, c) {
        var d = a.exp || {};
        d[b] = c;
        a.exp = d
    };
    var M = {
        M: {
            fk: "call_conversion",
            Xd: "ccm_conversion",
            wa: "conversion",
            Yo: "floodlight",
            Rf: "ga_conversion",
            yd: "gcp_remarketing",
            Ki: "landing_page",
            Da: "page_view",
            Ee: "fpm_test_hit",
            xb: "remarketing",
            Ub: "user_data_lead",
            yb: "user_data_web"
        }
    };
    var Ji = function() {
            this.C = new Set;
            this.H = new Set
        },
        Li = function(a) {
            var b = Ki.C;
            a = a === void 0 ? [] : a;
            var c = [].concat(Aa(b.C)).concat([].concat(Aa(b.H))).concat(a);
            c.sort(function(d, e) {
                return d - e
            });
            return c
        },
        Mi = function() {
            var a = [].concat(Aa(Ki.C.C));
            a.sort(function(b, c) {
                return b - c
            });
            return a
        },
        Ni = function() {
            var a = Ki.C,
                b = C(44);
            a.C = new Set;
            if (b !== "")
                for (var c = m(b.split("~")), d = c.next(); !d.done; d = c.next()) {
                    var e = Number(d.value);
                    isNaN(e) || a.C.add(e)
                }
        };
    var Oi = {},
        Pi = {
            __cl: 1,
            __ecl: 1,
            __ehl: 1,
            __evl: 1,
            __fal: 1,
            __fil: 1,
            __fsl: 1,
            __hl: 1,
            __jel: 1,
            __lcl: 1,
            __sdl: 1,
            __tl: 1,
            __ytl: 1
        },
        Qi = {
            __paused: 1,
            __tg: 1
        },
        Ri;
    for (Ri in Pi) Pi.hasOwnProperty(Ri) && (Qi[Ri] = 1);
    var Si = !1,
        Ti = cg(45),
        Ui, Vi = !1;
    Ui = Vi;
    var Wi = null,
        Xi = null,
        Yi = {},
        Zi = {},
        $i = "";
    Oi.Ui = $i;
    var Ki = new function() {
        this.C = new Ji;
        this.H = !1
    };

    function aj() {
        var a = C(18),
            b = a.length;
        return a[b - 1] === "/" ? a.substring(0, b - 1) : a
    }

    function bj() {
        if (!cg(47)) return !1;
        var a = dg(54);
        return H(84) ? a === 0 : a !== 1
    }

    function cj(a) {
        for (var b = {}, c = m(a.split("|")), d = c.next(); !d.done; d = c.next()) b[d.value] = !0;
        return b
    };
    var dj = /:[0-9]+$/,
        ej = /^\d+\.fls\.doubleclick\.net$/;

    function fj(a, b, c, d) {
        var e = gj(a, !!d, b),
            f, g;
        return c ? (g = e[b]) != null ? g : [] : (f = e[b]) == null ? void 0 : f[0]
    }

    function gj(a, b, c) {
        for (var d = {}, e = m(a.split("&")), f = e.next(); !f.done; f = e.next()) {
            var g = m(f.value.split("=")),
                h = g.next().value,
                l = za(g),
                n = decodeURIComponent(h.replace(/\+/g, " "));
            if (c === void 0 || n === c) {
                var p = l.join("=");
                d[n] || (d[n] = []);
                d[n].push(b ? p : decodeURIComponent(p.replace(/\+/g, " ")))
            }
        }
        return d
    }

    function hj(a) {
        try {
            return decodeURIComponent(a)
        } catch (b) {}
    }

    function ij(a, b, c, d, e) {
        b && (b = String(b).toLowerCase());
        if (b === "protocol" || b === "port") a.protocol = jj(a.protocol) || jj(w.location.protocol);
        b === "port" ? a.port = String(Number(a.hostname ? a.port : w.location.port) || (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")) : b === "host" && (a.hostname = (a.hostname || w.location.hostname).replace(dj, "").toLowerCase());
        return kj(a, b, c, d, e)
    }

    function kj(a, b, c, d, e) {
        var f, g = jj(a.protocol);
        b && (b = String(b).toLowerCase());
        switch (b) {
            case "url_no_fragment":
                f = lj(a);
                break;
            case "protocol":
                f = g;
                break;
            case "host":
                f = a.hostname.replace(dj, "").toLowerCase();
                if (c) {
                    var h = /^www\d*\./.exec(f);
                    h && h[0] && (f = f.substring(h[0].length))
                }
                break;
            case "port":
                f = String(Number(a.port) || (g === "http" ? 80 : g === "https" ? 443 : ""));
                break;
            case "path":
                a.pathname || a.hostname || jb("TAGGING", 1);
                f = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" + a.pathname;
                var l = f.split("/");
                (d || []).indexOf(l[l.length -
                    1]) >= 0 && (l[l.length - 1] = "");
                f = l.join("/");
                break;
            case "query":
                f = a.search.replace("?", "");
                e && (f = fj(f, e, !1));
                break;
            case "extension":
                var n = a.pathname.split(".");
                f = n.length > 1 ? n[n.length - 1] : "";
                f = f.split("/")[0];
                break;
            case "fragment":
                f = a.hash.replace("#", "");
                break;
            default:
                f = a && a.href
        }
        return f
    }

    function jj(a) {
        return a ? a.replace(":", "").toLowerCase() : ""
    }

    function lj(a) {
        var b = "";
        if (a && a.href) {
            var c = a.href.indexOf("#");
            b = c < 0 ? a.href : a.href.substring(0, c)
        }
        return b
    }
    var mj = {},
        nj = 0;

    function oj(a) {
        var b = mj[a];
        if (!b) {
            var c = A.createElement("a");
            a && (c.href = a);
            var d = c.pathname;
            d[0] !== "/" && (a || jb("TAGGING", 1), d = "/" + d);
            var e = c.hostname.replace(dj, "");
            b = {
                href: c.href,
                protocol: c.protocol,
                host: c.host,
                hostname: e,
                pathname: d,
                search: c.search,
                hash: c.hash,
                port: c.port
            };
            nj < 5 && (mj[a] = b, nj++)
        }
        return b
    }

    function pj(a, b, c) {
        var d = oj(a);
        return Ub(b, d, c)
    }

    function qj(a) {
        var b = oj(w.location.href),
            c = ij(b, "host", !1);
        if (c && c.match(ej)) {
            var d = ij(b, "path");
            if (d) {
                var e = d.split(a + "=");
                if (e.length > 1) return e[1].split(";")[0].split("?")[0]
            }
        }
    };
    var rj = /gtag[.\/]js/,
        sj = /gtm[.\/]js/,
        tj = !1;

    function uj(a) {
        if ((a.scriptContainerId || "").indexOf("GTM-") >= 0) {
            var b;
            a: {
                var c, d = (c = a.scriptElement) == null ? void 0 : c.src;
                if (d) {
                    for (var e = cg(47), f = oj(d), g = e ? f.pathname : "" + f.hostname + f.pathname, h = A.scripts, l = "", n = 0; n < h.length; ++n) {
                        var p = h[n];
                        if (!(p.innerHTML.length === 0 || !e && p.innerHTML.indexOf(a.scriptContainerId || "SHOULD_NOT_BE_SET") < 0 || p.innerHTML.indexOf(g) < 0)) {
                            if (p.innerHTML.indexOf("(function(w,d,s,l,i)") >= 0) {
                                b = String(n);
                                break a
                            }
                            l = String(n)
                        }
                    }
                    if (l) {
                        b = l;
                        break a
                    }
                }
                b = void 0
            }
            var q = b;
            if (q) return tj = !0,
                q
        }
        var r = [].slice.call(A.scripts);
        return a.scriptElement ? String(r.indexOf(a.scriptElement)) : "-1"
    }

    function vj(a) {
        if (tj) return "1";
        var b, c = (b = a.scriptElement) == null ? void 0 : b.src;
        if (c) {
            if (rj.test(c)) return "3";
            if (sj.test(c)) return "2"
        }
        return "0"
    };

    function N(a) {
        jb("GTM", a)
    };

    function wj(a) {
        var b = xj().destinationArray[a],
            c = xj().destination[a];
        return b && b.length > 0 ? b[0] : c
    }

    function yj(a, b) {
        var c = xj();
        c.pending || (c.pending = []);
        tb(c.pending, function(d) {
            return d.target.ctid === a.ctid && d.target.isDestination === a.isDestination
        }) || c.pending.push({
            target: a,
            onLoad: b
        })
    }

    function zj() {
        var a = w.google_tags_first_party;
        Array.isArray(a) || (a = []);
        for (var b = {}, c = m(a), d = c.next(); !d.done; d = c.next()) b[d.value] = !0;
        return Object.freeze(b)
    }
    var Aj = function() {
        this.container = {};
        this.destination = {};
        this.destinationArray = {};
        this.canonical = {};
        this.pending = [];
        this.injectedFirstPartyContainers = {};
        this.injectedFirstPartyContainers = zj()
    };

    function xj() {
        var a = Dc("google_tag_data", {}),
            b = a.tidr;
        b && typeof b === "object" || (b = new Aj, a.tidr = b);
        var c = b;
        c.container || (c.container = {});
        c.destination || (c.destination = {});
        c.destinationArray || (c.destinationArray = {});
        c.canonical || (c.canonical = {});
        c.pending || (c.pending = []);
        c.injectedFirstPartyContainers || (c.injectedFirstPartyContainers = zj());
        return c
    };

    function Bj() {
        return cg(7) && Cj().some(function(a) {
            return a === C(5)
        })
    }

    function Dj() {
        var a, b;
        b = b === void 0 ? [] : b;
        var c, d, e = (c = data) == null ? void 0 : (d = c.blob) == null ? void 0 : d[55];
        a = Array.isArray(e) ? e : b;
        return a != null ? a : []
    }

    function Ej() {
        return C(6) || "_" + C(5)
    }

    function Fj() {
        var a = C(10);
        return a ? a.split("|") : [C(5)]
    }

    function Cj() {
        var a = C(9);
        return a ? a.split("|").filter(function(b) {
            return b.indexOf("GTM-") !== 0
        }) : []
    }

    function Gj() {
        var a = Hj(Ij()),
            b = a && a.parent;
        if (b) return Hj(b)
    }

    function Jj() {
        var a = Hj(Ij());
        if (a) {
            for (; a.parent;) {
                var b = Hj(a.parent);
                if (!b) break;
                a = b
            }
            return a
        }
    }

    function Hj(a) {
        var b = xj();
        return a.isDestination ? wj(a.ctid) : b.container[a.ctid]
    }

    function Kj() {
        var a = xj();
        if (a.pending) {
            for (var b, c = [], d = !1, e = Fj(), f = Cj(), g = {}, h = 0; h < a.pending.length; g = {
                    yg: void 0
                }, h++) g.yg = a.pending[h], tb(g.yg.target.isDestination ? f : e, function(l) {
                return function(n) {
                    return n === l.yg.target.ctid
                }
            }(g)) ? d || (b = g.yg.onLoad, d = !0) : c.push(g.yg);
            a.pending = c;
            if (b) try {
                b(Ej())
            } catch (l) {}
        }
    }

    function Lj() {
        for (var a = C(5), b = Fj(), c = Cj(), d = Dj(), e = function(q, r) {
                var v = {
                    canonicalContainerId: C(6),
                    scriptContainerId: a,
                    state: 2,
                    containers: b.slice(),
                    destinations: c.slice()
                };
                Bc && (v.scriptElement = Bc);
                Cc && (v.scriptSource = Cc);
                Gj() === void 0 && (v.htmlLoadOrder = uj(v), v.loadScriptType = vj(v));
                var t, u;
                switch (r) {
                    case 0:
                        t = function(z) {
                            f.container[q] = z
                        };
                        u = f.container[q];
                        break;
                    case 1:
                        if (H(269)) {
                            t = function(z) {
                                f.destinationArray[q] = f.destinationArray[q] || [];
                                f.destinationArray[q].unshift(z)
                            };
                            var x, y = ((x = f.destinationArray[q]) ==
                                null ? void 0 : x[0]) || f.destination[q];
                            !y || y.state !== 0 && y.state !== 1 || (u = y)
                        } else t = function(z) {
                            f.destination[q] = z
                        }, u = wj(q);
                        break;
                    case 2:
                        H(269) ? (t = function(z) {
                            f.destinationArray[q] = f.destinationArray[q] || [];
                            f.destinationArray[q].push(z)
                        }, u = void 0) : (t = function(z) {
                            f.destination[q] = z
                        }, u = wj(q))
                }
                t && (u ? (u.state === 0 && N(93), na(Object, "assign").call(Object, u, v)) : t(v))
            }, f = xj(), g = m(b), h = g.next(); !h.done; h = g.next()) e(h.value, 0);
        for (var l = m(c), n = l.next(); !n.done; n = l.next()) {
            var p = n.value;
            d.includes(p) ? e(p, 1) : e(p, 2)
        }
        f.canonical[Ej()] = {};
        Kj()
    }

    function Mj() {
        var a = Ej();
        return !!xj().canonical[a]
    }

    function Nj(a) {
        return !!xj().container[a]
    }

    function Oj(a) {
        var b = wj(a);
        return b ? b.state !== 0 : !1
    }

    function Ij() {
        return {
            ctid: C(5),
            isDestination: cg(7)
        }
    }

    function Pj(a, b, c) {
        var d = Ij(),
            e = xj().container[a];
        e && e.state !== 3 || (xj().container[a] = {
            state: 1,
            context: b,
            parent: d
        }, yj({
            ctid: a,
            isDestination: !1
        }, c))
    }

    function Qj() {
        var a = xj().container,
            b;
        for (b in a)
            if (a.hasOwnProperty(b) && a[b].state === 1) return !0;
        return !1
    }

    function Rj() {
        var a = {};
        xb(xj().destination, function(b, c) {
            (c == null ? void 0 : c.state) === 0 && (a[b] = c)
        });
        xb(xj().destinationArray, function(b, c) {
            var d = c[0];
            (d == null ? void 0 : d.state) === 0 && (a[b] = d)
        });
        return a
    }

    function Sj(a) {
        return !!(a && a.parent && a.context && a.context.source === 1 && a.parent.ctid.indexOf("GTM-") !== 0)
    }

    function Tj() {
        for (var a = xj(), b = m(Fj()), c = b.next(); !c.done; c = b.next())
            if (a.injectedFirstPartyContainers[c.value]) return !0;
        return !1
    };

    function Uj(a) {
        a = a === void 0 ? [] : a;
        return Li(a).join("~")
    }

    function Vj() {
        if (!H(118)) return "";
        var a, b;
        return (((a = Hj(Ij())) == null ? void 0 : (b = a.context) == null ? void 0 : b.loadExperiments) || []).join("~")
    };
    var Wj = {
            "https://www.google.com": "/g",
            "https://www.googleadservices.com": "/as",
            "https://pagead2.googlesyndication.com": "/gs"
        },
        Xj = ["/as/d/ccm/conversion", "/g/d/ccm/conversion", "/gs/ccm/conversion", "/d/ccm/form-data"];

    function Yj(a, b) {
        if (a) {
            var c = "" + a;
            c.indexOf("http://") !== 0 && c.indexOf("https://") !== 0 && (c = "https://" + c);
            c[c.length - 1] === "/" && (c = c.substring(0, c.length - 1));
            return oj("" + c + b).href
        }
    }

    function Zj(a, b) {
        if (bj() || cg(50)) return Yj(a, b)
    }

    function ak() {
        return !!Oi.Ui && Oi.Ui.split("@@").join("") !== "SGTM_TOKEN"
    }

    function bk(a) {
        for (var b = m([K.m.ud, K.m.qc]), c = b.next(); !c.done; c = b.next()) {
            var d = P(a, c.value);
            if (d) return d
        }
    }

    function ck(a, b, c) {
        c = c === void 0 ? "" : c;
        if (!bj()) return a;
        var d = b ? Wj[a] || "" : "";
        d === "/gs" && (c = "");
        return "" + aj() + d + c
    }

    function dk(a) {
        if (!bj()) return a;
        for (var b = m(Xj), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            if (Jb(a, "" + aj() + d)) return a + "&_uip=" + encodeURIComponent("::")
        }
        return a
    };
    var ek = {
        total: 0,
        Zc: 0,
        mn: {}
    };

    function fk(a) {
        var b = String(a[nf.Ra] || "").replace(/_/g, "");
        return Jb(b, "cvt") ? "cvt" : b
    }
    var gk = w.location.search.indexOf("?gtm_latency=") >= 0 || w.location.search.indexOf("&gtm_latency=") >= 0;
    var hk = Math.random(),
        ik, jk = dg(27);
    ik = gk || hk < jk;
    var kk, lk = dg(42);
    kk = gk || hk >= 1 - lk;

    function mk(a, b, c) {
        var d, e = a.GooglebQhCsO;
        e || (e = {}, a.GooglebQhCsO = e);
        d = e;
        if (d[b]) return !1;
        d[b] = [];
        d[b][0] = c;
        return !0
    };
    var nk = function(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e < 128 ? b[c++] = e : (e < 2048 ? b[c++] = e >> 6 | 192 : ((e & 64512) == 55296 && d + 1 < a.length && (a.charCodeAt(d + 1) & 64512) == 56320 ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        return b
    };
    var ok, pk;
    a: {
        for (var qk = ["CLOSURE_FLAGS"], rk = Fa, sk = 0; sk < qk.length; sk++)
            if (rk = rk[qk[sk]], rk == null) {
                pk = null;
                break a
            }
        pk = rk
    }
    var tk = pk && pk[610401301];
    ok = tk != null ? tk : !1;

    function uk() {
        var a = Fa.navigator;
        if (a) {
            var b = a.userAgent;
            if (b) return b
        }
        return ""
    }
    var vk, wk = Fa.navigator;
    vk = wk ? wk.userAgentData || null : null;

    function xk(a) {
        if (!ok || !vk) return !1;
        for (var b = 0; b < vk.brands.length; b++) {
            var c = vk.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function yk(a) {
        return uk().indexOf(a) != -1
    };

    function zk() {
        return ok ? !!vk && vk.brands.length > 0 : !1
    }

    function Ak() {
        return zk() ? !1 : yk("Opera")
    }

    function Bk() {
        return yk("Firefox") || yk("FxiOS")
    }

    function Ck() {
        return zk() ? xk("Chromium") : (yk("Chrome") || yk("CriOS")) && !(zk() ? 0 : yk("Edge")) || yk("Silk")
    };

    function Dk() {
        return ok ? !!vk && !!vk.platform : !1
    }

    function Ek() {
        return yk("iPhone") && !yk("iPod") && !yk("iPad")
    }

    function Fk() {
        Ek() || yk("iPad") || yk("iPod")
    };
    var Gk = function(a) {
        Gk[" "](a);
        return a
    };
    Gk[" "] = function() {};
    Ak();
    zk() || yk("Trident") || yk("MSIE");
    yk("Edge");
    !yk("Gecko") || uk().toLowerCase().indexOf("webkit") != -1 && !yk("Edge") || yk("Trident") || yk("MSIE") || yk("Edge");
    uk().toLowerCase().indexOf("webkit") != -1 && !yk("Edge") && yk("Mobile");
    Dk() || yk("Macintosh");
    Dk() || yk("Windows");
    (Dk() ? vk.platform === "Linux" : yk("Linux")) || Dk() || yk("CrOS");
    Dk() || yk("Android");
    Ek();
    yk("iPad");
    yk("iPod");
    Fk();
    uk().toLowerCase().indexOf("kaios");
    Bk();
    Ek() || yk("iPod");
    yk("iPad");
    !yk("Android") || Ck() || Bk() || Ak() || yk("Silk");
    Ck();
    !yk("Safari") || Ck() || (zk() ? 0 : yk("Coast")) || Ak() || (zk() ? 0 : yk("Edge")) || (zk() ? xk("Microsoft Edge") : yk("Edg/")) || (zk() ? xk("Opera") : yk("OPR")) || Bk() || yk("Silk") || yk("Android") || Fk();
    var Hk = {},
        Ik = null,
        Jk = function(a) {
            for (var b = [], c = 0, d = 0; d < a.length; d++) {
                var e = a.charCodeAt(d);
                e > 255 && (b[c++] = e & 255, e >>= 8);
                b[c++] = e
            }
            var f = 4;
            f === void 0 && (f = 0);
            if (!Ik) {
                Ik = {};
                for (var g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), h = ["+/=", "+/", "-_=", "-_.", "-_"], l = 0; l < 5; l++) {
                    var n = g.concat(h[l].split(""));
                    Hk[l] = n;
                    for (var p = 0; p < n.length; p++) {
                        var q = n[p];
                        Ik[q] === void 0 && (Ik[q] = p)
                    }
                }
            }
            for (var r = Hk[f], v = Array(Math.floor(b.length / 3)), t = r[64] || "", u = 0, x = 0; u < b.length - 2; u += 3) {
                var y = b[u],
                    z = b[u + 1],
                    D = b[u + 2],
                    E = r[y >> 2],
                    L = r[(y & 3) << 4 | z >> 4],
                    G = r[(z & 15) << 2 | D >> 6],
                    O = r[D & 63];
                v[x++] = "" + E + L + G + O
            }
            var W = 0,
                ia = t;
            switch (b.length - u) {
                case 2:
                    W = b[u + 1], ia = r[(W & 15) << 2] || t;
                case 1:
                    var T = b[u];
                    v[x] = "" + r[T >> 2] + r[(T & 3) << 4 | W >> 4] + ia + t
            }
            return v.join("")
        };
    var Kk = function(a) {
        return decodeURIComponent(a.replace(/\+/g, " "))
    };
    var Lk = function(a, b, c, d) {
            for (var e = b, f = c.length;
                (e = a.indexOf(c, e)) >= 0 && e < d;) {
                var g = a.charCodeAt(e - 1);
                if (g == 38 || g == 63) {
                    var h = a.charCodeAt(e + f);
                    if (!h || h == 61 || h == 38 || h == 35) return e
                }
                e += f + 1
            }
            return -1
        },
        Mk = /#|$/,
        Nk = function(a, b) {
            var c = a.search(Mk),
                d = Lk(a, 0, b, c);
            if (d < 0) return null;
            var e = a.indexOf("&", d);
            if (e < 0 || e > c) e = c;
            d += b.length + 1;
            return Kk(a.slice(d, e !== -1 ? e : 0))
        },
        Ok = /[?&]($|#)/,
        Pk = function(a, b, c) {
            for (var d, e = a.search(Mk), f = 0, g, h = [];
                (g = Lk(a, f, b, e)) >= 0;) h.push(a.substring(f, g)), f = Math.min(a.indexOf("&", g) +
                1 || e, e);
            h.push(a.slice(f));
            d = h.join("").replace(Ok, "$1");
            var l, n = c != null ? "=" + encodeURIComponent(String(c)) : "";
            var p = b + n;
            if (p) {
                var q, r = d.indexOf("#");
                r < 0 && (r = d.length);
                var v = d.indexOf("?"),
                    t;
                v < 0 || v > r ? (v = r, t = "") : t = d.substring(v + 1, r);
                q = [d.slice(0, v), t, d.slice(r)];
                var u = q[1];
                q[1] = p ? u ? u + "&" + p : p : u;
                l = q[0] + (q[1] ? "?" + q[1] : "") + q[2]
            } else l = d;
            return l
        };

    function Qk(a, b, c, d, e, f, g) {
        var h = Nk(c, "fmt");
        if (d) {
            var l = Nk(c, "random"),
                n = Nk(c, "label") || "";
            if (!l) return !1;
            var p = Jk(Kk(n) + ":" + Kk(l));
            if (!mk(a, p, d)) return !1
        }
        h && Number(h) !== 4 && (c = Pk(c, "rfmt", h));
        var q = Pk(c, "fmt", 4),
            r = b.getElementsByTagName("script")[0].parentElement;
        g == null || Rk(g);
        Lc(q, function() {
            g == null || Sk(g);
            a.google_noFurtherRedirects && d && (a.google_noFurtherRedirects = null, d())
        }, function() {
            g == null || Sk(g);
            e == null || e()
        }, f, r || void 0);
        return !0
    };
    var Tk = {},
        Uk = (Tk[1] = {}, Tk[2] = {}, Tk[3] = {}, Tk[4] = {}, Tk);

    function Vk(a, b, c) {
        var d = Wk(b, c);
        if (d) {
            var e = Uk[b][d];
            e || (e = Uk[b][d] = []);
            e.push(na(Object, "assign").call(Object, {}, a));
            var f = a.destinationId,
                g = a.endpoint;
            ek.total += 1;
            ek.Zc += 1;
            var h, l = f === void 0 ? "" : f;
            h = ek.mn[l] || (ek.mn[l] = {
                total: 0,
                Zc: 0,
                nn: {}
            });
            h.total += 1;
            h.Zc += 1;
            var n, p = String(g);
            n = h.nn[p] || (h.nn[p] = {
                total: 0,
                Zc: 0
            });
            n.total += 1;
            n.Zc += 1
        }
    }

    function Xk(a, b) {
        var c = Wk(a, b);
        if (c) {
            var d = Uk[a][c];
            d && (Uk[a][c] = d.filter(function(e) {
                return !e.vn
            }))
        }
    }

    function Yk(a) {
        switch (a) {
            case "script-src":
            case "script-src-elem":
                return 1;
            case "frame-src":
                return 4;
            case "connect-src":
                return 2;
            case "img-src":
                return 3
        }
    }

    function Wk(a, b) {
        var c = b;
        if (b[0] === "/") {
            var d;
            c = ((d = w.location) == null ? void 0 : d.origin) + b
        }
        try {
            var e = new URL(c);
            return a === 4 ? e.origin : e.origin + e.pathname
        } catch (f) {}
    }

    function Zk(a) {
        var b = Ea.apply(1, arguments);
        kk && (Vk(a, 2, b[0]), Vk(a, 3, b[0]));
        Xc.apply(null, Aa(b))
    }

    function $k(a) {
        var b = Ea.apply(1, arguments);
        kk && Vk(a, 2, b[0]);
        return Yc.apply(null, Aa(b))
    }

    function al(a) {
        var b = Ea.apply(1, arguments);
        kk && Vk(a, 3, b[0]);
        Oc.apply(null, Aa(b))
    }

    function bl(a) {
        var b = Ea.apply(1, arguments),
            c = b[0];
        kk && (Vk(a, 2, c), Vk(a, 3, c));
        return bd.apply(null, Aa(b))
    }

    function cl(a) {
        var b = Ea.apply(1, arguments);
        kk && Vk(a, 1, b[0]);
        Lc.apply(null, Aa(b))
    }

    function dl(a) {
        var b = Ea.apply(1, arguments);
        b[0] && kk && Vk(a, 4, b[0]);
        Nc.apply(null, Aa(b))
    }

    function el(a) {
        var b = Ea.apply(1, arguments);
        kk && Vk(a, 1, b[2]);
        return Qk.apply(null, Aa(b))
    };
    var fl = {
        Ja: {
            Ae: 0,
            De: 1,
            Ni: 2
        }
    };
    fl.Ja[fl.Ja.Ae] = "FULL_TRANSMISSION";
    fl.Ja[fl.Ja.De] = "LIMITED_TRANSMISSION";
    fl.Ja[fl.Ja.Ni] = "NO_TRANSMISSION";
    var gl = {
        aa: {
            Pc: 0,
            Qa: 1,
            dd: 2,
            Nc: 3
        }
    };
    gl.aa[gl.aa.Pc] = "NO_QUEUE";
    gl.aa[gl.aa.Qa] = "ADS";
    gl.aa[gl.aa.dd] = "ANALYTICS";
    gl.aa[gl.aa.Nc] = "MONITORING";

    function hl() {
        var a = Dc("google_tag_data", {});
        return a.ics = a.ics || new il
    }
    var il = function() {
        this.entries = {};
        this.waitPeriodTimedOut = this.wasSetLate = this.accessedAny = this.accessedDefault = this.usedImplicit = this.usedUpdate = this.usedDefault = this.usedDeclare = this.active = !1;
        this.C = []
    };
    il.prototype.default = function(a, b, c, d, e, f, g) {
        this.usedDefault || this.usedDeclare || !this.accessedDefault && !this.accessedAny || (this.wasSetLate = !0);
        this.usedDefault = this.active = !0;
        jb("TAGGING", 19);
        b == null ? jb("TAGGING", 18) : jl(this, a, b === "granted", c, d, e, f, g)
    };
    il.prototype.waitForUpdate = function(a, b, c) {
        for (var d = 0; d < a.length; d++) jl(this, a[d], void 0, void 0, "", "", b, c)
    };
    var jl = function(a, b, c, d, e, f, g, h) {
        var l = a.entries,
            n = l[b] || {},
            p = n.region,
            q = d && qb(d) ? d.toUpperCase() : void 0;
        e = e.toUpperCase();
        f = f.toUpperCase();
        if (e === "" || q === f || (q === e ? p !== f : !q && !p)) {
            var r = !!(g && g > 0 && n.update === void 0),
                v = {
                    region: q,
                    declare_region: n.declare_region,
                    implicit: n.implicit,
                    default: c !== void 0 ? c : n.default,
                    declare: n.declare,
                    update: n.update,
                    quiet: r
                };
            if (e !== "" || n.default !== !1) l[b] = v;
            r && w.setTimeout(function() {
                l[b] === v && v.quiet && (jb("TAGGING", 2), a.waitPeriodTimedOut = !0, a.clearTimeout(b, void 0, h),
                    a.notifyListeners())
            }, g)
        }
    };
    k = il.prototype;
    k.clearTimeout = function(a, b, c) {
        var d = [a],
            e = c.delegatedConsentTypes,
            f;
        for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
        var g = this.entries[a] || {},
            h = this.getConsentState(a, c);
        if (g.quiet) {
            g.quiet = !1;
            for (var l = m(d), n = l.next(); !n.done; n = l.next()) kl(this, n.value)
        } else if (b !== void 0 && h !== b)
            for (var p = m(d), q = p.next(); !q.done; q = p.next()) kl(this, q.value)
    };
    k.update = function(a, b, c) {
        this.usedDefault || this.usedDeclare || this.usedUpdate || !this.accessedAny || (this.wasSetLate = !0);
        this.usedUpdate = this.active = !0;
        if (b != null) {
            var d = this.getConsentState(a, c),
                e = this.entries;
            (e[a] = e[a] || {}).update = b === "granted";
            this.clearTimeout(a, d, c)
        }
    };
    k.declare = function(a, b, c, d, e) {
        this.usedDeclare = this.active = !0;
        var f = this.entries,
            g = f[a] || {},
            h = g.declare_region,
            l = c && qb(c) ? c.toUpperCase() : void 0;
        d = d.toUpperCase();
        e = e.toUpperCase();
        if (d === "" || l === e || (l === d ? h !== e : !l && !h)) {
            var n = {
                region: g.region,
                declare_region: l,
                declare: b === "granted",
                implicit: g.implicit,
                default: g.default,
                update: g.update,
                quiet: g.quiet
            };
            if (d !== "" || g.declare !== !1) f[a] = n
        }
    };
    k.implicit = function(a, b) {
        this.usedImplicit = !0;
        var c = this.entries,
            d = c[a] = c[a] || {};
        d.implicit !== !1 && (d.implicit = b === "granted")
    };
    k.getConsentState = function(a, b) {
        var c = this.entries,
            d = c[a] || {},
            e = d.update;
        if (e !== void 0) return e ? 1 : 2;
        if (b.usedContainerScopedDefaults) {
            var f = b.containerScopedDefaults[a];
            if (f === 3) return 1;
            if (f === 2) return 2
        } else if (e = d.default, e !== void 0) return e ? 1 : 2;
        if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
            var g = b.delegatedConsentTypes[a],
                h = c[g] || {};
            e = h.update;
            if (e !== void 0) return e ? 1 : 2;
            if (b.usedContainerScopedDefaults) {
                var l = b.containerScopedDefaults[g];
                if (l === 3) return 1;
                if (l === 2) return 2
            } else if (e =
                h.default, e !== void 0) return e ? 1 : 2
        }
        e = d.declare;
        if (e !== void 0) return e ? 1 : 2;
        e = d.implicit;
        return e !== void 0 ? e ? 3 : 4 : 0
    };
    k.addListener = function(a, b) {
        this.C.push({
            consentTypes: a,
            Id: b
        })
    };
    var kl = function(a, b) {
        for (var c = 0; c < a.C.length; ++c) {
            var d = a.C[c];
            Array.isArray(d.consentTypes) && d.consentTypes.indexOf(b) !== -1 && (d.qn = !0)
        }
    };
    il.prototype.notifyListeners = function(a, b) {
        for (var c = 0; c < this.C.length; ++c) {
            var d = this.C[c];
            if (d.qn) {
                d.qn = !1;
                try {
                    d.Id({
                        consentEventId: a,
                        consentPriorityId: b
                    })
                } catch (e) {}
            }
        }
    };
    var ll = !1,
        ml = !1,
        nl = {},
        ol = {
            delegatedConsentTypes: {},
            corePlatformServices: {},
            usedCorePlatformServices: !1,
            selectedAllCorePlatformServices: !1,
            containerScopedDefaults: (nl.ad_storage = 1, nl.analytics_storage = 1, nl.ad_user_data = 1, nl.ad_personalization = 1, nl),
            usedContainerScopedDefaults: !1
        };

    function pl(a) {
        var b = hl();
        b.accessedAny = !0;
        return (qb(a) ? [a] : a).every(function(c) {
            switch (b.getConsentState(c, ol)) {
                case 1:
                case 3:
                    return !0;
                case 2:
                case 4:
                    return !1;
                default:
                    return !0
            }
        })
    }

    function ql(a) {
        var b = hl();
        b.accessedAny = !0;
        return b.getConsentState(a, ol)
    }

    function rl(a) {
        var b = hl();
        b.accessedAny = !0;
        return !(b.entries[a] || {}).quiet
    }

    function sl() {
        if (!Wa(7)) return !1;
        var a = hl();
        a.accessedAny = !0;
        if (a.active) return !0;
        if (!ol.usedContainerScopedDefaults) return !1;
        for (var b = m(Object.keys(ol.containerScopedDefaults)), c = b.next(); !c.done; c = b.next())
            if (ol.containerScopedDefaults[c.value] !== 1) return !0;
        return !1
    }

    function tl(a, b) {
        hl().addListener(a, b)
    }

    function ul(a, b) {
        hl().notifyListeners(a, b)
    }

    function vl(a, b) {
        function c() {
            for (var e = 0; e < b.length; e++)
                if (!rl(b[e])) return !0;
            return !1
        }
        if (c()) {
            var d = !1;
            tl(b, function(e) {
                d || c() || (d = !0, a(e))
            })
        } else a({})
    }

    function wl(a, b) {
        function c() {
            for (var h = [], l = 0; l < e.length; l++) {
                var n = e[l];
                pl(n) && !f[n] && h.push(n)
            }
            return h
        }

        function d(h) {
            for (var l = 0; l < h.length; l++) f[h[l]] = !0
        }
        var e = qb(b) ? [b] : b,
            f = {},
            g = c();
        g.length !== e.length && (d(g), tl(e, function(h) {
            function l(q) {
                q.length !== 0 && (d(q), h.consentTypes = q, a(h))
            }
            var n = c();
            if (n.length !== 0) {
                var p = Object.keys(f).length;
                n.length + p >= e.length ? l(n) : w.setTimeout(function() {
                    l(c())
                }, 500)
            }
        }))
    };
    var xl = {},
        yl = (xl[gl.aa.Pc] = fl.Ja.Ae, xl[gl.aa.Qa] = fl.Ja.Ae, xl[gl.aa.dd] = fl.Ja.Ae, xl[gl.aa.Nc] = fl.Ja.Ae, xl),
        zl = function(a, b) {
            this.C = a;
            this.consentTypes = b
        };
    zl.prototype.isConsentGranted = function() {
        switch (this.C) {
            case 0:
                return this.consentTypes.every(function(a) {
                    return pl(a)
                });
            case 1:
                return this.consentTypes.some(function(a) {
                    return pl(a)
                });
            default:
                rc(this.C, "consentsRequired had an unknown type")
        }
    };
    var Al = {},
        Bl = (Al[gl.aa.Pc] = new zl(0, []), Al[gl.aa.Qa] = new zl(0, ["ad_storage"]), Al[gl.aa.dd] = new zl(0, ["analytics_storage"]), Al[gl.aa.Nc] = new zl(1, ["ad_storage", "analytics_storage"]), Al);
    var Dl = function(a) {
        var b = this;
        this.type = a;
        this.C = [];
        tl(Bl[a].consentTypes, function() {
            Cl(b) || b.flush()
        })
    };
    Dl.prototype.flush = function() {
        for (var a = m(this.C), b = a.next(); !b.done; b = a.next()) {
            var c = b.value;
            c()
        }
        this.C = []
    };
    var Cl = function(a) {
            return yl[a.type] === fl.Ja.Ni && !Bl[a.type].isConsentGranted()
        },
        El = function(a, b) {
            Cl(a) ? a.C.push(b) : b()
        },
        Fl = new Map;

    function Gl(a) {
        Fl.has(a) || Fl.set(a, new Dl(a));
        return Fl.get(a)
    };
    var Hl = {
        Z: {
            In: "aw_user_data_cache",
            Uh: "cookie_deprecation_label",
            Lg: "diagnostics_page_id",
            Xr: "em_registry",
            xi: "eab",
            Zo: "fl_user_data_cache",
            ep: "ga4_user_data_cache",
            Be: "ip_geo_data_cache",
            Di: "ip_geo_fetch_in_progress",
            lm: "nb_data",
            Oi: "page_experiment_ids",
            Fe: "pt_data",
            qm: "pt_listener_set",
            wm: "service_worker_endpoint",
            zm: "shared_user_id",
            Am: "shared_user_id_requested",
            xh: "shared_user_id_source"
        }
    };
    var Il = function(a) {
        return ff(function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        })
    }(Hl.Z);

    function Jl(a, b) {
        b = b === void 0 ? !1 : b;
        if (Il(a)) {
            var c, d, e = (d = (c = Dc("google_tag_data", {})).xcd) != null ? d : c.xcd = {};
            if (e[a]) return e[a];
            if (b) {
                var f = void 0,
                    g = 1,
                    h = {},
                    l = {
                        set: function(n) {
                            f = n;
                            l.notify()
                        },
                        get: function() {
                            return f
                        },
                        subscribe: function(n) {
                            h[String(g)] = n;
                            return g++
                        },
                        unsubscribe: function(n) {
                            var p = String(n);
                            return h.hasOwnProperty(p) ? (delete h[p], !0) : !1
                        },
                        notify: function() {
                            for (var n = m(Object.keys(h)), p = n.next(); !p.done; p = n.next()) {
                                var q = p.value;
                                try {
                                    h[q](a, f)
                                } catch (r) {}
                            }
                        }
                    };
                return e[a] = l
            }
        }
    }

    function Kl(a, b) {
        var c = Jl(a, !0);
        c && c.set(b)
    }

    function Ll(a) {
        var b;
        return (b = Jl(a)) == null ? void 0 : b.get()
    }

    function Ml(a, b) {
        var c = Jl(a);
        if (!c) {
            c = Jl(a, !0);
            if (!c) return;
            c.set(b)
        }
        return c.get()
    }

    function Nl(a, b) {
        if (typeof b === "function") {
            var c;
            return (c = Jl(a, !0)) == null ? void 0 : c.subscribe(b)
        }
    }

    function Ol(a, b) {
        var c = Jl(a);
        return c ? c.unsubscribe(b) : !1
    };
    var Pl = {},
        Ql = (Pl.tdp = 1, Pl.exp = 1, Pl.pid = 1, Pl.dl = 1, Pl.seq = 1, Pl.t = 1, Pl.v = 1, Pl),
        Rl = ["mcc"],
        Sl = {},
        Tl = {},
        Ul = !1;

    function Vl(a, b, c) {
        Tl[a] = b;
        (c === void 0 || c) && Wl(a)
    }

    function Wl(a, b) {
        Sl[a] !== void 0 && (b === void 0 || !b) || Jb(C(5), "GTM-") && a === "mcc" || (Sl[a] = !0)
    }

    function Xl(a) {
        a = a === void 0 ? !1 : a;
        var b = Object.keys(Sl).filter(function(c) {
            return Sl[c] === !0 && Tl[c] !== void 0 && (a || !Rl.includes(c))
        });
        Yl(b);
        return b.map(function(c) {
            var d = Tl[c];
            typeof d === "function" && (d = d());
            return d ? "&" + c + "=" + d : ""
        }).join("") + "&z=0"
    }

    function Zl(a) {
        var b = Xl(a === void 0 ? !1 : a),
            c = "https://" + C(21),
            d = "/td?id=" + C(5);
        return "" + ck(c) + d + b
    }

    function Yl(a) {
        a.forEach(function(b) {
            Ql[b] || (Sl[b] = !1)
        })
    }

    function $l(a) {
        a = a === void 0 ? !1 : a;
        if (Ki.H && kk && C(5)) {
            var b = Gl(gl.aa.Nc);
            if (Cl(b)) Ul || (Ul = !0, El(b, $l));
            else {
                var c = Zl(a),
                    d = {
                        destinationId: C(5),
                        endpoint: 61
                    };
                a ? bl(d, c, void 0, {
                    Pe: !0
                }, void 0, function() {
                    al(d, c + "&img=1")
                }) : al(d, c);
                Ul = !1
            }
        }
    }

    function am() {
        Object.keys(Sl).filter(function(a) {
            return Sl[a] && !Ql[a]
        }).length > 0 && $l(!0)
    }
    var bm;

    function cm() {
        if (Ll(Hl.Z.Lg) === void 0) {
            var a = function() {
                Kl(Hl.Z.Lg, ub());
                bm = 0
            };
            a();
            w.setInterval(a, 864E5)
        } else Nl(Hl.Z.Lg, function() {
            bm = 0
        });
        bm = 0
    }

    function dm() {
        cm();
        Vl("v", "3");
        Vl("t", "t");
        Vl("pid", function() {
            return String(Ll(Hl.Z.Lg))
        });
        Vl("seq", function() {
            return String(++bm)
        });
        Vl("exp", Uj());
        Qc(w, "pagehide", am)
    };
    var em = ["ad_storage", "analytics_storage", "ad_user_data", "ad_personalization"],
        fm = [K.m.ud, K.m.qc, K.m.qe, K.m.Pb, K.m.Sb, K.m.Na, K.m.Xa, K.m.Wa, K.m.sb, K.m.Qb],
        gm = !1,
        hm = !1,
        im = {},
        jm = {};

    function km() {
        !hm && gm && (em.some(function(a) {
            return ol.containerScopedDefaults[a] !== 1
        }) || lm("mbc"));
        hm = !0
    }

    function lm(a) {
        kk && (Vl(a, "1"), $l())
    }

    function mm(a, b) {
        if (!im[b] && (im[b] = !0, jm[b]))
            for (var c = m(fm), d = c.next(); !d.done; d = c.next())
                if (P(a, d.value)) {
                    lm("erc");
                    break
                }
    };

    function nm(a) {
        jb("HEALTH", a)
    };
    var om = {},
        pm = !1;

    function qm() {
        function a() {
            c !== void 0 && Ol(Hl.Z.Be, c);
            try {
                var e = Ll(Hl.Z.Be);
                om = JSON.parse(e)
            } catch (f) {
                N(123), nm(2), om = {}
            }
            pm = !0;
            b()
        }
        var b = rm,
            c = void 0,
            d = Ll(Hl.Z.Be);
        d ? a(d) : (c = Nl(Hl.Z.Be, a), sm())
    }

    function sm() {
        function a(b) {
            Kl(Hl.Z.Be, b || "{}");
            Kl(Hl.Z.Di, !1)
        }
        if (!Ll(Hl.Z.Di)) {
            Kl(Hl.Z.Di, !0);
            try {
                w.fetch("https://www.google.com/ccm/geo", {
                    method: "GET",
                    cache: "no-store",
                    mode: "cors",
                    credentials: "omit"
                }).then(function(b) {
                    b.ok ? b.text().then(function(c) {
                        a(c)
                    }, function() {
                        a()
                    }) : a()
                }, function() {
                    a()
                })
            } catch (b) {
                a()
            }
        }
    }

    function tm() {
        var a = C(22);
        try {
            return JSON.parse(hb(a))
        } catch (b) {
            return N(123), nm(2), {}
        }
    }

    function um() {
        return om["0"] || ""
    }

    function vm() {
        return om["1"] || ""
    }

    function wm() {
        var a = !1;
        return a
    }

    function xm() {
        return om["6"] !== !1
    }

    function ym() {
        var a = "";
        return a
    }

    function zm() {
        var a = "";
        return a
    };
    var Am = {},
        Bm = Object.freeze((Am[K.m.Nb] = 1, Am[K.m.Mg] = 1, Am[K.m.Yh] = 1, Am[K.m.Ob] = 1, Am[K.m.Ca] = 1, Am[K.m.sb] = 1, Am[K.m.tb] = 1, Am[K.m.Cb] = 1, Am[K.m.ld] = 1, Am[K.m.Qb] = 1, Am[K.m.Wa] = 1, Am[K.m.xc] = 1, Am[K.m.oe] = 1, Am[K.m.Fa] = 1, Am[K.m.Lk] = 1, Am[K.m.vf] = 1, Am[K.m.Vg] = 1, Am[K.m.Wg] = 1, Am[K.m.ii] = 1, Am[K.m.qe] = 1, Am[K.m.Wk] = 1, Am[K.m.Dc] = 1, Am[K.m.ve] = 1, Am[K.m.Zk] = 1, Am[K.m.Zg] = 1, Am[K.m.li] = 1, Am[K.m.Fc] = 1, Am[K.m.Gc] = 1, Am[K.m.Xa] = 1, Am[K.m.ni] = 1, Am[K.m.Rb] = 1, Am[K.m.rd] = 1, Am[K.m.sd] = 1, Am[K.m.ud] = 1, Am[K.m.Ff] = 1, Am[K.m.ri] = 1, Am[K.m.vd] =
            1, Am[K.m.qc] = 1, Am[K.m.wd] = 1, Am[K.m.yl] = 1, Am[K.m.Tb] = 1, Am[K.m.Mc] = 1, Am[K.m.Ti] = 1, Am));
    Object.freeze([K.m.za, K.m.Ya, K.m.Db, K.m.kb, K.m.oi, K.m.Na, K.m.ji, K.m.zo]);
    var Cm = {},
        Dm = Object.freeze((Cm[K.m.co] = 1, Cm[K.m.eo] = 1, Cm[K.m.fo] = 1, Cm[K.m.ho] = 1, Cm[K.m.io] = 1, Cm[K.m.lo] = 1, Cm[K.m.mo] = 1, Cm[K.m.no] = 1, Cm[K.m.po] = 1, Cm[K.m.fe] = 1, Cm)),
        Em = {},
        Fm = Object.freeze((Em[K.m.Bk] = 1, Em[K.m.Ck] = 1, Em[K.m.be] = 1, Em[K.m.ce] = 1, Em[K.m.Dk] = 1, Em[K.m.fd] = 1, Em[K.m.de] = 1, Em[K.m.hc] = 1, Em[K.m.wc] = 1, Em[K.m.jc] = 1, Em[K.m.Ab] = 1, Em[K.m.ee] = 1, Em[K.m.kc] = 1, Em[K.m.Ek] = 1, Em)),
        Gm = Object.freeze([K.m.Nb, K.m.df, K.m.Ob, K.m.xc, K.m.qe, K.m.Cf, K.m.rd, K.m.wd]),
        Hm = Object.freeze([].concat(Aa(Gm))),
        Im = Object.freeze([K.m.tb,
            K.m.Wg, K.m.Ff, K.m.ri, K.m.Tg
        ]),
        Jm = Object.freeze([].concat(Aa(Im))),
        Km = {},
        Lm = (Km[K.m.X] = "1", Km[K.m.ja] = "2", Km[K.m.W] = "3", Km[K.m.La] = "4", Km),
        Mm = {},
        Nm = Object.freeze((Mm.search = "s", Mm.youtube = "y", Mm.playstore = "p", Mm.shopping = "h", Mm.ads = "a", Mm.maps = "m", Mm));

    function Om(a) {
        return typeof a !== "object" || a === null ? {} : a
    }

    function Pm(a) {
        return a === void 0 || a === null ? "" : typeof a === "object" ? a.toString() : String(a)
    }

    function Qm(a) {
        if (a !== void 0 && a !== null) return Pm(a)
    }

    function Rm(a) {
        return typeof a === "number" ? a : Qm(a)
    };

    function Sm(a) {
        return a && a.indexOf("pending:") === 0 ? Tm(a.substr(8)) : !1
    }

    function Tm(a) {
        if (a == null || a.length === 0) return !1;
        var b = Number(a),
            c = Eb();
        return b < c + 3E5 && b > c - 9E5
    };
    var Um = !1,
        Vm = !1,
        Wm = !1,
        Xm = 0,
        Ym = !1,
        Zm = [];

    function $m(a) {
        if (Xm === 0) Ym && Zm && (Zm.length >= 100 && Zm.shift(), Zm.push(a));
        else if (an()) {
            var b = C(41),
                c = Dc(b, []);
            c.length >= 50 && c.shift();
            c.push(a)
        }
    }

    function bn() {
        cn();
        Rc(A, "TAProdDebugSignal", bn)
    }

    function cn() {
        if (!Vm) {
            Vm = !0;
            dn();
            var a = Zm;
            Zm = void 0;
            a == null || a.forEach(function(b) {
                $m(b)
            })
        }
    }

    function dn() {
        var a = A.documentElement.getAttribute("data-tag-assistant-prod-present");
        Tm(a) ? Xm = 1 : !Sm(a) || Um || Wm ? Xm = 2 : (Wm = !0, Qc(A, "TAProdDebugSignal", bn, !1), w.setTimeout(function() {
            cn();
            Um = !0
        }, 200))
    }

    function an() {
        if (!Ym) return !1;
        switch (Xm) {
            case 1:
            case 0:
                return !0;
            case 2:
                return !1;
            default:
                return !1
        }
    };
    var en = !1;

    function fn(a, b) {
        var c = Fj(),
            d = Cj();
        C(26);
        if (an()) {
            var e = gn("INIT");
            e.containerLoadSource = a != null ? a : 0;
            b && (e.parentTargetReference = b);
            e.aliases = c;
            e.destinations = d;
            $m(e)
        }
    }

    function hn(a) {
        var b, c, d, e;
        b = a.targetId;
        c = a.request;
        d = a.hb;
        e = a.isBatched;
        var f;
        if (f = an()) {
            var g;
            a: switch (c.endpoint) {
                case 19:
                case 47:
                    g = !0;
                    break a;
                default:
                    g = !1
            }
            f = !g
        }
        if (f) {
            var h = gn("GTAG_HIT", {
                eventId: d.eventId,
                priorityId: d.priorityId
            });
            h.target = b;
            h.url = c.url;
            c.postBody && (h.postBody = c.postBody);
            h.parameterEncoding = c.parameterEncoding;
            h.endpoint = c.endpoint;
            e !== void 0 && (h.isBatched = e);
            $m(h)
        }
    }

    function jn(a) {
        an() && hn(a())
    }

    function gn(a, b) {
        b = b === void 0 ? {} : b;
        b.groupId = kn;
        var c, d = b,
            e = ln,
            f = {
                publicId: mn
            };
        d.eventId != null && (f.eventId = d.eventId);
        d.priorityId != null && (f.priorityId = d.priorityId);
        d.eventName && (f.eventName = d.eventName);
        d.groupId && (f.groupId = d.groupId);
        d.tagName && (f.tagName = d.tagName);
        c = {
            containerProduct: "GTM",
            key: f,
            version: e,
            messageType: a
        };
        c.containerProduct = en ? "OGT" : "GTM";
        c.key.targetRef = nn;
        return c
    }
    var mn = "",
        ln = "",
        nn = {
            ctid: "",
            isDestination: !1
        },
        kn;

    function on(a) {
        var b = C(5),
            c = Bj(),
            d = C(6),
            e = C(1);
        C(23);
        Xm = 0;
        Ym = !0;
        dn();
        kn = a;
        mn = b;
        ln = e;
        en = Ti;
        nn = {
            ctid: b,
            isDestination: c,
            canonicalId: d
        }
    };
    var pn = [K.m.X, K.m.ja, K.m.W, K.m.La],
        qn, rn;

    function sn(a) {
        var b = a[K.m.fc];
        b || (b = [""]);
        for (var c = {
                ng: 0
            }; c.ng < b.length; c = {
                ng: c.ng
            }, ++c.ng) xb(a, function(d) {
            return function(e, f) {
                if (e !== K.m.fc) {
                    var g = Pm(f),
                        h = b[d.ng],
                        l = um(),
                        n = vm();
                    ml = !0;
                    ll && jb("TAGGING", 20);
                    hl().declare(e, g, h, l, n)
                }
            }
        }(c))
    }

    function tn(a) {
        km();
        !rn && qn && lm("crc");
        rn = !0;
        var b = a[K.m.Gg];
        b && N(41);
        var c = a[K.m.fc];
        c ? N(40) : c = [""];
        for (var d = {
                og: 0
            }; d.og < c.length; d = {
                og: d.og
            }, ++d.og) xb(a, function(e) {
            return function(f, g) {
                if (f !== K.m.fc && f !== K.m.Gg) {
                    var h = Qm(g),
                        l = c[e.og],
                        n = Number(b),
                        p = um(),
                        q = vm();
                    n = n === void 0 ? 0 : n;
                    ll = !0;
                    ml && jb("TAGGING", 20);
                    hl().default(f, h, l, p, q, n, ol)
                }
            }
        }(d))
    }

    function un(a) {
        ol.usedContainerScopedDefaults = !0;
        var b = a[K.m.fc];
        if (b) {
            var c = Array.isArray(b) ? b : [b];
            if (!c.includes(vm()) && !c.includes(um())) return
        }
        xb(a, function(d, e) {
            switch (d) {
                case "ad_storage":
                case "analytics_storage":
                case "ad_user_data":
                case "ad_personalization":
                    break;
                default:
                    return
            }
            ol.usedContainerScopedDefaults = !0;
            ol.containerScopedDefaults[d] = e === "granted" ? 3 : 2
        })
    }

    function vn(a, b) {
        km();
        qn = !0;
        xb(a, function(c, d) {
            var e = Pm(d);
            ll = !0;
            ml && jb("TAGGING", 20);
            hl().update(c, e, ol)
        });
        ul(b.eventId, b.priorityId)
    }

    function wn(a) {
        a.hasOwnProperty("all") && (ol.selectedAllCorePlatformServices = !0, xb(Nm, function(b) {
            ol.corePlatformServices[b] = a.all === "granted";
            ol.usedCorePlatformServices = !0
        }));
        xb(a, function(b, c) {
            b !== "all" && (ol.corePlatformServices[b] = c === "granted", ol.usedCorePlatformServices = !0)
        })
    }

    function xn(a) {
        Array.isArray(a) || (a = [a]);
        return a.every(function(b) {
            return pl(b)
        })
    }

    function yn(a, b) {
        tl(a, b)
    }

    function zn(a, b) {
        wl(a, b)
    }

    function Mn(a, b) {
        vl(a, b)
    }

    function Nn() {
        var a = [K.m.X, K.m.La, K.m.W];
        hl().waitForUpdate(a, 500, ol)
    }

    function On(a) {
        for (var b = m(a), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            hl().clearTimeout(d, void 0, ol)
        }
        ul()
    }

    function Pn() {
        if (!Ui)
            for (var a = xm() ? cj(eg(5)) : cj(eg(4)), b = 0; b < pn.length; b++) {
                var c = pn[b],
                    d = c,
                    e = a[c] ? "granted" : "denied";
                hl().implicit(d, e)
            }
    };
    var Qn = !1,
        Rn = [];

    function Sn() {
        if (!Qn) {
            Qn = !0;
            for (var a = Rn.length - 1; a >= 0; a--) Rn[a]();
            Rn = []
        }
    };
    var Tn = 0;

    function Un(a) {
        kk && a === void 0 && Tn === 0 && (Vl("mcc", "1"), Tn = 1)
    };

    function Vn() {
        var a = [],
            b = Number('') || 0,
            c = Number('') || 0;
        c || (c = b / 100);
        var d = function() {
            var la = !1;
            la = !0;
            return la
        }();
        a.push({
            oa: 21,
            studyId: 21,
            experimentId: 105102050,
            controlId: 105102051,
            controlId2: 105102052,
            probability: c,
            active: d,
            ka: 0
        });
        var e =
            Number('') || 0,
            f = Number('') || 0;
        f || (f = e / 100);
        var g = function() {
            var la = !1;
            la = !0;
            return la
        }();
        a.push({
            oa: 265,
            studyId: 265,
            experimentId: 115691063,
            controlId: 115691064,
            controlId2: 115691065,
            probability: f,
            active: g,
            ka: 0
        });
        var h = Number('') || 0,
            l = Number('') || 0;
        l || (l = h / 100);
        var n = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 228,
            studyId: 228,
            experimentId: 105177154,
            controlId: 105177155,
            controlId2: 105255245,
            probability: l,
            active: n,
            ka: 0
        });
        var p = Number('') ||
            0,
            q = Number('') || 0;
        q || (q = p / 100);
        var r = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 256,
            studyId: 256,
            experimentId: 115495938,
            controlId: 115495939,
            controlId2: 115495940,
            probability: q,
            active: r,
            ka: 0
        });
        var v = Number('') ||
            0,
            t = Number('') || 0;
        t || (t = v / 100);
        var u = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 257,
            studyId: 257,
            experimentId: 115495941,
            controlId: 115495942,
            controlId2: 115495943,
            probability: t,
            active: u,
            ka: 0
        });
        var x = Number('') || 0,
            y = Number('') || 0;
        y || (y = x / 100);
        var z = function() {
            var la = !1;
            la = !0;
            return la
        }();
        a.push({
            oa: 219,
            studyId: 219,
            experimentId: 104948811,
            controlId: 104948812,
            controlId2: 0,
            probability: y,
            active: z,
            ka: 0
        });
        var D = Number('') || 0,
            E = Number('1') || 0;
        E || (E = D / 100);
        var L = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 220,
            studyId: 220,
            experimentId: 104948813,
            controlId: 104948814,
            controlId2: 0,
            probability: E,
            active: L,
            ka: 0
        });
        var G = Number('') || 0,
            O = Number('0.01') || 0;
        O || (O = G / 100);
        var W = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 255,
            studyId: 255,
            experimentId: 105391252,
            controlId: 105391253,
            controlId2: 105446120,
            probability: O,
            active: W,
            ka: 0
        });
        var ia = Number('') || 0,
            T = Number('') || 0;
        T || (T = ia / 100);
        var ca = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 235,
            studyId: 235,
            experimentId: 105357150,
            controlId: 105357151,
            controlId2: 0,
            probability: T,
            active: ca,
            ka: 1
        });
        var va = Number('') || 0,
            ka = Number('') || 0;
        ka || (ka = va / 100);
        var Z = function() {
            var la = !1;
            la = !0;
            return la
        }();
        a.push({
            oa: 264,
            studyId: 264,
            experimentId: 115752876,
            controlId: 115752874,
            controlId2: 115752875,
            probability: ka,
            active: Z,
            ka: 0
        });
        var V = Number('') ||
            0,
            ja = Number('0.5') || 0;
        ja || (ja = V / 100);
        var ta = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 203,
            studyId: 203,
            experimentId: 115480710,
            controlId: 115480709,
            controlId2: 115489982,
            probability: ja,
            active: ta,
            ka: 0
        });
        var ua = Number('') || 0,
            Ta = Number('') ||
            0;
        Ta || (Ta = ua / 100);
        var Ya = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 178,
            studyId: 178,
            experimentId: 115958700,
            controlId: 115958701,
            controlId2: 115958702,
            probability: Ta,
            active: Ya,
            ka: 0
        });
        var Lb = Number('') || 0,
            Mb = Number('') || 0;
        Mb || (Mb = Lb / 100);
        var Pb = function() {
            var la = !1;
            la = !0;
            return la
        }();
        a.push({
            oa: 197,
            studyId: 197,
            experimentId: 105113532,
            controlId: 105113531,
            controlId2: 0,
            probability: Mb,
            active: Pb,
            ka: 0
        });
        var Zc = Number('') || 0,
            $c = Number('0.2') || 0;
        $c || ($c = Zc / 100);
        var Th = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 243,
            studyId: 243,
            experimentId: 115616985,
            controlId: 115616986,
            controlId2: 0,
            probability: $c,
            active: Th,
            ka: 0
        });
        var cH = Number('') || 0,
            An = Number('') || 0;
        An || (An = cH / 100);
        var dH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 171,
            studyId: 171,
            experimentId: 104967143,
            controlId: 104967140,
            controlId2: 0,
            probability: An,
            active: dH,
            ka: 0
        });
        var eH = Number('') || 0,
            Bn = Number('0') || 0;
        Bn || (Bn = eH / 100);
        var fH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 254,
            studyId: 254,
            experimentId: 115583767,
            controlId: 115583768,
            controlId2: 115583769,
            probability: Bn,
            active: fH,
            ka: 0
        });
        var gH = Number('') || 0,
            Cn = Number('') || 0;
        Cn || (Cn = gH / 100);
        var hH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 253,
            studyId: 253,
            experimentId: 115583770,
            controlId: 115583771,
            controlId2: 115583772,
            probability: Cn,
            active: hH,
            ka: 0
        });
        var iH = Number('') || 0,
            Dn = Number('') || 0;
        Dn || (Dn = iH / 100);
        var jH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 266,
            studyId: 266,
            experimentId: 115718529,
            controlId: 115718530,
            controlId2: 115718531,
            probability: Dn,
            active: jH,
            ka: 0
        });
        var kH = Number('') || 0,
            En = Number('') || 0;
        En || (En = kH / 100);
        var lH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 267,
            studyId: 267,
            experimentId: 115718526,
            controlId: 115718527,
            controlId2: 115718528,
            probability: En,
            active: lH,
            ka: 0
        });
        var mH = Number('') || 0,
            Fn = Number('0.1') || 0;
        Fn || (Fn = mH / 100);
        var nH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 259,
            studyId: 259,
            experimentId: 105322302,
            controlId: 105322303,
            controlId2: 105322304,
            probability: Fn,
            active: nH,
            ka: 0
        });
        var oH = Number('') || 0,
            Gn = Number('') || 0;
        Gn || (Gn = oH / 100);
        var pH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 249,
            studyId: 249,
            experimentId: 105440521,
            controlId: 105440522,
            controlId2: 0,
            focused: !0,
            probability: Gn,
            active: pH,
            ka: 0
        });
        var qH = Number('') || 0,
            Hn = Number('0.5') || 0;
        Hn || (Hn = qH / 100);
        var rH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 195,
            studyId: 195,
            experimentId: 104527906,
            controlId: 104527907,
            controlId2: 104898015,
            probability: Hn,
            active: rH,
            ka: 1
        });
        var sH = Number('') ||
            0,
            In = Number('0.5') || 0;
        In || (In = sH / 100);
        var tH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 196,
            studyId: 196,
            experimentId: 104528500,
            controlId: 104528501,
            controlId2: 104898016,
            probability: In,
            active: tH,
            ka: 0
        });
        var uH = Number('') || 0,
            Jn = Number('') ||
            0;
        Jn || (Jn = uH / 100);
        var vH = function() {
            var la = !1;
            la = !0;
            return la
        }();
        a.push({
            oa: 229,
            studyId: 229,
            experimentId: 105359938,
            controlId: 105359937,
            controlId2: 105359936,
            probability: Jn,
            active: vH,
            ka: 0
        });
        var wH = Number('') || 0,
            Kn = Number('0') ||
            0;
        Kn || (Kn = wH / 100);
        var xH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 261,
            studyId: 261,
            experimentId: 115811758,
            controlId: 115811759,
            controlId2: 0,
            probability: Kn,
            active: xH,
            ka: 1
        });
        var yH = Number('') || 0,
            Ln = Number('') || 0;
        Ln || (Ln = yH / 100);
        var zH = function() {
            var la = !1;
            return la
        }();
        a.push({
            oa: 225,
            studyId: 225,
            experimentId: 105476338,
            controlId: 105476339,
            controlId2: 105476599,
            probability: Ln,
            active: zH,
            ka: 0
        });
        return a
    };
    var Q = {
        A: {
            Eg: "accept_by_default",
            Fg: "add_tag_timing",
            Wd: "ads_event_page_view",
            bd: "allow_ad_personalization",
            dk: "batch_on_navigation",
            hk: "client_id_source",
            Ue: "consent_event_id",
            Ve: "consent_priority_id",
            Tr: "consent_state",
            fa: "consent_updated",
            Yd: "conversion_linker_enabled",
            Ea: "cookie_options",
            Ig: "create_dc_join",
            Jg: "create_fpm_geo_join",
            Kg: "create_fpm_signals_join",
            Zd: "create_google_join",
            Wh: "dc_random",
            ae: "em_event",
            Wr: "endpoint_for_debug",
            Ak: "enhanced_client_id_source",
            Xh: "enhanced_match_result",
            Bl: "euid_logged_in_state",
            ze: "euid_mode_enabled",
            eb: "event_start_timestamp_ms",
            Fl: "event_usage",
            zi: "extra_tag_experiment_ids",
            ns: "add_parameter",
            Ai: "attribution_reporting_experiment",
            Bi: "counting_method",
            jh: "send_as_iframe",
            qs: "parameter_order",
            kh: "parsed_target",
            cp: "ga4_collection_subdomain",
            Ul: "gbraid_cookie_marked",
            nh: "handle_internally",
            ba: "hit_type",
            zd: "hit_type_override",
            Sf: "ignore_hit_success_failure",
            vs: "is_config_command",
            ph: "is_consent_update",
            Tf: "is_conversion",
            am: "is_ecommerce",
            Bd: "is_external_event",
            Fi: "is_fallback_aw_conversion_ping_allowed",
            Uf: "is_first_visit",
            bm: "is_first_visit_conversion",
            qh: "is_fl_fallback_conversion_flow_allowed",
            Cd: "is_fpm_encryption",
            Gi: "is_fpm_split",
            Gb: "is_gcp_conversion",
            dm: "is_google_signals_allowed",
            Dd: "is_merchant_center",
            rh: "is_new_to_site",
            Hi: "is_personalization",
            sh: "is_server_side_destination",
            Ce: "is_session_start",
            gm: "is_session_start_conversion",
            ws: "is_sgtm_ga_ads_conversion_study_control_group",
            xs: "is_sgtm_prehit",
            hm: "is_sgtm_service_worker",
            Ii: "is_split_conversion",
            lp: "is_syn",
            Vf: "join_id",
            Ji: "join_elapsed",
            Wf: "join_timer_sec",
            Ge: "tunnel_updated",
            Bs: "prehit_for_retry",
            Ds: "promises",
            Es: "record_aw_latency",
            Qc: "redact_ads_data",
            He: "redact_click_ids",
            tm: "remarketing_only",
            Qi: "send_ccm_parallel_ping",
            Gs: "send_ccm_parallel_test_ping",
            cg: "send_to_destinations",
            Ri: "send_to_targets",
            yp: "send_user_data_hit",
            Oa: "source_canonical_id",
            ya: "speculative",
            Cm: "speculative_in_message",
            Dm: "suppress_script_load",
            Em: "syn_or_mod",
            Jm: "transient_ecsid",
            dg: "transmission_type",
            Sa: "user_data",
            Js: "user_data_from_automatic",
            Ks: "user_data_from_automatic_getter",
            Lm: "user_data_from_code",
            Ep: "user_data_from_manual",
            Mm: "user_data_mode",
            eg: "user_id_updated"
        }
    };
    var Wn = {};

    function Xn(a) {
        var b = a,
            c = a = Yn[b.studyId] ? na(Object, "assign").call(Object, {}, b, {
                active: !0
            }) : b;
        c.controlId2 && c.probability <= .25 || (c = na(Object, "assign").call(Object, {}, c, {
            controlId2: 0
        }));
        xi[c.studyId] = c;
        a.focused && (Wn[a.studyId] = !0);
        if (a.ka === 1) {
            var d = a.studyId;
            Zn(Ml(Hl.Z.Oi, {}), d);
            $n(d) && F(d)
        } else if (a.ka === 0) {
            var e = a.studyId;
            Zn(ao, e);
            $n(e) && F(e)
        }
    }

    function Zn(a, b) {
        if (xi[b]) {
            var c = xi[b],
                d = c.experimentId,
                e = c.probability;
            if (!(a.studies || {})[b]) {
                var f = a.studies || {};
                f[b] = !0;
                a.studies = f;
                xi[b].active || (xi[b].probability > .5 ? Bi(a, d, b) : e <= 0 || e > 1 || Ai.yr(a, b))
            }
        }
        if (!Wn[b]) {
            var g = Di(a, b);
            g && Ki.C.H.add(g)
        }
    }
    var ao = {};

    function $n(a) {
        return Ci(Ml(Hl.Z.Oi, {}), a) || Ci(ao, a)
    }

    function bo(a) {
        var b = R(a, Q.A.zi) || [];
        return Uj(b)
    }
    var Yn = {};

    function co() {
        Yn = {};
        var a, b, c = ((a = w) == null ? void 0 : (b = a.location) == null ? void 0 : b.hash) || "";
        if (c.indexOf("_te=") !== 0) {
            var d = c.substring(5);
            if (d)
                for (var e = m(d.split("~")), f = e.next(); !f.done; f = e.next()) {
                    var g = Number(f.value);
                    g && (Yn[g] = !0, F(g))
                }
        }
        for (var h = m(Vn()), l = h.next(); !l.done; l = h.next()) Xn(l.value);
        if (H(264)) {
            for (var n = [], p = m(fg(56) || []), q = p.next(); !q.done; q = p.next()) {
                var r = q.value,
                    v = {
                        studyId: r[1],
                        active: !!r[2],
                        probability: r[3] || 0,
                        experimentId: r[4] || 0,
                        controlId: r[5] || 0,
                        controlId2: r[6] || 0
                    },
                    t = 0;
                switch (r[7]) {
                    case 2:
                        t =
                            1;
                        break;
                    case 1:
                    case 0:
                        t = 0
                }
                var u;
                a: switch (v.studyId) {
                    case 249:
                        u = !0;
                        break a;
                    default:
                        u = !1
                }
                var x = na(Object, "assign").call(Object, {}, v, {
                    ka: t,
                    focused: u
                });
                (x.active || x.experimentId && x.controlId) && n.push(x)
            }
            for (var y = m(n), z = y.next(); !z.done; z = y.next()) Xn(z.value)
        }
    };
    var eo = {
        Qf: {
            Qn: "cd",
            Rn: "ce",
            Sn: "cf",
            Tn: "cpf",
            Un: "cu"
        }
    };
    var fo = w.google_tag_manager = w.google_tag_manager || {};

    function go(a, b) {
        return fo[a] = fo[a] || b()
    }

    function ho() {
        var a = C(5),
            b = io;
        fo[a] = fo[a] || b
    }

    function jo() {
        var a = C(19);
        return fo[a] = fo[a] || {}
    }

    function ko() {
        var a = C(19);
        return fo[a]
    }

    function lo() {
        var a = fo.sequence || 1;
        fo.sequence = a + 1;
        return a
    }
    w.google_tag_data = w.google_tag_data || {};
    var mo = /^(?:AW|DC|G|GF|GT|HA|MC|UA)$/,
        no = /\s/;

    function oo(a, b) {
        if (qb(a)) {
            a = Cb(a);
            var c = a.indexOf("-");
            if (!(c < 0)) {
                var d = a.substring(0, c);
                if (mo.test(d)) {
                    var e = a.substring(c + 1),
                        f;
                    if (b) {
                        var g = function(n) {
                            var p = n.indexOf("/");
                            return p < 0 ? [n] : [n.substring(0, p), n.substring(p + 1)]
                        };
                        f = g(e);
                        if (d === "DC" && f.length === 2) {
                            var h = g(f[1]);
                            h.length === 2 && (f[1] = h[0], f.push(h[1]))
                        }
                    } else {
                        f = e.split("/");
                        for (var l = 0; l < f.length; l++)
                            if (!f[l] || no.test(f[l]) && (d !== "AW" || l !== 1)) return
                    }
                    return {
                        id: a,
                        prefix: d,
                        destinationId: d + "-" + f[0],
                        ids: f
                    }
                }
            }
        }
    }

    function po(a, b) {
        for (var c = {}, d = 0; d < a.length; ++d) {
            var e = oo(a[d], b);
            e && (c[e.id] = e)
        }
        var f = [],
            g;
        for (g in c)
            if (c.hasOwnProperty(g)) {
                var h = c[g];
                h.prefix === "AW" && h.ids[qo[1]] && f.push(h.destinationId)
            }
        for (var l = 0; l < f.length; ++l) delete c[f[l]];
        for (var n = [], p = m(Object.keys(c)), q = p.next(); !q.done; q = p.next()) n.push(c[q.value]);
        return n
    }
    var ro = {},
        qo = (ro[0] = 0, ro[1] = 1, ro[2] = 2, ro[3] = 0, ro[4] = 1, ro[5] = 0, ro[6] = 0, ro[7] = 0, ro);
    var so = gg(34, 500),
        to = {},
        uo = {},
        vo = {
            initialized: 11,
            complete: 12,
            interactive: 13
        },
        wo = {},
        xo = Object.freeze((wo[K.m.rd] = !0, wo)),
        yo = void 0;

    function zo(a, b) {
        if (b.length && kk) {
            var c;
            (c = to)[a] != null || (c[a] = []);
            uo[a] != null || (uo[a] = []);
            var d = b.filter(function(e) {
                return !uo[a].includes(e)
            });
            to[a].push.apply(to[a], Aa(d));
            uo[a].push.apply(uo[a], Aa(d));
            !yo && d.length > 0 && (Wl("tdc", !0), yo = w.setTimeout(function() {
                $l();
                to = {};
                yo = void 0
            }, so))
        }
    }

    function Ao(a, b) {
        var c = {},
            d;
        for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
        for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
        return c
    }

    function Bo(a, b, c, d) {
        c = c === void 0 ? {} : c;
        d = d === void 0 ? "" : d;
        if (a === b) return [];
        var e = function(r, v) {
                var t;
                qd(v) === "object" ? t = v[r] : qd(v) === "array" && (t = v[r]);
                return t === void 0 ? xo[r] : t
            },
            f = Ao(a, b),
            g;
        for (g in f)
            if (f.hasOwnProperty(g)) {
                var h = (d ? d + "." : "") + g,
                    l = e(g, a),
                    n = e(g, b),
                    p = qd(l) === "object" || qd(l) === "array",
                    q = qd(n) === "object" || qd(n) === "array";
                if (p && q) Bo(l, n, c, h);
                else if (p || q || l !== n) c[h] = !0
            }
        return Object.keys(c)
    }

    function Co() {
        Vl("tdc", function() {
            yo && (w.clearTimeout(yo), yo = void 0);
            var a = [],
                b;
            for (b in to) to.hasOwnProperty(b) && a.push(b + "*" + to[b].join("."));
            return a.length ? a.join("!") : void 0
        }, !1)
    };
    var Do = {
        R: {
            bk: 1,
            Si: 2,
            Wj: 3,
            uk: 4,
            Xj: 5,
            ed: 6,
            tk: 7,
            pp: 8,
            vm: 9,
            Yj: 10,
            Zj: 11,
            mh: 12,
            Ml: 13,
            Jl: 14,
            Ll: 15,
            Il: 16,
            Kl: 17,
            Hl: 18,
            Hn: 19,
            ap: 20,
            bp: 21,
            Mi: 22
        }
    };
    Do.R[Do.R.bk] = "ALLOW_INTEREST_GROUPS";
    Do.R[Do.R.Si] = "SERVER_CONTAINER_URL";
    Do.R[Do.R.Wj] = "ADS_DATA_REDACTION";
    Do.R[Do.R.uk] = "CUSTOMER_LIFETIME_VALUE";
    Do.R[Do.R.Xj] = "ALLOW_CUSTOM_SCRIPTS";
    Do.R[Do.R.ed] = "ANY_COOKIE_PARAMS";
    Do.R[Do.R.tk] = "COOKIE_EXPIRES";
    Do.R[Do.R.pp] = "LEGACY_ENHANCED_CONVERSION_JS_VARIABLE";
    Do.R[Do.R.vm] = "RESTRICTED_DATA_PROCESSING";
    Do.R[Do.R.Yj] = "ALLOW_DISPLAY_FEATURES";
    Do.R[Do.R.Zj] = "ALLOW_GOOGLE_SIGNALS";
    Do.R[Do.R.mh] = "GENERATED_TRANSACTION_ID";
    Do.R[Do.R.Ml] = "FLOODLIGHT_COUNTING_METHOD_UNKNOWN";
    Do.R[Do.R.Jl] = "FLOODLIGHT_COUNTING_METHOD_STANDARD";
    Do.R[Do.R.Ll] = "FLOODLIGHT_COUNTING_METHOD_UNIQUE";
    Do.R[Do.R.Il] = "FLOODLIGHT_COUNTING_METHOD_PER_SESSION";
    Do.R[Do.R.Kl] = "FLOODLIGHT_COUNTING_METHOD_TRANSACTIONS";
    Do.R[Do.R.Hl] = "FLOODLIGHT_COUNTING_METHOD_ITEMS_SOLD";
    Do.R[Do.R.Hn] = "ADS_OGT_V1_USAGE";
    Do.R[Do.R.ap] = "FORM_INTERACTION_PERMISSION_DENIED";
    Do.R[Do.R.bp] = "FORM_SUBMIT_PERMISSION_DENIED";
    Do.R[Do.R.Mi] = "MICROTASK_NOT_SUPPORTED";
    var Eo = {},
        Fo = (Eo[K.m.Zh] = Do.R.bk, Eo[K.m.ud] = Do.R.Si, Eo[K.m.qc] = Do.R.Si, Eo[K.m.Ha] = Do.R.Wj, Eo[K.m.ne] = Do.R.uk, Eo[K.m.cf] = Do.R.Xj, Eo[K.m.xc] = Do.R.ed, Eo[K.m.Wa] = Do.R.ed, Eo[K.m.sb] = Do.R.ed, Eo[K.m.ld] = Do.R.ed, Eo[K.m.Qb] = Do.R.ed, Eo[K.m.Cb] = Do.R.ed, Eo[K.m.tb] = Do.R.tk, Eo[K.m.Rb] = Do.R.vm, Eo[K.m.Mg] = Do.R.Yj, Eo[K.m.Ob] = Do.R.Zj, Eo),
        Go = {},
        Ho = (Go.unknown = Do.R.Ml, Go.standard = Do.R.Jl, Go.unique = Do.R.Ll, Go.per_session = Do.R.Il, Go.transactions = Do.R.Kl, Go.items_sold = Do.R.Hl, Go);
    var mb = [];

    function Io(a, b) {
        b = b === void 0 ? !1 : b;
        jb("GTAG_EVENT_FEATURE_CHANNEL", a);
        b && (mb[a] = !0)
    }

    function Jo(a, b) {
        b = b === void 0 ? !1 : b;
        for (var c = Object.keys(a), d = m(Object.keys(Fo)), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            c.includes(f) && Io(Fo[f], b)
        }
    };
    var Ko = function(a, b, c, d, e, f, g, h, l, n, p) {
            this.eventId = a;
            this.priorityId = b;
            this.C = c;
            this.V = d;
            this.H = e;
            this.T = f;
            this.P = g;
            this.eventMetadata = h;
            this.onSuccess = l;
            this.onFailure = n;
            this.isGtmEvent = p
        },
        Lo = function(a, b) {
            var c = [];
            switch (b) {
                case 3:
                    c.push(a.C);
                    c.push(a.V);
                    c.push(a.H);
                    c.push(a.T);
                    c.push(a.P);
                    break;
                case 2:
                    c.push(a.C);
                    break;
                case 1:
                    c.push(a.V);
                    c.push(a.H);
                    c.push(a.T);
                    c.push(a.P);
                    break;
                case 4:
                    c.push(a.C), c.push(a.V), c.push(a.H), c.push(a.T)
            }
            return c
        },
        P = function(a, b, c, d) {
            for (var e = m(Lo(a, d === void 0 ? 3 :
                    d)), f = e.next(); !f.done; f = e.next()) {
                var g = f.value;
                if (g[b] !== void 0) return g[b]
            }
            return c
        },
        Mo = function(a) {
            for (var b = {}, c = Lo(a, 4), d = m(c), e = d.next(); !e.done; e = d.next())
                for (var f = Object.keys(e.value), g = m(f), h = g.next(); !h.done; h = g.next()) b[h.value] = 1;
            return Object.keys(b)
        };
    Ko.prototype.getMergedValues = function(a, b, c) {
        function d(n) {
            sd(n) && xb(n, function(p, q) {
                f = !0;
                e[p] = q
            })
        }
        b = b === void 0 ? 3 : b;
        var e = {},
            f = !1;
        c && d(c);
        var g = Lo(this, b);
        g.reverse();
        for (var h = m(g), l = h.next(); !l.done; l = h.next()) d(l.value[a]);
        return f ? e : void 0
    };
    var No = function(a) {
            for (var b = [K.m.qf, K.m.kf, K.m.lf, K.m.nf, K.m.pf, K.m.rf, K.m.tf], c = Lo(a, 3), d = m(c), e = d.next(); !e.done; e = d.next()) {
                for (var f = e.value, g = {}, h = !1, l = m(b), n = l.next(); !n.done; n = l.next()) {
                    var p = n.value;
                    f[p] !== void 0 && (g[p] = f[p], h = !0)
                }
                var q = h ? g : void 0;
                if (q) return q
            }
            return {}
        },
        Oo = function(a, b) {
            this.eventId = a;
            this.priorityId = b;
            this.H = {};
            this.V = {};
            this.C = {};
            this.P = {};
            this.la = {};
            this.T = {};
            this.eventMetadata = {};
            this.isGtmEvent = !1;
            this.onSuccess = function() {};
            this.onFailure = function() {}
        },
        Po = function(a,
            b) {
            a.H = b;
            return a
        },
        Qo = function(a, b) {
            a.V = b;
            return a
        },
        Ro = function(a, b) {
            a.C = b;
            return a
        },
        So = function(a, b) {
            a.P = b;
            return a
        },
        To = function(a, b) {
            a.la = b;
            return a
        },
        Uo = function(a, b) {
            a.T = b;
            return a
        },
        Vo = function(a, b) {
            a.eventMetadata = b || {};
            return a
        },
        Wo = function(a, b) {
            a.onSuccess = b;
            return a
        },
        Xo = function(a, b) {
            a.onFailure = b;
            return a
        },
        Yo = function(a, b) {
            a.isGtmEvent = b;
            return a
        },
        Zo = function(a) {
            return new Ko(a.eventId, a.priorityId, a.H, a.V, a.C, a.P, a.T, a.eventMetadata, a.onSuccess, a.onFailure, a.isGtmEvent)
        };
    var $o = new wb,
        ap = {},
        bp = {},
        ep = {
            name: C(19),
            set: function(a, b) {
                td(Nb(a, b), ap);
                cp()
            },
            get: function(a) {
                return dp(a, 2)
            },
            reset: function() {
                $o = new wb;
                ap = {};
                cp()
            }
        };

    function dp(a, b) {
        return b != 2 ? $o.get(a) : fp(a)
    }

    function fp(a, b) {
        var c = a.split(".");
        b = b || [];
        for (var d = ap, e = 0; e < c.length; e++) {
            if (d === null) return !1;
            if (d === void 0) break;
            d = d[c[e]];
            if (b.indexOf(d) !== -1) return
        }
        return d
    }

    function gp(a, b) {
        bp.hasOwnProperty(a) || ($o.set(a, b), td(Nb(a, b), ap), cp())
    }

    function hp() {
        for (var a = ["gtm.allowlist", "gtm.blocklist", "gtm.whitelist", "gtm.blacklist", "tagTypeBlacklist"], b = 0; b < a.length; b++) {
            var c = a[b],
                d = dp(c, 1);
            if (Array.isArray(d) || sd(d)) d = td(d, null);
            bp[c] = d
        }
    }

    function cp(a) {
        xb(bp, function(b, c) {
            $o.set(b, c);
            td(Nb(b), ap);
            td(Nb(b, c), ap);
            a && delete bp[b]
        })
    }

    function ip(a, b) {
        var c, d = (b === void 0 ? 2 : b) !== 1 ? fp(a) : $o.get(a);
        qd(d) === "array" || qd(d) === "object" ? c = td(d, null) : c = d;
        return c
    };
    var jp = {
        UA: 1,
        AW: 2,
        DC: 3,
        G: 4,
        GF: 5,
        GT: 12,
        GTM: 14,
        HA: 6,
        MC: 7
    };

    function kp(a) {
        a = a === void 0 ? {} : a;
        var b = C(5).split("-")[0].toUpperCase(),
            c, d = {
                ctid: C(5),
                un: dg(15),
                xn: C(14),
                Sq: cg(7) ? 2 : 1,
                Fr: a.zn,
                canonicalId: C(6),
                vr: (c = Jj()) == null ? void 0 : c.canonicalContainerId,
                Gr: a.Td === void 0 ? void 0 : a.Td ? 10 : 12
            };
        d.canonicalId !== a.Pa && (d.Pa = a.Pa);
        var e = Gj();
        d.Zq = e ? e.canonicalContainerId : void 0;
        Ti ? (d.Ph = jp[b], d.Ph || (d.Ph = 0)) : d.Ph = Ui ? 13 : 10;
        cg(47) ? (d.Dj = 0, d.Rp = 2) : cg(50) ? d.Dj = 1 : d.Dj = 3;
        var f = {
            6: !1
        };
        dg(54) === 2 ? f[7] = !0 : dg(54) === 1 && (f[2] = !0);
        if (Cc) {
            var g = ij(oj(Cc), "host");
            g && (f[8] = g.match(/^(www\.)?googletagmanager\.com$/) ===
                null)
        }
        d.Xp = f;
        return mf(d, a.Ah)
    };
    var lp = {
            Gn: gg(3, 0)
        },
        mp = [],
        np = !1;

    function op(a) {
        mp.push(a)
    }
    var pp = void 0,
        qp = {},
        rp = void 0,
        sp = new function() {
            var a = 5;
            lp.Gn > 0 && (a = lp.Gn);
            this.H = a;
            this.C = 0;
            this.P = []
        },
        tp = 1E3;

    function up(a, b) {
        var c = pp;
        if (c === void 0)
            if (b) c = lo();
            else return "";
        for (var d = [ck("https://" + C(21)), "/a", "?id=" + C(5)], e = m(mp), f = e.next(); !f.done; f = e.next())
            for (var g = f.value, h = g({
                    eventId: c,
                    Vd: !!a
                }), l = m(h), n = l.next(); !n.done; n = l.next()) {
                var p = m(n.value),
                    q = p.next().value,
                    r = p.next().value;
                d.push("&" + q + "=" + r)
            }
        d.push("&z=0");
        return d.join("")
    }

    function vp() {
        if (Ki.H && (rp && (w.clearTimeout(rp), rp = void 0), pp !== void 0 && wp)) {
            var a = Gl(gl.aa.Nc);
            if (Cl(a)) np || (np = !0, El(a, vp));
            else {
                var b;
                if (!(b = qp[pp])) {
                    var c = sp;
                    b = c.C < c.H ? !1 : Eb() - c.P[c.C % c.H] < 1E3
                }
                if (b || tp-- <= 0) N(1), qp[pp] = !0;
                else {
                    var d = sp,
                        e = d.C++ % d.H;
                    d.P[e] = Eb();
                    var f = up(!0);
                    al({
                        destinationId: C(5),
                        endpoint: 56,
                        eventId: pp
                    }, f);
                    np = wp = !1
                }
            }
        }
    }

    function xp() {
        if (ik && Ki.H) {
            var a = up(!0, !0);
            al({
                destinationId: C(5),
                endpoint: 56,
                eventId: pp
            }, a)
        }
    }
    var wp = !1;

    function yp(a) {
        qp[a] || (a !== pp && (vp(), pp = a), wp = !0, rp || (rp = w.setTimeout(vp, 500)), up().length >= 2022 && vp())
    }
    var zp = ub();

    function Ap() {
        zp = ub()
    }

    function Bp() {
        var a = [
                ["v", "3"],
                ["t", "t"],
                ["pid", String(zp)]
            ],
            b = kp();
        b && a.push(["gtm", b]);
        return a
    };
    var Cp = {};

    function Dp(a, b, c) {
        ik && a !== void 0 && (Cp[a] = Cp[a] || [], Cp[a].push(c + b), yp(a))
    }

    function Ep(a) {
        var b = a.eventId,
            c = a.Vd,
            d = [],
            e = Cp[b] || [];
        e.length && d.push(["epr", e.join(".")]);
        c && delete Cp[b];
        return d
    };

    function Fp(a, b, c, d) {
        var e = oo(c, d.isGtmEvent);
        e && (Si && (d.deferrable = !0), Gp.push("event", [b, a], e, d))
    }

    function Hp(a, b, c, d) {
        var e = oo(c, d.isGtmEvent);
        e && Gp.push("get", [a, b], e, d)
    }

    function Ip(a) {
        var b = oo(a, !0),
            c;
        b ? c = Jp(Gp, b).T : c = {};
        return c
    }
    var Kp = function() {
            this.C = {};
            this.T = {};
            this.V = {};
            this.la = null;
            this.P = {};
            this.H = !1;
            this.status = 1
        },
        Lp = function(a, b, c, d) {
            this.H = Eb();
            this.C = b;
            this.args = c;
            this.messageContext = d;
            this.type = a
        },
        Mp = function() {
            this.destinations = {};
            this.C = {};
            this.commands = []
        },
        Jp = function(a, b) {
            return a.destinations[b.destinationId] = a.destinations[b.destinationId] || new Kp
        },
        Np = function(a, b, c, d) {
            if (d.C) {
                var e = Jp(a, d.C),
                    f = e.la;
                if (f) {
                    var g = td(c, null),
                        h = td(e.C[d.C.id], null),
                        l = td(e.P, null),
                        n = td(e.T, null),
                        p = td(a.C, null),
                        q = {};
                    if (ik) try {
                        q =
                            td(ap, null)
                    } catch (x) {
                        N(72)
                    }
                    var r = d.C.prefix,
                        v = function(x) {
                            Dp(d.messageContext.eventId, r, x)
                        },
                        t = Zo(Yo(Xo(Wo(Vo(To(So(Uo(Ro(Qo(Po(new Oo(d.messageContext.eventId, d.messageContext.priorityId), g), h), l), n), p), q), d.messageContext.eventMetadata), function() {
                            if (v) {
                                var x = v;
                                v = void 0;
                                x("2");
                                if (d.messageContext.onSuccess) d.messageContext.onSuccess()
                            }
                        }), function() {
                            if (v) {
                                var x = v;
                                v = void 0;
                                x("3");
                                if (d.messageContext.onFailure) d.messageContext.onFailure()
                            }
                        }), !!d.messageContext.isGtmEvent)),
                        u = function() {
                            try {
                                Dp(d.messageContext.eventId,
                                    r, "1");
                                var x = d.type,
                                    y = d.C.id;
                                if (kk && x === "config") {
                                    var z, D = (z = oo(y)) == null ? void 0 : z.ids;
                                    if (!(D && D.length > 1)) {
                                        var E, L = Dc("google_tag_data", {});
                                        L.td || (L.td = {});
                                        E = L.td;
                                        var G = td(t.T);
                                        td(t.C, G);
                                        var O = [],
                                            W;
                                        for (W in E) E.hasOwnProperty(W) && Bo(E[W], G).length && O.push(W);
                                        O.length && (zo(y, O), jb("TAGGING", vo[A.readyState] || 14));
                                        E[y] = G
                                    }
                                }
                                f(d.C.id, b, d.H, t)
                            } catch (ia) {
                                Dp(d.messageContext.eventId, r, "4")
                            }
                        };
                    b === "gtag.get" ? u() : El(e.xa, u)
                }
            }
        };
    Mp.prototype.register = function(a, b, c, d) {
        var e = Jp(this, a);
        e.status !== 3 && (e.la = b, e.status = 3, e.xa = Gl(c), Op(this, a, d || {}), this.flush())
    };
    Mp.prototype.push = function(a, b, c, d) {
        c !== void 0 && (Jp(this, c).status === 1 && (Jp(this, c).status = 2, this.push("require", [{}], c, {})), Jp(this, c).H && (d.deferrable = !1), d.eventMetadata || (d.eventMetadata = {}), d.eventMetadata[Q.A.cg] || (d.eventMetadata[Q.A.cg] = [c.destinationId]), d.eventMetadata[Q.A.Ri] || (d.eventMetadata[Q.A.Ri] = [c.id]));
        this.commands.push(new Lp(a, c, b, d));
        d.deferrable || this.flush()
    };
    Mp.prototype.flush = function(a) {
        for (var b = this, c = [], d = !1, e = {}; this.commands.length; e = {
                Sc: void 0,
                Ch: void 0,
                dj: void 0,
                ej: void 0
            }) {
            var f = this.commands[0],
                g = f.C;
            if (f.messageContext.deferrable) !g || Jp(this, g).H ? (f.messageContext.deferrable = !1, this.commands.push(f)) : c.push(f), this.commands.shift();
            else {
                switch (f.type) {
                    case "require":
                        if (Jp(this, g).status !== 3 && !a) {
                            this.commands.push.apply(this.commands, c);
                            return
                        }
                        break;
                    case "set":
                        var h = f.args[0];
                        xb(h, function(u, x) {
                            td(Nb(u, x), b.C)
                        });
                        Jo(h, !0);
                        break;
                    case "config":
                        var l =
                            Jp(this, g);
                        e.Sc = {};
                        xb(f.args[0], function(u) {
                            return function(x, y) {
                                td(Nb(x, y), u.Sc)
                            }
                        }(e));
                        var n = !!e.Sc[K.m.wd];
                        delete e.Sc[K.m.wd];
                        var p = g.destinationId === g.id;
                        Jo(e.Sc, !0);
                        n || (p ? l.P = {} : l.C[g.id] = {});
                        l.H && n || Np(this, K.m.ma, e.Sc, f);
                        l.H = !0;
                        p ? td(e.Sc, l.P) : (td(e.Sc, l.C[g.id]), N(70));
                        d = !0;
                        break;
                    case "event":
                        e.Ch = {};
                        xb(f.args[0], function(u) {
                            return function(x, y) {
                                td(Nb(x, y), u.Ch)
                            }
                        }(e));
                        Jo(e.Ch);
                        Np(this, f.args[1], e.Ch, f);
                        break;
                    case "get":
                        var q = {},
                            r = (q[K.m.yf] = f.args[0], q[K.m.xf] = f.args[1], q);
                        Np(this, K.m.mc, r,
                            f);
                        break;
                    case "container_config":
                        var v = Jp(this, g);
                        e.dj = {};
                        xb(f.args[0], function(u) {
                            return function(x, y) {
                                td(Nb(x, y), u.dj)
                            }
                        }(e));
                        v.P = e.dj;
                        d = v.H = !0;
                        break;
                    case "destination_config":
                        var t = Jp(this, g);
                        e.ej = {};
                        xb(f.args[0], function(u) {
                            return function(x, y) {
                                td(Nb(x, y), u.ej)
                            }
                        }(e));
                        t.C[g.id] || (t.C[g.id] = {});
                        t.C[g.id] = e.ej;
                        d = t.H = !0
                }
                this.commands.shift();
                Pp(this, f)
            }
        }
        this.commands.push.apply(this.commands, c);
        d && this.flush()
    };
    var Pp = function(a, b) {
            if (b.type !== "require")
                if (b.C)
                    for (var c = Jp(a, b.C).V[b.type] || [], d = 0; d < c.length; d++) c[d]();
                else
                    for (var e in a.destinations)
                        if (a.destinations.hasOwnProperty(e)) {
                            var f = a.destinations[e];
                            if (f && f.V)
                                for (var g = f.V[b.type] || [], h = 0; h < g.length; h++) g[h]()
                        }
        },
        Op = function(a, b, c) {
            var d = td(c, null);
            td(Jp(a, b).T, d);
            Jp(a, b).T = d
        },
        Gp = new Mp;

    function Qp(a) {
        var b = a.location.href;
        if (a === a.top) return {
            url: b,
            Qq: !0
        };
        var c = !1,
            d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        var e = a.location.ancestorOrigins;
        if (e) {
            var f = e[e.length - 1],
                g;
            f && ((g = b) == null ? void 0 : g.indexOf(f)) === -1 && (c = !1, b = f)
        }
        return {
            url: b,
            Qq: c
        }
    }

    function Rp(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    Gk(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch (c) {
            return !1
        }
    }

    function Sp() {
        for (var a = w, b = a; a && a != a.parent;) a = a.parent, Rp(a) && (b = a);
        return b
    };
    var Tp = function(a, b) {
            var c = function() {};
            c.prototype = a.prototype;
            var d = new c;
            a.apply(d, Array.prototype.slice.call(arguments, 1));
            return d
        },
        Up = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = null;
                    c()
                }
            }
        };

    function Vp(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    var Wp = function(a, b) {
            for (var c = a, d = 0; d < 50; ++d) {
                var e;
                try {
                    e = !(!c.frames || !c.frames[b])
                } catch (h) {
                    e = !1
                }
                if (e) return c;
                var f;
                a: {
                    try {
                        var g = c.parent;
                        if (g && g != c) {
                            f = g;
                            break a
                        }
                    } catch (h) {}
                    f = null
                }
                if (!(c = f)) break
            }
            return null
        },
        Xp = function(a) {
            var b = w;
            if (b.top == b) return 0;
            if (a === void 0 ? 0 : a) {
                var c = b.location.ancestorOrigins;
                if (c) return c[c.length - 1] == b.location.origin ? 1 : 2
            }
            return Rp(b.top) ? 1 : 2
        },
        Yp = function(a) {
            a = a === void 0 ? document : a;
            return a.createElement("img")
        };

    function Zp(a, b, c) {
        return typeof a.addEventListener === "function" ? (a.addEventListener(b, c, !1), !0) : !1
    }

    function $p(a, b, c) {
        typeof a.removeEventListener === "function" && a.removeEventListener(b, c, !1)
    };

    function aq(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = Yp(a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = wc(g, e);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                $p(e, "load", f);
                $p(e, "error", f)
            };
            Zp(e, "load", f);
            Zp(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }

    function bq(a) {
        var b;
        b = b === void 0 ? !1 : b;
        var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
        Vp(a, function(d, e) {
            if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d))
        });
        cq(c, b)
    }

    function cq(a, b) {
        var c = window,
            d;
        b = b === void 0 ? !1 : b;
        d = d === void 0 ? !1 : d;
        if (c.fetch) {
            var e = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            };
            d && (e.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? e.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : e.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            });
            c.fetch(a, e)
        } else aq(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d)
    };
    var dq = function() {
        this.la = this.la;
        this.T = this.T
    };
    dq.prototype.la = !1;
    dq.prototype.dispose = function() {
        this.la || (this.la = !0, this.P())
    };
    dq.prototype[ha.Symbol.dispose] = function() {
        this.dispose()
    };
    dq.prototype.addOnDisposeCallback = function(a, b) {
        this.la ? b !== void 0 ? a.call(b) : a() : (this.T || (this.T = []), b && (a = a.bind(b)), this.T.push(a))
    };
    dq.prototype.P = function() {
        if (this.T)
            for (; this.T.length;) this.T.shift()()
    };

    function eq(a) {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }
    var fq = function(a, b) {
        b = b === void 0 ? {} : b;
        dq.call(this);
        this.C = null;
        this.xa = {};
        this.Oc = 0;
        this.V = null;
        this.H = a;
        var c;
        this.wb = (c = b.timeoutMs) != null ? c : 500;
        var d;
        this.Za = (d = b.Ps) != null ? d : !1
    };
    ya(fq, dq);
    fq.prototype.P = function() {
        this.xa = {};
        this.V && ($p(this.H, "message", this.V), delete this.V);
        delete this.xa;
        delete this.H;
        delete this.C;
        dq.prototype.P.call(this)
    };
    var hq = function(a) {
        return typeof a.H.__tcfapi === "function" || gq(a) != null
    };
    fq.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.Za
            },
            d = Up(function() {
                return a(c)
            }),
            e = 0;
        this.wb !== -1 && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.wb));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = eq(c), c.internalBlockOnErrors = b.Za, h && c.internalErrorState === 0 || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            iq(this, "addEventListener", f)
        } catch (g) {
            c.tcString =
                "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    fq.prototype.removeEventListener = function(a) {
        a && a.listenerId && iq(this, "removeEventListener", null, a.listenerId)
    };
    var kq = function(a, b, c) {
            var d;
            d = d === void 0 ? "755" : d;
            var e;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var f = a.publisher.restrictions[b];
                    if (f !== void 0) {
                        e = f[d === void 0 ? "755" : d];
                        break a
                    }
                }
                e = void 0
            }
            var g = e;
            if (g === 0) return !1;
            var h = c;
            c === 2 ? (h = 0, g === 2 && (h = 1)) : c === 3 && (h = 1, g === 1 && (h = 0));
            var l;
            if (h === 0)
                if (a.purpose && a.vendor) {
                    var n = jq(a.vendor.consents, d === void 0 ? "755" : d);
                    l = n && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : n && jq(a.purpose.consents, b)
                } else l = !0;
            else l = h === 1 ? a.purpose && a.vendor ? jq(a.purpose.legitimateInterests,
                b) && jq(a.vendor.legitimateInterests, d === void 0 ? "755" : d) : !0 : !0;
            return l
        },
        jq = function(a, b) {
            return !(!a || !a[b])
        },
        iq = function(a, b, c, d) {
            c || (c = function() {});
            var e = a.H;
            if (typeof e.__tcfapi === "function") {
                var f = e.__tcfapi;
                f(b, 2, c, d)
            } else if (gq(a)) {
                lq(a);
                var g = ++a.Oc;
                a.xa[g] = c;
                if (a.C) {
                    var h = {};
                    a.C.postMessage((h.__tcfapiCall = {
                        command: b,
                        version: 2,
                        callId: g,
                        parameter: d
                    }, h), "*")
                }
            } else c({}, !1)
        },
        gq = function(a) {
            if (a.C) return a.C;
            a.C = Wp(a.H, "__tcfapiLocator");
            return a.C
        },
        lq = function(a) {
            if (!a.V) {
                var b = function(c) {
                    try {
                        var d;
                        d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                        a.xa[d.callId](d.returnValue, d.success)
                    } catch (e) {}
                };
                a.V = b;
                Zp(a.H, "message", b)
            }
        },
        mq = function(a) {
            if (a.gdprApplies === !1) return !0;
            a.internalErrorState === void 0 && (a.internalErrorState = eq(a));
            return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (bq({
                e: String(a.internalErrorState)
            }), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
        };
    var nq = {
        1: 0,
        3: 0,
        4: 0,
        7: 3,
        9: 3,
        10: 3
    };
    gg(32, 500);

    function oq() {
        return go("tcf", function() {
            return {}
        })
    }
    var pq = function() {
        return new fq(w, {
            timeoutMs: -1
        })
    };

    function qq() {
        var a = oq(),
            b = pq();
        hq(b) && !rq() && !sq() && N(124);
        if (!a.active && hq(b)) {
            rq() && (a.active = !0, a.purposes = {}, a.cmpId = 0, a.tcfPolicyVersion = 0, hl().active = !0, a.tcString = "tcunavailable");
            Nn();
            try {
                b.addEventListener(function(c) {
                    if (c.internalErrorState !== 0) tq(a), On([K.m.X, K.m.La, K.m.W]), hl().active = !0;
                    else if (a.gdprApplies = c.gdprApplies, a.cmpId = c.cmpId, a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode, sq() && (a.active = !0), !uq(c) || rq() || sq()) {
                        a.tcfPolicyVersion = c.tcfPolicyVersion;
                        var d;
                        if (c.gdprApplies ===
                            !1) {
                            var e = {},
                                f;
                            for (f in nq) nq.hasOwnProperty(f) && (e[f] = !0);
                            d = e;
                            b.removeEventListener(c)
                        } else if (uq(c)) {
                            var g = {},
                                h;
                            for (h in nq)
                                if (nq.hasOwnProperty(h))
                                    if (h === "1") {
                                        var l, n = c,
                                            p = {
                                                tq: !0
                                            };
                                        p = p === void 0 ? {} : p;
                                        l = mq(n) ? n.gdprApplies === !1 ? !0 : n.tcString === "tcunavailable" ? !p.idpcApplies : (p.idpcApplies || n.gdprApplies !== void 0 || p.tq) && (p.idpcApplies || typeof n.tcString === "string" && n.tcString.length) ? kq(n, "1", 0) : !0 : !1;
                                        g["1"] = l
                                    } else g[h] = kq(c, h, nq[h]);
                            d = g
                        }
                        if (d) {
                            a.tcString = c.tcString || "tcempty";
                            a.purposes = d;
                            var q = {},
                                r = (q[K.m.X] = a.purposes["1"] ? "granted" : "denied", q);
                            a.gdprApplies !== !0 ? (On([K.m.X, K.m.La, K.m.W]), hl().active = !0) : (r[K.m.La] = a.purposes["3"] && a.purposes["4"] ? "granted" : "denied", typeof a.tcfPolicyVersion === "number" && a.tcfPolicyVersion >= 4 ? r[K.m.W] = a.purposes["1"] && a.purposes["7"] ? "granted" : "denied" : On([K.m.W]), vn(r, {
                                eventId: 0
                            }, {
                                gdprApplies: a ? a.gdprApplies : void 0,
                                tcString: vq() || ""
                            }))
                        }
                    } else On([K.m.X, K.m.La, K.m.W])
                })
            } catch (c) {
                tq(a), On([K.m.X, K.m.La, K.m.W]), hl().active = !0
            }
        }
    }

    function tq(a) {
        a.type = "e";
        a.tcString = "tcunavailable"
    }

    function uq(a) {
        return a.eventStatus === "tcloaded" || a.eventStatus === "useractioncomplete" || a.eventStatus === "cmpuishown"
    }

    function rq() {
        return w.gtag_enable_tcf_support === !0
    }

    function sq() {
        return oq().enableAdvertiserConsentMode === !0
    }

    function vq() {
        var a = oq();
        if (a.active) return a.tcString
    }

    function wq() {
        var a = oq();
        if (a.active && a.gdprApplies !== void 0) return a.gdprApplies ? "1" : "0"
    }

    function xq(a) {
        if (!nq.hasOwnProperty(String(a))) return !0;
        var b = oq();
        return b.active && b.purposes ? !!b.purposes[String(a)] : !0
    };
    var yq = [K.m.X, K.m.ja, K.m.W, K.m.La],
        zq = {},
        Aq = (zq[K.m.X] = 1, zq[K.m.ja] = 2, zq);

    function Bq(a) {
        if (a === void 0) return 0;
        switch (P(a, K.m.Nb)) {
            case void 0:
                return 1;
            case !1:
                return 3;
            default:
                return 2
        }
    }

    function Cq() {
        return (H(183) ? eg(16).split("~") : eg(17).split("~")).indexOf(vm()) !== -1 && zc.globalPrivacyControl === !0
    }

    function Dq(a) {
        if (Cq()) return !1;
        var b = Bq(a);
        if (b === 3) return !1;
        switch (ql(K.m.La)) {
            case 1:
            case 3:
                return !0;
            case 2:
                return !1;
            case 4:
                return b === 2;
            case 0:
                return !0;
            default:
                return !1
        }
    }

    function Eq() {
        return sl() || !pl(K.m.X) || !pl(K.m.ja)
    }

    function Fq() {
        var a = {},
            b;
        for (b in Aq) Aq.hasOwnProperty(b) && (a[Aq[b]] = ql(b));
        return "G1" + jf(a[1] || 0) + jf(a[2] || 0)
    }
    var Gq = {},
        Hq = (Gq[K.m.X] = 0, Gq[K.m.ja] = 1, Gq[K.m.W] = 2, Gq[K.m.La] = 3, Gq);

    function Iq(a) {
        switch (a) {
            case void 0:
                return 1;
            case !0:
                return 3;
            case !1:
                return 2;
            default:
                return 0
        }
    }

    function Jq(a) {
        for (var b = "1", c = 0; c < yq.length; c++) {
            var d = b,
                e, f = yq[c],
                g = ol.delegatedConsentTypes[f];
            e = g === void 0 ? 0 : Hq.hasOwnProperty(g) ? 12 | Hq[g] : 8;
            var h = hl();
            h.accessedAny = !0;
            var l = h.entries[f] || {};
            e = e << 2 | Iq(l.implicit);
            b = d + ("" + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [e] + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [Iq(l.declare) << 4 | Iq(l.default) << 2 | Iq(l.update)])
        }
        var n = b,
            p = (Cq() ? 1 : 0) << 3,
            q = (sl() ? 1 : 0) << 2,
            r = Bq(a);
        b = n + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [p |
            q | r
        ];
        return b += "" + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [ol.containerScopedDefaults.ad_storage << 4 | ol.containerScopedDefaults.analytics_storage << 2 | ol.containerScopedDefaults.ad_user_data] + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [(ol.usedContainerScopedDefaults ? 1 : 0) << 2 | ol.containerScopedDefaults.ad_personalization]
    }

    function Kq() {
        if (!pl(K.m.W)) return "-";
        for (var a = Object.keys(Nm), b = {}, c = m(a), d = c.next(); !d.done; d = c.next()) {
            var e = d.value;
            b[e] = ol.corePlatformServices[e] !== !1
        }
        for (var f = "", g = m(a), h = g.next(); !h.done; h = g.next()) {
            var l = h.value;
            b[l] && (f += Nm[l])
        }(ol.usedCorePlatformServices ? ol.selectedAllCorePlatformServices : 1) && (f += "o");
        return f || "-"
    }

    function Lq() {
        return xm() || (rq() || sq()) && wq() === "1" ? "1" : "0"
    }

    function Mq() {
        return (xm() ? !0 : !(!rq() && !sq()) && wq() === "1") || !pl(K.m.W)
    }

    function Nq() {
        var a = "0",
            b = "0",
            c;
        var d = oq();
        c = d.active ? d.cmpId : void 0;
        typeof c === "number" && c >= 0 && c <= 4095 && (a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c >> 6 & 63], b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c & 63]);
        var e = "0",
            f;
        var g = oq();
        f = g.active ? g.tcfPolicyVersion : void 0;
        typeof f === "number" && f >= 0 && f <= 63 && (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [f]);
        var h = 0;
        xm() && (h |= 1);
        wq() === "1" && (h |= 2);
        rq() && (h |= 4);
        var l;
        var n = oq();
        l = n.enableAdvertiserConsentMode !==
            void 0 ? n.enableAdvertiserConsentMode ? "1" : "0" : void 0;
        l === "1" && (h |= 8);
        hl().waitPeriodTimedOut && (h |= 16);
        return "1" + a + b + e + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [h]
    }

    function Oq() {
        return vm() === "US-CO"
    };

    function Pq(a, b, c, d) {
        var e, f = Number(a.Wc != null ? a.Wc : void 0);
        f !== 0 && (e = new Date((b || Eb()) + 1E3 * (f || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: e,
            vc: d
        }
    };
    var Qq = ["ad_storage", "ad_user_data"];

    function Rq(a, b) {
        if (!a) return jb("TAGGING", 32), 10;
        if (b === null || b === void 0 || b === "") return jb("TAGGING", 33), 11;
        var c = Sq(!1);
        if (c.error !== 0) return jb("TAGGING", 34), c.error;
        if (!c.value) return jb("TAGGING", 35), 2;
        c.value[a] = b;
        var d = Tq(c);
        d !== 0 && jb("TAGGING", 36);
        return d
    }

    function Uq(a) {
        if (!a) return jb("TAGGING", 27), {
            error: 10
        };
        var b = Sq();
        if (b.error !== 0) return jb("TAGGING", 29), b;
        if (!b.value) return jb("TAGGING", 30), {
            error: 2
        };
        if (!(a in b.value)) return jb("TAGGING", 31), {
            value: void 0,
            error: 15
        };
        var c = b.value[a];
        return c === null || c === void 0 || c === "" ? (jb("TAGGING", 28), {
            value: void 0,
            error: 11
        }) : {
            value: c,
            error: 0
        }
    }

    function Sq(a) {
        a = a === void 0 ? !0 : a;
        if (!pl(Qq)) return jb("TAGGING", 43), {
            error: 3
        };
        try {
            if (!w.localStorage) return jb("TAGGING", 44), {
                error: 1
            }
        } catch (f) {
            return jb("TAGGING", 45), {
                error: 14
            }
        }
        var b = {
                schema: "gcl",
                version: 1
            },
            c = void 0;
        try {
            c = w.localStorage.getItem("_gcl_ls")
        } catch (f) {
            return jb("TAGGING", 46), {
                error: 13
            }
        }
        try {
            if (c) {
                var d = JSON.parse(c);
                if (d && typeof d === "object") b = d;
                else return jb("TAGGING", 47), {
                    error: 12
                }
            }
        } catch (f) {
            return jb("TAGGING", 48), {
                error: 8
            }
        }
        if (b.schema !== "gcl") return jb("TAGGING", 49), {
            error: 4
        };
        if (b.version !== 1) return jb("TAGGING", 50), {
            error: 5
        };
        try {
            var e = Vq(b);
            a && e && Tq({
                value: b,
                error: 0
            })
        } catch (f) {
            return jb("TAGGING", 48), {
                error: 8
            }
        }
        return {
            value: b,
            error: 0
        }
    }

    function Vq(a) {
        if (!a || typeof a !== "object") return !1;
        if ("expires" in a && "value" in a) {
            var b;
            typeof a.expires === "number" ? b = a.expires : b = typeof a.expires === "string" ? Number(a.expires) : NaN;
            if (isNaN(b) || !(Date.now() <= b)) return a.value = null, a.error = 9, jb("TAGGING", 54), !0
        } else {
            for (var c = !1, d = m(Object.keys(a)), e = d.next(); !e.done; e = d.next()) c = Vq(a[e.value]) || c;
            return c
        }
        return !1
    }

    function Tq(a) {
        if (a.error) return a.error;
        if (!a.value) return jb("TAGGING", 42), 2;
        var b = a.value,
            c;
        try {
            c = JSON.stringify(b)
        } catch (d) {
            return jb("TAGGING", 52), 6
        }
        try {
            w.localStorage.setItem("_gcl_ls", c)
        } catch (d) {
            return jb("TAGGING", 53), 7
        }
        return 0
    };
    var Wq = {
            wg: "value",
            fb: "conversionCount",
            Lh: 1
        },
        Xq = {
            Ih: 9,
            Oh: 10,
            wg: "timeouts",
            fb: "timeouts",
            Lh: 0
        },
        Yq = [Wq, Xq, {
            Ih: 11,
            Oh: 12,
            wg: "eopCount",
            fb: "endOfPageCount",
            Lh: 0
        }, {
            Ih: 11,
            Oh: 12,
            wg: "errors",
            fb: "errors",
            Lh: 0
        }];

    function Zq(a) {
        var b;
        b = b === void 0 ? 1 : b;
        if (!$q(a)) return {};
        var c = ar(Yq),
            d = c[a.fb];
        if (d === void 0 || d === -1) return c;
        var e = {},
            f = na(Object, "assign").call(Object, {}, c, (e[a.fb] = d + b, e));
        return br(f) ? f : c
    }

    function ar(a) {
        var b;
        a: {
            var c = Uq("gcl_ctr");
            if (c.error === 0 && c.value && typeof c.value === "object") {
                var d = c.value;
                try {
                    b = "value" in d && typeof d.value === "object" ? d.value : void 0;
                    break a
                } catch (p) {}
            }
            b = void 0
        }
        for (var e = b, f = {}, g = m(a), h = g.next(); !h.done; h = g.next()) {
            var l = h.value;
            if (e && $q(l)) {
                var n = e[l.wg];
                n === void 0 || Number.isNaN(n) ? f[l.fb] = -1 : f[l.fb] = Number(n)
            } else f[l.fb] = -1
        }
        return f
    }

    function cr() {
        for (var a = Zq(Wq), b = [], c = m(Yq), d = c.next(); !d.done; d = c.next()) {
            var e = d.value,
                f = a[e.fb];
            if (f === void 0 || f < e.Lh) break;
            b.push(f.toString())
        }
        return b.join("~")
    }

    function br(a, b) {
        b = b || {};
        for (var c = Eb(), d = Pq(b, c, !0), e = {}, f = m(Yq), g = f.next(); !g.done; g = f.next()) {
            var h = g.value,
                l = a[h.fb];
            l !== void 0 && l !== -1 && (e[h.wg] = l)
        }
        e.creationTimeMs = c;
        return Rq("gcl_ctr", {
            value: e,
            expires: Number(d.expires)
        }) === 0 ? !0 : !1
    }

    function $q(a) {
        return pl(["ad_storage", "ad_user_data"]) ? !a.Oh || Wa(a.Oh) : !1
    }

    function dr(a) {
        return pl(["ad_storage", "ad_user_data"]) ? !a.Ih || Wa(a.Ih) : !1
    };
    var er = {
        N: {
            xp: 0,
            Vj: 1,
            Hg: 2,
            kk: 3,
            Sh: 4,
            ik: 5,
            jk: 6,
            lk: 7,
            Th: 8,
            Dl: 9,
            Cl: 10,
            yi: 11,
            El: 12,
            ih: 13,
            Nl: 14,
            Yf: 15,
            wp: 16,
            Ie: 17,
            Wi: 18,
            Xi: 19,
            Yi: 20,
            Gm: 21,
            Zi: 22,
            Vh: 23,
            vk: 24
        }
    };
    er.N[er.N.xp] = "RESERVED_ZERO";
    er.N[er.N.Vj] = "ADS_CONVERSION_HIT";
    er.N[er.N.Hg] = "CONTAINER_EXECUTE_START";
    er.N[er.N.kk] = "CONTAINER_SETUP_END";
    er.N[er.N.Sh] = "CONTAINER_SETUP_START";
    er.N[er.N.ik] = "CONTAINER_BLOCKING_END";
    er.N[er.N.jk] = "CONTAINER_EXECUTE_END";
    er.N[er.N.lk] = "CONTAINER_YIELD_END";
    er.N[er.N.Th] = "CONTAINER_YIELD_START";
    er.N[er.N.Dl] = "EVENT_EXECUTE_END";
    er.N[er.N.Cl] = "EVENT_EVALUATION_END";
    er.N[er.N.yi] = "EVENT_EVALUATION_START";
    er.N[er.N.El] = "EVENT_SETUP_END";
    er.N[er.N.ih] = "EVENT_SETUP_START";
    er.N[er.N.Nl] = "GA4_CONVERSION_HIT";
    er.N[er.N.Yf] = "PAGE_LOAD";
    er.N[er.N.wp] = "PAGEVIEW";
    er.N[er.N.Ie] = "SNIPPET_LOAD";
    er.N[er.N.Wi] = "TAG_CALLBACK_ERROR";
    er.N[er.N.Xi] = "TAG_CALLBACK_FAILURE";
    er.N[er.N.Yi] = "TAG_CALLBACK_SUCCESS";
    er.N[er.N.Gm] = "TAG_EXECUTE_END";
    er.N[er.N.Zi] = "TAG_EXECUTE_START";
    er.N[er.N.Vh] = "CUSTOM_PERFORMANCE_START";
    er.N[er.N.vk] = "CUSTOM_PERFORMANCE_END";
    var fr = [],
        gr = {},
        hr = {};

    function ir(a) {
        if (Wa(19) && fr.includes(a)) {
            var b;
            (b = hd()) == null || b.mark(a + "-" + er.N.Vh + "-" + (hr[a] || 0))
        }
    }

    function jr(a) {
        if (Wa(19) && fr.includes(a)) {
            var b = a + "-" + er.N.vk + "-" + (hr[a] || 0),
                c = {
                    start: a + "-" + er.N.Vh + "-" + (hr[a] || 0),
                    end: b
                },
                d;
            (d = hd()) == null || d.mark(b);
            var e, f, g = (f = (e = hd()) == null ? void 0 : e.measure(b, c)) == null ? void 0 : f.duration;
            g !== void 0 && (hr[a] = (hr[a] || 0) + 1, gr[a] = g + (gr[a] || 0))
        }
    };
    var kr = ["2", "3"];

    function lr(a) {
        return a.origin !== "null"
    };

    function mr(a, b, c, d) {
        try {
            ir("3");
            var e;
            return (e = nr(function(f) {
                return f === a
            }, b, c, d)[a]) != null ? e : []
        } finally {
            jr("3")
        }
    }

    function nr(a, b, c, d) {
        var e;
        if (or(d)) {
            for (var f = {}, g = String(b || pr()).split(";"), h = 0; h < g.length; h++) {
                var l = g[h].split("="),
                    n = l[0].trim();
                if (n && a(n)) {
                    var p = l.slice(1).join("=").trim();
                    p && c && (p = decodeURIComponent(p));
                    var q = void 0,
                        r = void 0;
                    ((q = f)[r = n] || (q[r] = [])).push(p)
                }
            }
            e = f
        } else e = {};
        return e
    }

    function qr(a, b, c, d, e) {
        if (or(e)) {
            var f = rr(a, d, e);
            if (f.length === 1) return f[0];
            if (f.length !== 0) {
                f = sr(f, function(g) {
                    return g.jq
                }, b);
                if (f.length === 1) return f[0];
                f = sr(f, function(g) {
                    return g.er
                }, c);
                return f[0]
            }
        }
    }

    function tr(a, b, c, d) {
        var e = pr(),
            f = window;
        lr(f) && (f.document.cookie = a);
        var g = pr();
        return e !== g || c !== void 0 && mr(b, g, !1, d).indexOf(c) >= 0
    }

    function ur(a, b, c, d) {
        function e(x, y, z) {
            if (z == null) return delete h[y], x;
            h[y] = z;
            return x + "; " + y + "=" + z
        }

        function f(x, y) {
            if (y == null) return x;
            h[y] = !0;
            return x + "; " + y
        }
        if (!or(c.vc)) return 2;
        var g;
        b == null ? g = a + "=deleted; expires=" + (new Date(0)).toUTCString() : (c.encode && (b = encodeURIComponent(b)), b = vr(b), g = a + "=" + b);
        var h = {};
        g = e(g, "path", c.path);
        var l;
        c.expires instanceof Date ? l = c.expires.toUTCString() : c.expires != null && (l = "" + c.expires);
        g = e(g, "expires", l);
        g = e(g, "max-age", c.Vq);
        g = e(g, "samesite", c.xr);
        c.secure &&
            (g = f(g, "secure"));
        var n = c.domain;
        if (n && n.toLowerCase() === "auto") {
            for (var p = wr(), q = void 0, r = !1, v = 0; v < p.length; ++v) {
                var t = p[v] !== "none" ? p[v] : void 0,
                    u = e(g, "domain", t);
                u = f(u, c.flags);
                try {
                    d && d(a, h)
                } catch (x) {
                    q = x;
                    continue
                }
                r = !0;
                if (!xr(t, c.path) && tr(u, a, b, c.vc)) return 0
            }
            if (q && !r) throw q;
            return 1
        }
        n && n.toLowerCase() !== "none" && (g = e(g, "domain", n));
        g = f(g, c.flags);
        d && d(a, h);
        return xr(n, c.path) ? 1 : tr(g, a, b, c.vc) ? 0 : 1
    }

    function yr(a, b, c) {
        c.path == null && (c.path = "/");
        c.domain || (c.domain = "auto");
        ir("2");
        var d = ur(a, b, c);
        jr("2");
        return d
    }

    function sr(a, b, c) {
        for (var d = [], e = [], f, g = 0; g < a.length; g++) {
            var h = a[g],
                l = b(h);
            l === c ? d.push(h) : f === void 0 || l < f ? (e = [h], f = l) : l === f && e.push(h)
        }
        return d.length > 0 ? d : e
    }

    function rr(a, b, c) {
        for (var d = [], e = mr(a, void 0, void 0, c), f = 0; f < e.length; f++) {
            var g = e[f].split("."),
                h = g.shift();
            if (!b || !h || b.indexOf(h) !== -1) {
                var l = g.shift();
                if (l) {
                    var n = l.split("-");
                    d.push({
                        Zp: e[f],
                        aq: g.join("."),
                        jq: Number(n[0]) || 1,
                        er: Number(n[1]) || 1
                    })
                }
            }
        }
        return d
    }

    function vr(a) {
        a && a.length > 1200 && (a = a.substring(0, 1200));
        return a
    }
    var zr = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        Ar = /(^|\.)doubleclick\.net$/i;

    function xr(a, b) {
        return a !== void 0 && (Ar.test(window.document.location.hostname) || b === "/" && zr.test(a))
    }

    function Br(a) {
        if (!a) return 1;
        var b = a;
        Wa(6) && a === "none" && (b = window.document.location.hostname);
        b = b.indexOf(".") === 0 ? b.substring(1) : b;
        return b.split(".").length
    }

    function Cr(a) {
        if (!a || a === "/") return 1;
        a[0] !== "/" && (a = "/" + a);
        a[a.length - 1] !== "/" && (a += "/");
        return a.split("/").length - 1
    }

    function Dr(a, b) {
        var c = "" + Br(a),
            d = Cr(b);
        d > 1 && (c += "-" + d);
        return c
    }
    var pr = function() {
            return lr(window) ? window.document.cookie : ""
        },
        or = function(a) {
            return a && Wa(7) ? (Array.isArray(a) ? a : [a]).every(function(b) {
                return rl(b) && pl(b)
            }) : !0
        },
        wr = function() {
            var a = [],
                b = window.document.location.hostname.split(".");
            if (b.length === 4) {
                var c = b[b.length - 1];
                if (Number(c).toString() === c) return ["none"]
            }
            for (var d = b.length - 2; d >= 0; d--) a.push(b.slice(d).join("."));
            var e = window.document.location.hostname;
            Ar.test(e) || zr.test(e) || a.push("none");
            return a
        };

    function Er(a) {
        var b = Math.round(Math.random() * 2147483647);
        return a ? String(b ^ Vh(a) & 2147483647) : String(b)
    }

    function Fr(a) {
        return [Er(a), Math.round(Eb() / 1E3)].join(".")
    }

    function Gr(a, b, c, d, e) {
        var f = Br(b),
            g;
        return (g = qr(a, f, Cr(c), d, e)) == null ? void 0 : g.aq
    };
    var Hr;

    function Ir() {
        function a(g) {
            c(g.target || g.srcElement || {})
        }

        function b(g) {
            d(g.target || g.srcElement || {})
        }
        var c = Jr,
            d = Kr,
            e = Lr();
        if (!e.init) {
            Qc(A, "mousedown", a);
            Qc(A, "keyup", a);
            Qc(A, "submit", b);
            var f = HTMLFormElement.prototype.submit;
            HTMLFormElement.prototype.submit = function() {
                d(this);
                f.call(this)
            };
            e.init = !0
        }
    }

    function Mr(a, b, c, d, e) {
        var f = {
            callback: a,
            domains: b,
            fragment: c === 2,
            placement: c,
            forms: d,
            sameHost: e
        };
        Lr().decorators.push(f)
    }

    function Nr(a, b, c) {
        for (var d = Lr().decorators, e = {}, f = 0; f < d.length; ++f) {
            var g = d[f],
                h;
            if (h = !c || g.forms) a: {
                var l = g.domains,
                    n = a,
                    p = !!g.sameHost;
                if (l && (p || n !== A.location.hostname))
                    for (var q = 0; q < l.length; q++)
                        if (l[q] instanceof RegExp) {
                            if (l[q].test(n)) {
                                h = !0;
                                break a
                            }
                        } else if (n.indexOf(l[q]) >= 0 || p && l[q].indexOf(n) >= 0) {
                    h = !0;
                    break a
                }
                h = !1
            }
            if (h) {
                var r = g.placement;
                r === void 0 && (r = g.fragment ? 2 : 1);
                r === b && Hb(e, g.callback())
            }
        }
        return e
    }

    function Lr() {
        var a = Dc("google_tag_data", {}),
            b = a.gl;
        b && b.decorators || (b = {
            decorators: []
        }, a.gl = b);
        return b
    };
    var Or = /(.*?)\*(.*?)\*(.*)/,
        Pr = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
        Qr = /^(?:www\.|m\.|amp\.)+/,
        Rr = /([^?#]+)(\?[^#]*)?(#.*)?/;

    function Sr(a) {
        var b = Rr.exec(a);
        if (b) return {
            Jj: b[1],
            query: b[2],
            fragment: b[3]
        }
    }

    function Tr(a) {
        return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)")
    }

    function Ur(a, b) {
        var c = [zc.userAgent, (new Date).getTimezoneOffset(), zc.userLanguage || zc.language, Math.floor(Eb() / 60 / 1E3) - (b === void 0 ? 0 : b), a].join("*"),
            d;
        if (!(d = Hr)) {
            for (var e = Array(256), f = 0; f < 256; f++) {
                for (var g = f, h = 0; h < 8; h++) g = g & 1 ? g >>> 1 ^ 3988292384 : g >>> 1;
                e[f] = g
            }
            d = e
        }
        Hr = d;
        for (var l = 4294967295, n = 0; n < c.length; n++) l = l >>> 8 ^ Hr[(l ^ c.charCodeAt(n)) & 255];
        return ((l ^ -1) >>> 0).toString(36)
    }

    function Vr(a) {
        return function(b) {
            var c = oj(w.location.href),
                d = c.search.replace("?", ""),
                e = fj(d, "_gl", !1, !0) || "";
            b.query = Wr(e) || {};
            var f = ij(c, "fragment"),
                g;
            var h = -1;
            if (Jb(f, "_gl=")) h = 4;
            else {
                var l = f.indexOf("&_gl=");
                l > 0 && (h = l + 3 + 2)
            }
            if (h < 0) g = void 0;
            else {
                var n = f.indexOf("&", h);
                g = n < 0 ? f.substring(h) : f.substring(h, n)
            }
            b.fragment = Wr(g || "") || {};
            a && Xr(c, d, f)
        }
    }

    function Yr(a, b) {
        var c = Tr(a).exec(b),
            d = b;
        if (c) {
            var e = c[2],
                f = c[4];
            d = c[1];
            f && (d = d + e + f)
        }
        return d
    }

    function Xr(a, b, c) {
        function d(g, h) {
            var l = Yr("_gl", g);
            l.length && (l = h + l);
            return l
        }
        if (yc && yc.replaceState) {
            var e = Tr("_gl");
            if (e.test(b) || e.test(c)) {
                var f = ij(a, "path");
                b = d(b, "?");
                c = d(c, "#");
                yc.replaceState({}, "", "" + f + b + c)
            }
        }
    }

    function Zr(a, b) {
        var c = Vr(!!b),
            d = Lr();
        d.data || (d.data = {
            query: {},
            fragment: {}
        }, c(d.data));
        var e = {},
            f = d.data;
        f && (Hb(e, f.query), a && Hb(e, f.fragment));
        return e
    }
    var Wr = function(a) {
        try {
            var b = $r(a, 3);
            if (b !== void 0) {
                for (var c = {}, d = b ? b.split("*") : [], e = 0; e + 1 < d.length; e += 2) {
                    var f = d[e],
                        g = hb(d[e + 1]);
                    c[f] = g
                }
                jb("TAGGING", 6);
                return c
            }
        } catch (h) {
            jb("TAGGING", 8)
        }
    };

    function $r(a, b) {
        if (a) {
            var c;
            a: {
                for (var d = a, e = 0; e < 3; ++e) {
                    var f = Or.exec(d);
                    if (f) {
                        c = f;
                        break a
                    }
                    d = hj(d) || ""
                }
                c = void 0
            }
            var g = c;
            if (g && g[1] === "1") {
                var h = g[3],
                    l;
                a: {
                    for (var n = g[2], p = 0; p < b; ++p)
                        if (n === Ur(h, p)) {
                            l = !0;
                            break a
                        }
                    l = !1
                }
                if (l) return h;
                jb("TAGGING", 7)
            }
        }
    }

    function as(a, b, c, d, e) {
        function f(p) {
            p = Yr(a, p);
            var q = p.charAt(p.length - 1);
            p && q !== "&" && (p += "&");
            return p + n
        }
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        var g = Sr(c);
        if (!g) return "";
        var h = g.query || "",
            l = g.fragment || "",
            n = a + "=" + b;
        d ? l.substring(1).length !== 0 && e || (l = "#" + f(l.substring(1))) : h = "?" + f(h.substring(1));
        return "" + g.Jj + h + l
    }

    function bs(a, b) {
        function c(n, p, q) {
            var r;
            a: {
                for (var v in n)
                    if (n.hasOwnProperty(v)) {
                        r = !0;
                        break a
                    }
                r = !1
            }
            if (r) {
                var t, u = [],
                    x;
                for (x in n)
                    if (n.hasOwnProperty(x)) {
                        var y = n[x];
                        y !== void 0 && y === y && y !== null && y.toString() !== "[object Object]" && (u.push(x), u.push(gb(String(y))))
                    }
                var z = u.join("*");
                t = ["1", Ur(z), z].join("*");
                d ? (Wa(3) || Wa(1) || !p) && cs("_gl", t, a, p, q) : ds("_gl", t, a, p, q)
            }
        }
        var d = (a.tagName || "").toUpperCase() === "FORM",
            e = Nr(b, 1, d),
            f = Nr(b, 2, d),
            g = Nr(b, 4, d),
            h = Nr(b, 3, d);
        c(e, !1, !1);
        c(f, !0, !1);
        Wa(1) && c(g, !0, !0);
        for (var l in h) h.hasOwnProperty(l) &&
            es(l, h[l], a)
    }

    function es(a, b, c) {
        c.tagName.toLowerCase() === "a" ? ds(a, b, c) : c.tagName.toLowerCase() === "form" && cs(a, b, c)
    }

    function ds(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        var f;
        if (f = c.href) {
            var g;
            if (!(g = !Wa(4) || d)) {
                var h = w.location.href,
                    l = Sr(c.href),
                    n = Sr(h);
                g = !(l && n && l.Jj === n.Jj && l.query === n.query && l.fragment)
            }
            f = g
        }
        if (f) {
            var p = as(a, b, c.href, d, e);
            oc.test(p) && (c.href = p)
        }
    }

    function cs(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        if (c) {
            var f = c.getAttribute("action") || "";
            if (f) {
                var g = (c.method || "").toLowerCase();
                if (g !== "get" || d) {
                    if (g === "get" || g === "post") {
                        var h = as(a, b, f, d, e);
                        oc.test(h) && (c.action = h)
                    }
                } else {
                    for (var l = c.childNodes || [], n = !1, p = 0; p < l.length; p++) {
                        var q = l[p];
                        if (q.name === a) {
                            q.setAttribute("value", b);
                            n = !0;
                            break
                        }
                    }
                    if (!n) {
                        var r = A.createElement("input");
                        r.setAttribute("type", "hidden");
                        r.setAttribute("name", a);
                        r.setAttribute("value", b);
                        c.appendChild(r)
                    }
                }
            }
        }
    }

    function Jr(a) {
        try {
            var b;
            a: {
                for (var c = a, d = 100; c && d > 0;) {
                    if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
                        b = c;
                        break a
                    }
                    c = c.parentNode;
                    d--
                }
                b = null
            }
            var e = b;
            if (e) {
                var f = e.protocol;
                f !== "http:" && f !== "https:" || bs(e, e.hostname)
            }
        } catch (g) {}
    }

    function Kr(a) {
        try {
            var b = a.getAttribute("action");
            if (b) {
                var c = ij(oj(b), "host");
                bs(a, c)
            }
        } catch (d) {}
    }

    function fs(a, b, c, d) {
        Ir();
        var e = c === "fragment" ? 2 : 1;
        d = !!d;
        Mr(a, b, e, d, !1);
        e === 2 && jb("TAGGING", 23);
        d && jb("TAGGING", 24)
    }

    function gs(a, b) {
        Ir();
        Mr(a, [kj(w.location, "host", !0)], b, !0, !0)
    }

    function hs() {
        var a = A.location.hostname,
            b = Pr.exec(A.referrer);
        if (!b) return !1;
        var c = b[2],
            d = b[1],
            e = "";
        if (c) {
            var f = c.split("/"),
                g = f[1];
            e = g === "s" ? hj(f[2]) || "" : hj(g) || ""
        } else if (d) {
            if (d.indexOf("xn--") === 0) return !1;
            e = d.replace(/-/g, ".").replace(/\.\./g, "-")
        }
        var h = a.replace(Qr, ""),
            l = e.replace(Qr, ""),
            n;
        if (!(n = h === l)) {
            var p = "." + l;
            n = h.length >= p.length && h.substring(h.length - p.length, h.length) === p
        }
        return n
    }

    function is(a, b) {
        return a === !1 ? !1 : a || b || hs()
    };
    var js = ["1"],
        ks = {},
        ls = {};

    function ms(a, b) {
        b = b === void 0 ? !0 : b;
        var c = ns(a.prefix);
        if (ks[c]) os(a);
        else if (ps(c, a.path, a.domain)) {
            var d = ls[ns(a.prefix)] || {
                id: void 0,
                Kh: void 0
            };
            b && qs(a, d.id, d.Kh);
            os(a)
        } else {
            var e = qj("auiddc");
            if (e) jb("TAGGING", 17), ks[c] = e;
            else if (b) {
                var f = ns(a.prefix),
                    g = Fr();
                rs(f, g, a);
                ps(c, a.path, a.domain);
                os(a, !0)
            }
        }
    }

    function os(a, b) {
        if ((b === void 0 ? 0 : b) && $q(Wq)) {
            var c = Sq(!1);
            c.error !== 0 ? jb("TAGGING", 38) : c.value ? "gcl_ctr" in c.value ? (delete c.value.gcl_ctr, Tq(c) !== 0 && jb("TAGGING", 41)) : jb("TAGGING", 40) : jb("TAGGING", 39)
        }
        if (dr(Wq) && ar([Wq])[Wq.fb] === -1) {
            for (var d = {}, e = (d[Wq.fb] = 0, d), f = m(Yq), g = f.next(); !g.done; g = f.next()) {
                var h = g.value;
                h !== Wq && dr(h) && (e[h.fb] = 0)
            }
            br(e, a)
        }
    }

    function qs(a, b, c) {
        var d = ns(a.prefix),
            e = ks[d];
        if (e) {
            var f = e.split(".");
            if (f.length === 2) {
                var g = Number(f[1]) || 0;
                if (g) {
                    var h = e;
                    b && (h = e + "." + b + "." + (c ? c : Math.floor(Eb() / 1E3)));
                    rs(d, h, a, g * 1E3)
                }
            }
        }
    }

    function rs(a, b, c, d) {
        var e;
        e = ["1", Dr(c.domain, c.path), b].join(".");
        var f = Pq(c, d);
        f.vc = ss();
        yr(a, e, f)
    }

    function ps(a, b, c) {
        var d = Gr(a, b, c, js, ss());
        if (!d) return !1;
        ts(a, d);
        return !0
    }

    function ts(a, b) {
        var c = b.split(".");
        c.length === 5 ? (ks[a] = c.slice(0, 2).join("."), ls[a] = {
            id: c.slice(2, 4).join("."),
            Kh: Number(c[4]) || 0
        }) : c.length === 3 ? ls[a] = {
            id: c.slice(0, 2).join("."),
            Kh: Number(c[2]) || 0
        } : ks[a] = b
    }

    function ns(a) {
        return (a || "_gcl") + "_au"
    }

    function us(a) {
        function b() {
            pl(c) && a()
        }
        var c = ss();
        vl(function() {
            b();
            pl(c) || wl(b, c)
        }, c)
    }

    function vs(a) {
        var b = Zr(!0),
            c = ns(a.prefix);
        us(function() {
            var d = b[c];
            if (d) {
                ts(c, d);
                var e = Number(ks[c].split(".")[1]) * 1E3;
                if (e) {
                    jb("TAGGING", 16);
                    var f = Pq(a, e);
                    f.vc = ss();
                    var g = ["1", Dr(a.domain, a.path), d].join(".");
                    yr(c, g, f)
                }
            }
        })
    }

    function ws(a, b, c, d, e) {
        e = e || {};
        var f = function() {
            var g = {},
                h = Gr(a, e.path, e.domain, js, ss());
            h && (g[a] = h);
            return g
        };
        us(function() {
            fs(f, b, c, d)
        })
    }

    function ss() {
        return ["ad_storage", "ad_user_data"]
    };

    function xs(a) {
        for (var b = [], c = A.cookie.split(";"), d = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"), e = 0; e < c.length; e++) {
            var f = c[e].match(d);
            f && b.push({
                Ud: f[1],
                value: f[2],
                timestamp: Number(f[2].split(".")[1]) || 0
            })
        }
        b.sort(function(g, h) {
            return h.timestamp - g.timestamp
        });
        return b
    }

    function ys(a, b) {
        var c = xs(a),
            d = {};
        if (!c || !c.length) return d;
        for (var e = 0; e < c.length; e++) {
            var f = c[e].value.split(".");
            if (!(f[0] !== "1" || b && f.length < 3 || !b && f.length !== 3) && Number(f[1])) {
                d[c[e].Ud] || (d[c[e].Ud] = []);
                var g = {
                    version: f[0],
                    timestamp: Number(f[1]) * 1E3,
                    gclid: f[2]
                };
                b && f.length > 3 && (g.labels = f.slice(3));
                d[c[e].Ud].push(g)
            }
        }
        return d
    };
    var zs = {},
        As = (zs.k = {
            ia: /^[\w-]+$/
        }, zs.b = {
            ia: /^[\w-]+$/,
            Mj: !0
        }, zs.i = {
            ia: /^[1-9]\d*$/
        }, zs.h = {
            ia: /^\d+$/
        }, zs.t = {
            ia: /^[1-9]\d*$/
        }, zs.d = {
            ia: /^[A-Za-z0-9_-]+$/
        }, zs.j = {
            ia: /^\d+$/
        }, zs.u = {
            ia: /^[1-9]\d*$/
        }, zs.l = {
            ia: /^[01]$/
        }, zs.o = {
            ia: /^[1-9]\d*$/
        }, zs.g = {
            ia: /^[01]$/
        }, zs.s = {
            ia: /^.+$/
        }, zs);
    var Bs = {},
        Fs = (Bs[5] = {
            Qh: {
                2: Cs
            },
            Cj: "2",
            Bh: ["k", "i", "b", "u"]
        }, Bs[4] = {
            Qh: {
                2: Cs,
                GCL: Ds
            },
            Cj: "2",
            Bh: ["k", "i", "b"]
        }, Bs[2] = {
            Qh: {
                GS2: Cs,
                GS1: Es
            },
            Cj: "GS2",
            Bh: "sogtjlhd".split("")
        }, Bs);

    function Gs(a, b, c) {
        var d = Fs[b];
        if (d) {
            var e = a.split(".")[0];
            c == null || c(e);
            if (e) {
                var f = d.Qh[e];
                if (f) return f(a, b)
            }
        }
    }

    function Cs(a, b) {
        var c = a.split(".");
        if (c.length === 3) {
            var d = c[2];
            if (d.indexOf("$") === -1 && d.indexOf("%24") !== -1) try {
                d = decodeURIComponent(d)
            } catch (v) {}
            var e = {},
                f = Fs[b];
            if (f) {
                for (var g = f.Bh, h = m(d.split("$")), l = h.next(); !l.done; l = h.next()) {
                    var n = l.value,
                        p = n[0];
                    if (g.indexOf(p) !== -1) try {
                        var q = decodeURIComponent(n.substring(1)),
                            r = As[p];
                        r && (r.Mj ? (e[p] = e[p] || [], e[p].push(q)) : e[p] = q)
                    } catch (v) {}
                }
                return e
            }
        }
    }

    function Hs(a, b, c) {
        var d = Fs[b];
        if (d) return [d.Cj, c || "1", Is(a, b)].join(".")
    }

    function Is(a, b) {
        var c = Fs[b];
        if (c) {
            for (var d = [], e = m(c.Bh), f = e.next(); !f.done; f = e.next()) {
                var g = f.value,
                    h = As[g];
                if (h) {
                    var l = a[g];
                    if (l !== void 0)
                        if (h.Mj && Array.isArray(l))
                            for (var n = m(l), p = n.next(); !p.done; p = n.next()) d.push(encodeURIComponent("" + g + p.value));
                        else d.push(encodeURIComponent("" + g + l))
                }
            }
            return d.join("$")
        }
    }

    function Ds(a) {
        var b = a.split(".");
        b.shift();
        var c = b.shift(),
            d = b.shift(),
            e = {};
        return e.k = d, e.i = c, e.b = b, e
    }

    function Es(a) {
        var b = a.split(".").slice(2);
        if (!(b.length < 5 || b.length > 7)) {
            var c = {};
            return c.s = b[0], c.o = b[1], c.g = b[2], c.t = b[3], c.j = b[4], c.l = b[5], c.h = b[6], c
        }
    };
    var Js = new Map([
        [5, "ad_storage"],
        [4, ["ad_storage", "ad_user_data"]],
        [2, "analytics_storage"]
    ]);

    function Ks(a, b, c) {
        if (Fs[b]) {
            for (var d = [], e = mr(a, void 0, void 0, Js.get(b)), f = m(e), g = f.next(); !g.done; g = f.next()) {
                var h = Gs(g.value, b, c);
                h && d.push(Ls(h))
            }
            return d
        }
    }

    function Ms(a) {
        var b = Ns;
        if (Fs[2]) {
            for (var c = {}, d = nr(a, void 0, void 0, Js.get(2)), e = Object.keys(d).sort(), f = m(e), g = f.next(); !g.done; g = f.next())
                for (var h = g.value, l = m(d[h]), n = l.next(); !n.done; n = l.next()) {
                    var p = Gs(n.value, 2, b);
                    p && (c[h] || (c[h] = []), c[h].push(Ls(p)))
                }
            return c
        }
    }

    function Os(a, b, c, d, e) {
        d = d || {};
        var f = Dr(d.domain, d.path),
            g = Hs(b, c, f);
        if (!g) return 1;
        var h = Pq(d, e, void 0, Js.get(c));
        return yr(a, g, h)
    }

    function Ps(a, b) {
        var c = b.ia;
        return typeof c === "function" ? c(a) : c.test(a)
    }

    function Ls(a) {
        for (var b = m(Object.keys(a)), c = b.next(), d = {}; !c.done; d = {
                hg: void 0
            }, c = b.next()) {
            var e = c.value,
                f = a[e];
            d.hg = As[e];
            d.hg ? d.hg.Mj ? a[e] = Array.isArray(f) ? f.filter(function(g) {
                return function(h) {
                    return Ps(h, g.hg)
                }
            }(d)) : void 0 : typeof f === "string" && Ps(f, d.hg) || (a[e] = void 0) : a[e] = void 0
        }
        return a
    };
    var Qs = function() {
        this.value = 0
    };
    Qs.prototype.set = function(a) {
        return this.value |= 1 << a
    };
    var Rs = function(a, b) {
        b <= 0 || (a.value |= 1 << b - 1)
    };
    Qs.prototype.get = function() {
        return this.value
    };
    Qs.prototype.clear = function(a) {
        this.value &= ~(1 << a)
    };
    Qs.prototype.clearAll = function() {
        this.value = 0
    };
    Qs.prototype.equals = function(a) {
        return this.value === a.value
    };

    function Ss(a) {
        if (a) try {
            return new Uint8Array(atob(a.replace(/-/g, "+").replace(/_/g, "/")).split("").map(function(b) {
                return b.charCodeAt(0)
            }))
        } catch (b) {}
    }

    function Ts(a, b) {
        var c = 0,
            d = 0,
            e, f = b;
        do {
            if (f >= a.length) return;
            e = a[f++];
            c |= (e & 127) << d;
            d += 7
        } while (e & 128);
        return [c, f]
    };

    function Us() {
        var a = String,
            b = w.location.hostname,
            c = w.location.pathname,
            d = b = Vb(b);
        d.split(".").length > 2 && (d = d.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
        b = d;
        c = Vb(c);
        var e = c.split(";")[0];
        e = e.replace(/\/(ar|slp|web|index)?\/?$/, "");
        return a(Vh(("" + b + e).toLowerCase()))
    };
    var Vs = {},
        Ws = (Vs.gclid = !0, Vs.dclid = !0, Vs.gbraid = !0, Vs.wbraid = !0, Vs),
        Xs = /^\w+$/,
        Ys = /^[\w-]+$/,
        Zs = {},
        $s = (Zs.aw = "_aw", Zs.dc = "_dc", Zs.gf = "_gf", Zs.gp = "_gp", Zs.gs = "_gs", Zs.ha = "_ha", Zs.ag = "_ag", Zs.gb = "_gb", Zs),
        at = /^(?:www\.)?google(?:\.com?)?(?:\.[a-z]{2}t?)?$/,
        bt = /^www\.googleadservices\.com$/;

    function ct() {
        return ["ad_storage", "ad_user_data"]
    }

    function dt(a) {
        return !Wa(7) || pl(a)
    }

    function et(a, b) {
        function c() {
            var d = dt(b);
            d && a();
            return d
        }
        vl(function() {
            c() || wl(c, b)
        }, b)
    }

    function ft(a) {
        return gt(a).map(function(b) {
            return b.gclid
        })
    }

    function ht(a) {
        return it(a).filter(function(b) {
            return b.gclid
        }).map(function(b) {
            return b.gclid
        })
    }

    function it(a) {
        var b = jt(a.prefix),
            c = kt("gb", b),
            d = kt("ag", b);
        if (!d || !c) return [];
        var e = function(h) {
                return function(l) {
                    l.type = h;
                    return l
                }
            },
            f = gt(c).map(e("gb")),
            g = lt(d).map(e("ag"));
        return f.concat(g).sort(function(h, l) {
            return l.timestamp - h.timestamp
        })
    }

    function mt(a, b, c, d, e) {
        var f = tb(a, function(g) {
            return g.gclid === b
        });
        f ? (f.timestamp < c && (f.timestamp = c, f.Vc = e), f.labels = nt(f.labels || [], d || [])) : a.push({
            version: "2",
            gclid: b,
            timestamp: c,
            labels: d,
            Vc: e
        })
    }

    function lt(a) {
        for (var b = Ks(a, 5) || [], c = [], d = m(b), e = d.next(); !e.done; e = d.next()) {
            var f = e.value,
                g = f,
                h = ot(f);
            h && mt(c, g.k, h, g.b || [], f.u)
        }
        return c.sort(function(l, n) {
            return n.timestamp - l.timestamp
        })
    }

    function gt(a) {
        for (var b = [], c = mr(a, A.cookie, void 0, ct()), d = m(c), e = d.next(); !e.done; e = d.next()) {
            var f = pt(e.value);
            f != null && (f.Vc = void 0, f.Ba = new Qs, f.ab = [1], qt(b, f))
        }
        b.sort(function(g, h) {
            return h.timestamp - g.timestamp
        });
        return rt(b)
    }

    function st(a, b) {
        for (var c = [], d = m(a), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            c.includes(f) || c.push(f)
        }
        for (var g = m(b), h = g.next(); !h.done; h = g.next()) {
            var l = h.value;
            c.includes(l) || c.push(l)
        }
        return c
    }

    function qt(a, b, c) {
        c = c === void 0 ? !1 : c;
        for (var d, e, f = m(a), g = f.next(); !g.done; g = f.next()) {
            var h = g.value;
            if (h.gclid === b.gclid) {
                d = h;
                break
            }
            h.Ba && b.Ba && h.Ba.equals(b.Ba) && (e = h)
        }
        if (d) {
            var l, n, p = (l = d.Ba) != null ? l : new Qs,
                q = (n = b.Ba) != null ? n : new Qs;
            p.value |= q.value;
            d.Ba = p;
            d.timestamp < b.timestamp && (d.timestamp = b.timestamp, d.Vc = b.Vc);
            d.labels = st(d.labels || [], b.labels || []);
            d.ab = st(d.ab || [], b.ab || [])
        } else c && e ? na(Object, "assign").call(Object, e, b) : a.push(b)
    }

    function tt(a) {
        if (!a) return new Qs;
        var b = new Qs;
        if (a === 1) return Rs(b, 2), Rs(b, 3), b;
        Rs(b, a);
        return b
    }

    function ut() {
        var a = Uq("gclid");
        if (!a || a.error || !a.value || typeof a.value !== "object") return null;
        var b = a.value;
        try {
            if (!("value" in b && b.value) || typeof b.value !== "object") return null;
            var c = b.value,
                d = c.value;
            if (!d || !d.match(Ys)) return null;
            var e = c.linkDecorationSource,
                f = c.linkDecorationSources,
                g = new Qs;
            typeof e === "number" ? g = tt(e) : typeof f === "number" && (g.value = f);
            return {
                version: "",
                gclid: d,
                timestamp: Number(c.creationTimeMs) || 0,
                labels: [],
                Ba: g,
                ab: [2]
            }
        } catch (h) {
            return null
        }
    }

    function vt() {
        var a = Uq("gcl_aw");
        if (a.error !== 0) return null;
        try {
            return a.value.reduce(function(b, c) {
                if (!c.value || typeof c.value !== "object") return b;
                var d = c.value,
                    e = d.value;
                if (!e || !e.match(Ys)) return b;
                var f = new Qs,
                    g = d.linkDecorationSources;
                typeof g === "number" && (f.value = g);
                b.push({
                    version: "",
                    gclid: e,
                    timestamp: Number(d.creationTimeMs) || 0,
                    expires: Number(c.expires) || 0,
                    labels: [],
                    Ba: f,
                    ab: [2]
                });
                return b
            }, [])
        } catch (b) {
            return null
        }
    }

    function wt(a) {
        for (var b = [], c = mr(a, A.cookie, void 0, ct()), d = m(c), e = d.next(); !e.done; e = d.next()) {
            var f = pt(e.value);
            f != null && (f.Vc = void 0, f.Ba = new Qs, f.ab = [1], qt(b, f))
        }
        var g = ut();
        g && (g.Vc = void 0, g.ab = g.ab || [2], qt(b, g));
        if (Wa(14)) {
            var h = vt();
            if (h)
                for (var l = m(h), n = l.next(); !n.done; n = l.next()) {
                    var p = n.value;
                    p.Vc = void 0;
                    p.ab = p.ab || [2];
                    qt(b, p)
                }
        }
        b.sort(function(q, r) {
            return r.timestamp - q.timestamp
        });
        return rt(b)
    }

    function nt(a, b) {
        if (!a.length) return b;
        if (!b.length) return a;
        var c = {};
        return a.concat(b).filter(function(d) {
            return c.hasOwnProperty(d) ? !1 : c[d] = !0
        })
    }

    function jt(a) {
        return a && typeof a === "string" && a.match(Xs) ? a : "_gcl"
    }

    function xt(a, b) {
        if (a) {
            var c = {
                value: a,
                Ba: new Qs
            };
            Rs(c.Ba, b);
            return c
        }
    }

    function zt(a, b, c) {
        var d = oj(a),
            e = ij(d, "query", !1, void 0, "gclsrc"),
            f = xt(ij(d, "query", !1, void 0, "gclid"), c ? 4 : 2);
        if (b && (!f || !e)) {
            var g = d.hash.replace("#", "");
            f || (f = xt(fj(g, "gclid", !1), 3));
            e || (e = fj(g, "gclsrc", !1))
        }
        return f && (e === void 0 || e === "aw" || e === "aw.ds" || Wa(18) && e === "aw.dv") ? [f] : []
    }

    function At(a, b) {
        var c = oj(a),
            d = ij(c, "query", !1, void 0, "gclid"),
            e = ij(c, "query", !1, void 0, "gclsrc"),
            f = ij(c, "query", !1, void 0, "wbraid");
        f = Tb(f);
        var g = ij(c, "query", !1, void 0, "gbraid"),
            h = ij(c, "query", !1, void 0, "gad_source"),
            l = ij(c, "query", !1, void 0, "dclid");
        if (b && !(d && e && f && g)) {
            var n = c.hash.replace("#", "");
            d = d || fj(n, "gclid", !1);
            e = e || fj(n, "gclsrc", !1);
            f = f || fj(n, "wbraid", !1);
            g = g || fj(n, "gbraid", !1);
            h = h || fj(n, "gad_source", !1)
        }
        return Bt(d, e, l, f, g, h)
    }

    function Ct() {
        return At(w.location.href, !0)
    }

    function Bt(a, b, c, d, e, f) {
        var g = {},
            h = function(l, n) {
                g[n] || (g[n] = []);
                g[n].push(l)
            };
        g.gclid = a;
        g.gclsrc = b;
        g.dclid = c;
        if (a !== void 0 && a.match(Ys)) switch (b) {
            case void 0:
                h(a, "aw");
                break;
            case "aw.ds":
                h(a, "aw");
                h(a, "dc");
                break;
            case "aw.dv":
                Wa(18) && (h(a, "aw"), h(a, "dc"));
                break;
            case "ds":
                h(a, "dc");
                break;
            case "3p.ds":
                h(a, "dc");
                break;
            case "gf":
                h(a, "gf");
                break;
            case "ha":
                h(a, "ha")
        }
        c && h(c, "dc");
        d !== void 0 && Ys.test(d) && (g.wbraid = d, h(d, "gb"));
        e !== void 0 && Ys.test(e) && (g.gbraid = e, h(e, "ag"));
        f !== void 0 && Ys.test(f) && (g.gad_source =
            f, h(f, "gs"));
        return g
    }

    function Dt(a) {
        for (var b = Ct(), c = !0, d = m(Object.keys(b)), e = d.next(); !e.done; e = d.next())
            if (b[e.value] !== void 0) {
                c = !1;
                break
            }
        c && (b = At(w.document.referrer, !1), b.gad_source = void 0);
        Et(b, !1, a)
    }

    function Ft(a) {
        Dt(a);
        var b = zt(w.location.href, !0, !1);
        b.length || (b = zt(w.document.referrer, !1, !0));
        a = a || {};
        Gt(a);
        if (b.length) {
            var c = b[0],
                d = Eb(),
                e = Pq(a, d, !0),
                f = ct(),
                g = function() {
                    dt(f) && e.expires !== void 0 && Rq("gclid", {
                        value: {
                            value: c.value,
                            creationTimeMs: d,
                            linkDecorationSources: c.Ba.get()
                        },
                        expires: Number(e.expires)
                    })
                };
            vl(function() {
                g();
                dt(f) || wl(g, f)
            }, f)
        }
    }

    function Gt(a) {
        var b;
        if (b = Wa(15)) {
            var c = Ht();
            b = at.test(c) || bt.test(c) || It()
        }
        if (b) {
            var d;
            a: {
                for (var e = oj(w.location.href), f = gj(ij(e, "query")), g = m(Object.keys(f)), h = g.next(); !h.done; h = g.next()) {
                    var l = h.value;
                    if (!Ws[l]) {
                        var n = f[l][0] || "",
                            p;
                        if (!n || n.length < 50 || n.length > 200) p = !1;
                        else {
                            var q = Ss(n),
                                r;
                            if (q) c: {
                                var v = q;
                                if (v && v.length !== 0) {
                                    var t = 0;
                                    try {
                                        for (var u = 10; t < v.length && !(u-- <= 0);) {
                                            var x = Ts(v, t);
                                            if (x === void 0) break;
                                            var y = m(x),
                                                z = y.next().value,
                                                D = y.next().value,
                                                E = z,
                                                L = D,
                                                G = E & 7;
                                            if (E >> 3 === 16382) {
                                                if (G !== 0) break;
                                                var O = Ts(v, L);
                                                if (O === void 0) break;
                                                r = m(O).next().value === 1;
                                                break c
                                            }
                                            var W;
                                            d: {
                                                var ia = void 0,
                                                    T = v,
                                                    ca = L;
                                                switch (G) {
                                                    case 0:
                                                        W = (ia = Ts(T, ca)) == null ? void 0 : ia[1];
                                                        break d;
                                                    case 1:
                                                        W = ca + 8;
                                                        break d;
                                                    case 2:
                                                        var va = Ts(T, ca);
                                                        if (va === void 0) break;
                                                        var ka = m(va),
                                                            Z = ka.next().value;
                                                        W = ka.next().value + Z;
                                                        break d;
                                                    case 5:
                                                        W = ca + 4;
                                                        break d
                                                }
                                                W = void 0
                                            }
                                            if (W === void 0 || W > v.length || W <= t) break;
                                            t = W
                                        }
                                    } catch (ja) {}
                                }
                                r = !1
                            }
                            else r = !1;
                            p = r
                        }
                        if (p) {
                            d = n;
                            break a
                        }
                    }
                }
                d = void 0
            }
            var V = d;
            V && Jt(V, 7, a)
        }
    }

    function Jt(a, b, c) {
        c = c || {};
        var d = Eb(),
            e = Pq(c, d, !0),
            f = ct(),
            g = function() {
                if (dt(f) && e.expires !== void 0) {
                    var h = vt() || [];
                    qt(h, {
                        version: "",
                        gclid: a,
                        timestamp: d,
                        expires: Number(e.expires),
                        Ba: tt(b)
                    }, !0);
                    Rq("gcl_aw", h.map(function(l) {
                        return {
                            value: {
                                value: l.gclid,
                                creationTimeMs: l.timestamp,
                                linkDecorationSources: l.Ba ? l.Ba.get() : 0
                            },
                            expires: Number(l.expires)
                        }
                    }))
                }
            };
        vl(function() {
            dt(f) ? g() : wl(g, f)
        }, f)
    }

    function Et(a, b, c, d, e) {
        c = c || {};
        e = e || [];
        var f = jt(c.prefix),
            g = d || Eb(),
            h = Math.round(g / 1E3),
            l = ct(),
            n = !1,
            p = !1,
            q = function() {
                if (dt(l)) {
                    var r = Pq(c, g, !0);
                    r.vc = l;
                    for (var v = function(W, ia) {
                            var T = kt(W, f);
                            T && (yr(T, ia, r), W !== "gb" && (n = !0))
                        }, t = function(W) {
                            var ia = ["GCL", h, W];
                            e.length > 0 && ia.push(e.join("."));
                            return ia.join(".")
                        }, u = m(["aw", "dc", "gf", "ha", "gp"]), x = u.next(); !x.done; x = u.next()) {
                        var y = x.value;
                        a[y] && v(y, t(a[y][0]))
                    }
                    if (!n && a.gb) {
                        var z = a.gb[0],
                            D = kt("gb", f);
                        !b && gt(D).some(function(W) {
                            return W.gclid === z && W.labels &&
                                W.labels.length > 0
                        }) || v("gb", t(z))
                    }
                }
                if (!p && a.gbraid && dt("ad_storage") && (p = !0, !n)) {
                    var E = a.gbraid,
                        L = kt("ag", f);
                    if (b || !lt(L).some(function(W) {
                            return W.gclid === E && W.labels && W.labels.length > 0
                        })) {
                        var G = {},
                            O = (G.k = E, G.i = "" + h, G.b = e, G);
                        Os(L, O, 5, c, g)
                    }
                }
                Kt(a, f, g, c)
            };
        vl(function() {
            q();
            dt(l) || wl(q, l)
        }, l)
    }

    function Kt(a, b, c, d) {
        if (a.gad_source !== void 0 && dt("ad_storage")) {
            var e = gd();
            if (e !== "r" && e !== "h") {
                var f = a.gad_source,
                    g = kt("gs", b);
                if (g) {
                    var h = Math.floor((Eb() - (fd() || 0)) / 1E3),
                        l, n = Us(),
                        p = {};
                    l = (p.k = f, p.i = "" + h, p.u = n, p);
                    Os(g, l, 5, d, c)
                }
            }
        }
    }

    function Lt(a, b) {
        var c = Zr(!0);
        et(function() {
            for (var d = jt(b.prefix), e = 0; e < a.length; ++e) {
                var f = a[e];
                if ($s[f] !== void 0) {
                    var g = kt(f, d),
                        h = c[g];
                    if (h) {
                        var l = Math.min(Mt(h), Eb()),
                            n;
                        b: {
                            for (var p = l, q = mr(g, A.cookie, void 0, ct()), r = 0; r < q.length; ++r)
                                if (Mt(q[r]) > p) {
                                    n = !0;
                                    break b
                                }
                            n = !1
                        }
                        if (!n) {
                            var v = Pq(b, l, !0);
                            v.vc = ct();
                            yr(g, h, v)
                        }
                    }
                }
            }
            Et(Bt(c.gclid, c.gclsrc), !1, b)
        }, ct())
    }

    function Nt(a) {
        var b = ["ag"],
            c = Zr(!0),
            d = jt(a.prefix);
        et(function() {
            for (var e = 0; e < b.length; ++e) {
                var f = kt(b[e], d);
                if (f) {
                    var g = c[f];
                    if (g) {
                        var h = Gs(g, 5);
                        if (h) {
                            var l = ot(h);
                            l || (l = Eb());
                            var n;
                            a: {
                                for (var p = l, q = Ks(f, 5), r = 0; r < q.length; ++r)
                                    if (ot(q[r]) > p) {
                                        n = !0;
                                        break a
                                    }
                                n = !1
                            }
                            if (n) break;
                            h.i = "" + Math.round(l / 1E3);
                            Os(f, h, 5, a, l)
                        }
                    }
                }
            }
        }, ["ad_storage"])
    }

    function kt(a, b) {
        var c = $s[a];
        if (c !== void 0) return b + c
    }

    function Mt(a) {
        return Ot(a.split(".")).length !== 0 ? (Number(a.split(".")[1]) || 0) * 1E3 : 0
    }

    function ot(a) {
        return a ? (Number(a.i) || 0) * 1E3 : 0
    }

    function pt(a) {
        var b = Ot(a.split("."));
        return b.length === 0 ? null : {
            version: b[0],
            gclid: b[2],
            timestamp: (Number(b[1]) || 0) * 1E3,
            labels: b.slice(3)
        }
    }

    function Ot(a) {
        return a.length < 3 || a[0] !== "GCL" && a[0] !== "1" || !/^\d+$/.test(a[1]) || !Ys.test(a[2]) ? [] : a
    }

    function Pt(a, b, c, d, e) {
        if (Array.isArray(b) && lr(w)) {
            var f = jt(e),
                g = function() {
                    for (var h = {}, l = 0; l < a.length; ++l) {
                        var n = kt(a[l], f);
                        if (n) {
                            var p = mr(n, A.cookie, void 0, ct());
                            p.length && (h[n] = p.sort()[p.length - 1])
                        }
                    }
                    return h
                };
            et(function() {
                fs(g, b, c, d)
            }, ct())
        }
    }

    function Qt(a, b, c, d) {
        if (Array.isArray(a) && lr(w)) {
            var e = ["ag"],
                f = jt(d),
                g = function() {
                    for (var h = {}, l = 0; l < e.length; ++l) {
                        var n = kt(e[l], f);
                        if (!n) return {};
                        var p = Ks(n, 5);
                        if (p.length) {
                            var q = p.sort(function(r, v) {
                                return ot(v) - ot(r)
                            })[0];
                            h[n] = Hs(q, 5)
                        }
                    }
                    return h
                };
            et(function() {
                fs(g, a, b, c)
            }, ["ad_storage"])
        }
    }

    function rt(a) {
        return a.filter(function(b) {
            return Ys.test(b.gclid)
        })
    }

    function Rt(a, b) {
        if (lr(w)) {
            for (var c = jt(b.prefix), d = {}, e = 0; e < a.length; e++) $s[a[e]] && (d[a[e]] = $s[a[e]]);
            et(function() {
                xb(d, function(f, g) {
                    var h = mr(c + g, A.cookie, void 0, ct());
                    h.sort(function(v, t) {
                        return Mt(t) - Mt(v)
                    });
                    if (h.length) {
                        var l = h[0],
                            n = Mt(l),
                            p = Ot(l.split(".")).length !== 0 ? l.split(".").slice(3) : [],
                            q = {},
                            r;
                        r = Ot(l.split(".")).length !== 0 ? l.split(".")[2] : void 0;
                        q[f] = [r];
                        Et(q, !0, b, n, p)
                    }
                })
            }, ct())
        }
    }

    function St(a) {
        var b = ["ag"],
            c = ["gbraid"];
        et(function() {
            for (var d = jt(a.prefix), e = 0; e < b.length; ++e) {
                var f = kt(b[e], d);
                if (!f) break;
                var g = Ks(f, 5);
                if (g.length) {
                    var h = g.sort(function(q, r) {
                            return ot(r) - ot(q)
                        })[0],
                        l = ot(h),
                        n = h.b,
                        p = {};
                    p[c[e]] = h.k;
                    Et(p, !0, a, l, n)
                }
            }
        }, ["ad_storage"])
    }

    function Tt(a, b) {
        for (var c = 0; c < b.length; ++c)
            if (a[b[c]]) return !0;
        return !1
    }

    function Ut(a) {
        function b(h, l, n) {
            n && (h[l] = n)
        }
        if (sl()) {
            var c = Ct(),
                d;
            a.includes("gad_source") && (d = c.gad_source !== void 0 ? c.gad_source : Zr(!1)._gs);
            if (Tt(c, a) || d) {
                var e = {};
                b(e, "gclid", c.gclid);
                b(e, "dclid", c.dclid);
                b(e, "gclsrc", c.gclsrc);
                b(e, "wbraid", c.wbraid);
                b(e, "gbraid", c.gbraid);
                gs(function() {
                    return e
                }, 3);
                var f = {},
                    g = (f._up = "1", f);
                b(g, "_gs", d);
                gs(function() {
                    return g
                }, 1)
            }
        }
    }

    function It() {
        var a = oj(w.location.href);
        return ij(a, "query", !1, void 0, "gad_source")
    }

    function Vt(a) {
        if (!Wa(1)) return null;
        var b = Zr(!0).gad_source;
        if (b != null) return w.location.hash = "", b;
        if (Wa(2)) {
            b = It();
            if (b != null) return b;
            var c = Ct();
            if (Tt(c, a)) return "0"
        }
        return null
    }

    function Wt(a) {
        var b = Vt(a);
        b != null && gs(function() {
            var c = {};
            return c.gad_source = b, c
        }, 4)
    }

    function Xt(a, b, c) {
        var d = [];
        if (b.length === 0) return d;
        for (var e = {}, f = 0; f < b.length; f++) {
            var g = b[f],
                h = g.type ? g.type : "gcl";
            (g.labels || []).indexOf(c) === -1 ? (a.push(0), e[h] || d.push(g)) : a.push(1);
            e[h] = !0
        }
        return d
    }

    function Yt(a, b, c, d) {
        var e = [];
        c = c || {};
        if (!dt(ct())) return e;
        var f = gt(a),
            g = Xt(e, f, b);
        if (g.length && !d)
            for (var h = m(g), l = h.next(); !l.done; l = h.next()) {
                var n = l.value,
                    p = n.timestamp,
                    q = [n.version, Math.round(p / 1E3), n.gclid].concat(n.labels || [], [b]).join("."),
                    r = Pq(c, p, !0);
                r.vc = ct();
                yr(a, q, r)
            }
        return e
    }

    function Zt(a, b) {
        var c = [];
        b = b || {};
        var d = it(b),
            e = Xt(c, d, a);
        if (e.length)
            for (var f = m(e), g = f.next(); !g.done; g = f.next()) {
                var h = g.value,
                    l = jt(b.prefix),
                    n = kt(h.type, l);
                if (!n) break;
                var p = h,
                    q = p.version,
                    r = p.gclid,
                    v = p.labels,
                    t = p.timestamp,
                    u = Math.round(t / 1E3);
                if (h.type === "ag") {
                    var x = {},
                        y = (x.k = r, x.i = "" + u, x.b = (v || []).concat([a]), x);
                    Os(n, y, 5, b, t)
                } else if (h.type === "gb") {
                    var z = [q, u, r].concat(v || [], [a]).join("."),
                        D = Pq(b, t, !0);
                    D.vc = ct();
                    yr(n, z, D)
                }
            }
        return c
    }

    function $t(a, b) {
        var c = jt(b),
            d = kt(a, c);
        if (!d) return 0;
        var e;
        e = a === "ag" ? lt(d) : gt(d);
        for (var f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
        return f
    }

    function au(a) {
        for (var b = 0, c = m(Object.keys(a)), d = c.next(); !d.done; d = c.next())
            for (var e = a[d.value], f = 0; f < e.length; f++) b = Math.max(b, Number(e[f].timestamp));
        return b
    }

    function bu(a) {
        var b = Math.max($t("aw", a), au(dt(ct()) ? ys() : {})),
            c = Math.max($t("gb", a), au(dt(ct()) ? ys("_gac_gb", !0) : {}));
        c = Math.max(c, $t("ag", a));
        return c > b
    }

    function Ht() {
        return A.referrer ? ij(oj(A.referrer), "host") : ""
    };

    function nu(a) {
        var b = window,
            c = b.webkit;
        delete b.webkit;
        a(b.webkit);
        b.webkit = c
    }

    function ou(a) {
        var b = {
            action: "gcl_setup"
        };
        if ("CWVWebViewMessage" in a.messageHandlers) return a.messageHandlers.CWVWebViewMessage.postMessage({
            command: "awb",
            payload: b
        }), !0;
        var c = a.messageHandlers.awb;
        return c ? (c.postMessage(b), !0) : !1
    };

    function pu() {
        return ["ad_storage", "ad_user_data"]
    }

    function qu(a) {
        if (H(38) && !Ll(Hl.Z.lm) && "webkit" in window && window.webkit.messageHandlers) {
            var b = function() {
                try {
                    nu(function(c) {
                        c && ("CWVWebViewMessage" in c.messageHandlers || "awb" in c.messageHandlers) && (Kl(Hl.Z.lm, function(d) {
                            d.gclid && Jt(d.gclid, 5, a)
                        }), ou(c) || N(178))
                    })
                } catch (c) {
                    N(177)
                }
            };
            vl(function() {
                dt(pu()) ? b() : wl(b, pu())
            }, pu())
        }
    };
    var ru = ["https://www.google.com", "https://www.youtube.com", "https://m.youtube.com"];

    function su(a) {
        return a.data.action !== "gcl_transfer" ? (N(173), !0) : a.data.gadSource ? a.data.gclid ? !1 : (N(181), !0) : (N(180), !0)
    }

    function tu(a, b) {
        if (H(a)) {
            if (Ll(Hl.Z.Fe)) return N(176), Hl.Z.Fe;
            if (Ll(Hl.Z.qm)) return N(170), Hl.Z.Fe;
            var c = Sp();
            if (!c) N(171);
            else if (c.opener) {
                var d = function(g) {
                    if (!ru.includes(g.origin)) N(172);
                    else if (!su(g)) {
                        var h = {
                            gadSource: g.data.gadSource
                        };
                        H(229) && (h.gclid = g.data.gclid);
                        Kl(Hl.Z.Fe, h);
                        a === 200 && g.data.gclid && Jt(String(g.data.gclid), 6, b);
                        var l;
                        (l = g.stopImmediatePropagation) == null || l.call(g);
                        $p(c, "message", d)
                    }
                };
                if (Zp(c, "message", d)) {
                    Kl(Hl.Z.qm, !0);
                    for (var e = m(ru), f = e.next(); !f.done; f = e.next()) c.opener.postMessage({
                            action: "gcl_setup"
                        },
                        f.value);
                    N(174);
                    return Hl.Z.Fe
                }
                N(175)
            }
        }
    };

    function Du(a) {
        var b = P(a.D, K.m.Gc),
            c = P(a.D, K.m.Fc);
        b && !c ? (a.eventName !== K.m.ma && a.eventName !== K.m.fe && N(131), a.isAborted = !0) : !b && c && (N(132), a.isAborted = !0)
    }

    function Eu(a) {
        var b = Xp(!0);
        U(a, K.m.Ec, b)
    }

    function Fu(a) {
        Oq() && U(a, K.m.ue, 1)
    }

    function Gu() {
        var a = A.title;
        if (a === void 0 || a === "") return "";
        a = encodeURIComponent(a);
        for (var b = 256; b > 0 && hj(a.substring(0, b)) === void 0;) b--;
        return hj(a.substring(0, b)) || ""
    }

    function Hu(a) {
        Iu(a, eo.Qf.Rn, P(a.D, K.m.tb))
    }

    function Iu(a, b, c) {
        xu(a, K.m.Mc) || U(a, K.m.Mc, {});
        xu(a, K.m.Mc)[b] = c
    }

    function Ju(a) {
        S(a, Q.A.dg, gl.aa.Qa)
    }

    function Ku(a) {
        var b = a.D.getMergedValues(K.m.Dc);
        b && a.mergeHitDataForKey(K.m.Dc, b)
    }

    function Lu(a, b) {
        b = b === void 0 ? !1 : b;
        var c = R(a, Q.A.cg),
            d = Mu(a, "custom_event_accept_rules", !1) && !b;
        if (c) {
            var e = c.indexOf(a.target.destinationId) >= 0,
                f = !0;
            H(240) && R(a, Q.A.nh) && (f = R(a, Q.A.Oa) === Ej());
            e && f ? S(a, Q.A.Eg, !0) : (S(a, Q.A.Eg, !1), d || (a.isAborted = !0));
            if (H(240))
                if (a.canBeAccepted()) {
                    var g = Dj().indexOf(a.target.destinationId) >= 0,
                        h = !1;
                    if (!g) {
                        var l, n = (l = wj(a.target.destinationId)) == null ? void 0 : l.canonicalContainerId;
                        n && (h = Ej() === n)
                    }
                    g || h ? R(a, Q.A.Eg) && a.accept() : a.isAborted = !0
                } else a.isAborted = !0;
            else R(a,
                Q.A.Eg) && a.accept()
        }
    }

    function Nu(a) {
        kk && (gm = !0, a.eventName === K.m.ma ? mm(a.D, a.target.id) : (R(a, Q.A.ae) || (jm[a.target.id] = !0), Un(R(a, Q.A.Oa))))
    }

    function Ou(a) {};
    var Pu = RegExp("^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"),
        Qu = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
        Ru = /^\d+\.fls\.doubleclick\.net$/,
        Su = /;gac=([^;?]+)/,
        Tu = /;gacgb=([^;?]+)/;

    function Uu(a, b) {
        if (Ru.test(A.location.host)) {
            var c = A.location.href.match(b);
            return c && c.length === 2 && c[1].match(Pu) ? hj(c[1]) || "" : ""
        }
        for (var d = [], e = m(Object.keys(a)), f = e.next(); !f.done; f = e.next()) {
            for (var g = f.value, h = [], l = a[g], n = 0; n < l.length; n++) h.push(l[n].gclid);
            d.push(g + ":" + h.join(","))
        }
        return d.length > 0 ? d.join(";") : ""
    }

    function Vu(a, b, c) {
        for (var d = dt(ct()) ? ys("_gac_gb", !0) : {}, e = [], f = !1, g = m(Object.keys(d)), h = g.next(); !h.done; h = g.next()) {
            var l = h.value,
                n = Yt("_gac_gb_" + l, a, b, c);
            f = f || n.length !== 0 && n.some(function(p) {
                return p === 1
            });
            e.push(l + ":" + n.join(","))
        }
        return {
            rq: f ? e.join(";") : "",
            qq: Uu(d, Tu)
        }
    }

    function Wu(a) {
        var b = A.location.href.match(new RegExp(";" + a + "=([^;?]+)"));
        return b && b.length === 2 && b[1].match(Qu) ? b[1] : void 0
    }

    function Xu(a) {
        var b = {},
            c, d, e;
        Ru.test(A.location.host) && (c = Wu("gclgs"), d = Wu("gclst"), e = Wu("gcllp"));
        if (c && d && e) b.lg = c, b.Fh = d, b.Eh = e;
        else {
            var f = Eb(),
                g = lt((a || "_gcl") + "_gs"),
                h = g.map(function(p) {
                    return p.gclid
                }),
                l = g.map(function(p) {
                    return f - p.timestamp
                }),
                n = g.map(function(p) {
                    return p.Vc
                });
            h.length > 0 && l.length > 0 && n.length > 0 && (b.lg = h.join("."), b.Fh = l.join("."), b.Eh = n.join("."))
        }
        return b
    }

    function Yu(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        if (Ru.test(A.location.host)) {
            var e = Wu(c);
            if (e) {
                if (d) {
                    var f = new Qs;
                    Rs(f, 2);
                    Rs(f, 3);
                    return e.split(".").map(function(h) {
                        return {
                            gclid: h,
                            Ba: f,
                            ab: [1]
                        }
                    })
                }
                return e.split(".").map(function(h) {
                    return {
                        gclid: h,
                        Ba: new Qs,
                        ab: [1]
                    }
                })
            }
        } else {
            if (b === "gclid") {
                var g = (a || "_gcl") + "_aw";
                return d ? wt(g) : gt(g)
            }
            if (b === "wbraid") return gt((a || "_gcl") + "_gb");
            if (b === "braids") return it({
                prefix: a
            })
        }
        return []
    }

    function Zu(a) {
        return Ru.test(A.location.host) ? !(Wu("gclaw") || Wu("gac")) : bu(a)
    }

    function $u(a, b, c) {
        var d;
        d = c ? Zt(a, b) : Yt((b && b.prefix || "_gcl") + "_gb", a, b);
        return d.length === 0 || d.every(function(e) {
            return e === 0
        }) ? "" : d.join(".")
    };

    function fv() {
        return go("dedupe_gclid", function() {
            return Fr()
        })
    };

    function nv() {
        var a;
        a = a === void 0 ? document : a;
        var b;
        return !((b = a.featurePolicy) == null || !b.allowedFeatures().includes("attribution-reporting"))
    };
    var rv = function(a) {
            this.C = 1;
            this.C > 0 || (this.C = 1);
            this.onSuccess = a.D.onSuccess
        },
        sv = function(a, b) {
            return Sb(function() {
                a.C--;
                if (pb(a.onSuccess) && a.C === 0) a.onSuccess()
            }, b > 0 ? b : 1)
        };

    function vv(a, b) {
        var c = !!bj();
        switch (a) {
            case 45:
                return "https://www.google.com/ccm/collect";
            case 46:
                return c ? aj() + "/gs/ccm/collect" : "https://pagead2.googlesyndication.com/ccm/collect";
            case 51:
                return "https://www.google.com/travel/flights/click/conversion";
            case 9:
                return "https://googleads.g.doubleclick.net/pagead/viewthroughconversion";
            case 17:
                return c ? H(90) && ym() ? tv() : "" + aj() + "/ag/g/c" : tv();
            case 16:
                return c ? H(90) && ym() ? uv() : "" + aj() + "/ga/g/c" : uv();
            case 1:
                return "https://ad.doubleclick.net/activity;";
            case 2:
                return c ?
                    aj() + "/ddm/activity/" : "https://ade.googlesyndication.com/ddm/activity/";
            case 33:
                return "https://ad.doubleclick.net/activity;register_conversion=1;";
            case 11:
                return c ? aj() + "/d/pagead/form-data" : H(141) ? "https://www.google.com/pagead/form-data" : "https://google.com/pagead/form-data";
            case 3:
                return "https://" + b.Op + ".fls.doubleclick.net/activityi;";
            case 5:
                return "https://www.googleadservices.com/pagead/conversion";
            case 6:
                return c ? aj() + "/gs/pagead/conversion" : "https://pagead2.googlesyndication.com/pagead/conversion";
            case 66:
                return "https://www.google.com/pagead/uconversion";
            case 8:
                return "https://www.google.com/pagead/1p-conversion";
            case 63:
                return "https://www.googleadservices.com/pagead/conversion";
            case 64:
                return c ? aj() + "/gs/pagead/conversion" : "https://pagead2.googlesyndication.com/pagead/conversion";
            case 65:
                return "https://www.google.com/pagead/1p-conversion";
            case 22:
                return c ? aj() + "/as/d/ccm/conversion" : "https://www.googleadservices.com/ccm/conversion";
            case 60:
                return c ? aj() + "/gs/ccm/conversion" : "https://pagead2.googlesyndication.com/ccm/conversion";
            case 23:
                return c ? aj() + "/g/d/ccm/conversion" : "https://www.google.com/ccm/conversion";
            case 55:
                return c ? aj() + "/gs/measurement/conversion/" : "https://pagead2.googlesyndication.com/measurement/conversion/";
            case 54:
                return H(205) ? "https://www.google.com/measurement/conversion/" : c ? aj() + "/g/measurement/conversion/" : "https://www.google.com/measurement/conversion/";
            case 21:
                return c ? aj() + "/d/ccm/form-data" : H(141) ? "https://www.google.com/ccm/form-data" : "https://google.com/ccm/form-data";
            case 7:
            case 52:
            case 53:
            case 39:
            case 38:
            case 40:
            case 37:
            case 49:
            case 48:
            case 14:
            case 24:
            case 19:
            case 27:
            case 30:
            case 36:
            case 62:
            case 26:
            case 29:
            case 32:
            case 35:
            case 57:
            case 58:
            case 50:
            case 12:
            case 13:
            case 20:
            case 18:
            case 59:
            case 47:
            case 15:
            case 0:
            case 61:
            case 56:
            case 25:
            case 28:
            case 31:
            case 34:
                throw Error("Unsupported endpoint");
            default:
                rc(a, "Unknown endpoint")
        }
    };

    function xv(a) {
        switch (a) {
            case 0:
                break;
            case 9:
                return "e4";
            case 6:
                return "e5";
            case 14:
                return "e6";
            default:
                return "e7"
        }
    };
    var yv = "email sha256_email_address phone_number sha256_phone_number first_name last_name".split(" "),
        zv = "first_name sha256_first_name last_name sha256_last_name street sha256_street city region country postal_code".split(" ");

    function Av(a, b) {
        if (!b._tag_metadata) {
            for (var c = {}, d = 0, e = 0; e < a.length; e++) d += Bv(a[e], b, c) ? 1 : 0;
            d > 0 && (b._tag_metadata = c)
        }
    }

    function Bv(a, b, c) {
        var d = b[a];
        if (d === void 0) return !1;
        c[a] = Array.isArray(d) ? d.map(function() {
            return {
                mode: "c"
            }
        }) : {
            mode: "c"
        };
        return !0
    }

    function Cv(a, b, c) {
        function d(f, g) {
            g = String(g).substring(0, 100);
            e.push("" + f + encodeURIComponent(g))
        }
        if (!c) return "";
        var e = [];
        d("i", String(a));
        d("f", b);
        c.mode && d("m", c.mode);
        c.isPreHashed && d("p", "1");
        c.rawLength && d("r", String(c.rawLength));
        c.normalizedLength && d("n", String(c.normalizedLength));
        c.location && d("l", c.location);
        c.selector && d("s", c.selector);
        return e.join(".")
    };

    function Dv() {
        this.blockSize = -1
    };

    function Ev(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.P = Fa.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.T = this.H = 0;
        this.C = [];
        this.la = a;
        this.V = b;
        this.xa = Fa.Int32Array ? new Int32Array(64) : Array(64);
        Fv === void 0 && (Fa.Int32Array ? Fv = new Int32Array(Gv) : Fv = Gv);
        this.reset()
    }
    Ga(Ev, Dv);
    for (var Hv = [], Iv = 0; Iv < 63; Iv++) Hv[Iv] = 0;
    var Jv = [].concat(128, Hv);
    Ev.prototype.reset = function() {
        this.T = this.H = 0;
        var a;
        if (Fa.Int32Array) a = new Int32Array(this.V);
        else {
            var b = this.V,
                c = b.length;
            if (c > 0) {
                for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
                a = d
            } else a = []
        }
        this.C = a
    };
    var Kv = function(a) {
        for (var b = a.P, c = a.xa, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (var f = 16; f < 64; f++) {
            var g = c[f - 15] | 0,
                h = c[f - 2] | 0;
            c[f] = ((c[f - 16] | 0) + ((g >>> 7 | g << 25) ^ (g >>> 18 | g << 14) ^ g >>> 3) | 0) + ((c[f - 7] | 0) + ((h >>> 17 | h << 15) ^ (h >>> 19 | h << 13) ^ h >>> 10) | 0) | 0
        }
        for (var l = a.C[0] | 0, n = a.C[1] | 0, p = a.C[2] | 0, q = a.C[3] | 0, r = a.C[4] | 0, v = a.C[5] | 0, t = a.C[6] | 0, u = a.C[7] | 0, x = 0; x < 64; x++) {
            var y = ((l >>> 2 | l << 30) ^ (l >>> 13 | l << 19) ^ (l >>> 22 | l << 10)) + (l & n ^ l & p ^ n & p) | 0,
                z = (u + ((r >>> 6 | r << 26) ^ (r >>> 11 | r << 21) ^ (r >>> 25 | r << 7)) |
                    0) + (((r & v ^ ~r & t) + (Fv[x] | 0) | 0) + (c[x] | 0) | 0) | 0;
            u = t;
            t = v;
            v = r;
            r = q + z | 0;
            q = p;
            p = n;
            n = l;
            l = z + y | 0
        }
        a.C[0] = a.C[0] + l | 0;
        a.C[1] = a.C[1] + n | 0;
        a.C[2] = a.C[2] + p | 0;
        a.C[3] = a.C[3] + q | 0;
        a.C[4] = a.C[4] + r | 0;
        a.C[5] = a.C[5] + v | 0;
        a.C[6] = a.C[6] + t | 0;
        a.C[7] = a.C[7] + u | 0
    };
    Ev.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.H;
        if (typeof a === "string")
            for (; c < b;) this.P[d++] = a.charCodeAt(c++), d == this.blockSize && (Kv(this), d = 0);
        else {
            var e, f = typeof a;
            e = f != "object" ? f : a ? Array.isArray(a) ? "array" : f : "null";
            if (e == "array" || e == "object" && typeof a.length == "number")
                for (; c < b;) {
                    var g = a[c++];
                    if (!("number" == typeof g && 0 <= g && 255 >= g && g == (g | 0))) throw Error("message must be a byte array");
                    this.P[d++] = g;
                    d == this.blockSize && (Kv(this), d = 0)
                } else throw Error("message must be string or array");
        }
        this.H = d;
        this.T += b
    };
    Ev.prototype.digest = function() {
        var a = [],
            b = this.T * 8;
        this.H < 56 ? this.update(Jv, 56 - this.H) : this.update(Jv, this.blockSize - (this.H - 56));
        for (var c = 63; c >= 56; c--) this.P[c] = b & 255, b /= 256;
        Kv(this);
        for (var d = 0, e = 0; e < this.la; e++)
            for (var f = 24; f >= 0; f -= 8) a[d++] = this.C[e] >> f & 255;
        return a
    };
    var Gv = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
            4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ],
        Fv;

    function Lv() {
        Ev.call(this, 8, Mv)
    }
    Ga(Lv, Ev);
    var Mv = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    var Nv = /^[0-9A-Fa-f]{64}$/;

    function Ov(a) {
        try {
            return (new TextEncoder).encode(a)
        } catch (b) {
            return Rb(a)
        }
    }

    function Pv(a) {
        var b = w;
        if (a === "" || a === "e0") return Promise.resolve(a);
        var c;
        if ((c = b.crypto) == null ? 0 : c.subtle) {
            if (Nv.test(a)) return Promise.resolve(a);
            try {
                var d = Ov(a);
                return b.crypto.subtle.digest("SHA-256", d).then(function(e) {
                    return Qv(e, b)
                }).catch(function() {
                    return "e2"
                })
            } catch (e) {
                return Promise.resolve("e2")
            }
        } else return Promise.resolve("e1")
    }

    function Qv(a, b) {
        var c = Array.from(new Uint8Array(a)).map(function(d) {
            return String.fromCharCode(d)
        }).join("");
        return b.btoa(c).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
    };

    function yw(a, b) {
        b && xb(b, function(c, d) {
            typeof d !== "object" && d !== void 0 && (a["1p." + c] = String(d))
        })
    };

    function zw(a, b) {
        var c = xu(a, K.m.Dc);
        if (c && typeof c === "object")
            for (var d = m(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
                var f = e.value,
                    g = c[f];
                g !== void 0 && (g === null && (g = ""), b["gap." + f] = String(g))
            }
    };
    var Nw = {};
    Nw.N = er.N;
    var Ow = {
            ys: "L",
            zp: "S",
            Ls: "Y",
            Sr: "B",
            ls: "E",
            us: "I",
            Is: "TC",
            rs: "HTC"
        },
        Pw = {
            zp: "S",
            ks: "V",
            Vr: "E",
            Hs: "tag"
        },
        Qw = {},
        Rw = (Qw[Nw.N.Xi] = "6", Qw[Nw.N.Yi] = "5", Qw[Nw.N.Wi] = "7", Qw);

    function Sw() {
        function a(c, d) {
            var e = nb(d);
            e && b.push([c, e])
        }
        var b = [];
        a("u", "GTM");
        a("ut", "TAGGING");
        a("h", "HEALTH");
        return b
    };
    var Tw = !1;

    function lx(a) {}

    function mx(a) {}

    function nx() {}

    function ox(a) {}

    function px(a) {}

    function qx(a) {}

    function rx() {}

    function sx(a, b) {}

    function tx(a, b, c) {}

    function ux() {};
    var vx = Object.freeze({
        cache: "no-store",
        credentials: "include",
        method: "GET",
        keepalive: !0,
        redirect: "follow"
    });

    function wx(a, b, c, d, e, f, g, h) {
        var l = na(Object, "assign").call(Object, {}, vx);
        c && (l.body = c, l.method = "POST");
        na(Object, "assign").call(Object, l, e);
        h == null || Rk(h);
        w.fetch(b, l).then(function(n) {
            h == null || Sk(h);
            if (!n.ok) g == null || g();
            else if (n.body) {
                var p = n.body.getReader(),
                    q = new TextDecoder;
                return new Promise(function(r) {
                    function v() {
                        p.read().then(function(t) {
                            var u;
                            u = t.done;
                            var x = q.decode(t.value, {
                                stream: !u
                            });
                            xx(d, x);
                            u ? (f == null || f(), r()) : v()
                        }).catch(function() {
                            r()
                        })
                    }
                    v()
                })
            }
        }).catch(function() {
            h == null || Sk(h);
            g ? g() : H(128) && (b += "&_z=retryFetch", c ? $k(a, b, c) : Zk(a, b))
        })
    };
    var yx = function(a) {
            this.P = a;
            this.C = ""
        },
        zx = function(a, b) {
            a.H = b;
            return a
        },
        xx = function(a, b) {
            b = a.C + b;
            for (var c = b.indexOf("\n\n"); c !== -1;) {
                var d = a,
                    e;
                a: {
                    var f = m(b.substring(0, c).split("\n")),
                        g = f.next().value,
                        h = f.next().value;
                    if (g.indexOf("event: message") === 0 && h.indexOf("data: ") === 0) try {
                        e = JSON.parse(h.substring(h.indexOf(":") + 1));
                        break a
                    } catch (l) {}
                    e = void 0
                }
                Ax(d, e);
                b = b.substring(c + 2);
                c = b.indexOf("\n\n")
            }
            a.C = b
        },
        Bx = function(a, b) {
            return function() {
                if (b.fallback_url && b.fallback_url_method) {
                    var c = {};
                    Ax(a, (c[b.fallback_url_method] = [b.fallback_url], c.options = {}, c))
                }
            }
        },
        Ax = function(a, b) {
            b && (Cx(b.send_pixel, b.options, a.P), Cx(b.create_iframe, b.options, a.T), Cx(b.fetch, b.options, a.H))
        };

    function Dx(a) {
        var b = a.search;
        return a.protocol + "//" + a.hostname + a.pathname + (b ? b + "&richsstsse" : "?richsstsse")
    }

    function Cx(a, b, c) {
        if (a && c) {
            var d = a || [];
            if (Array.isArray(d))
                for (var e = sd(b) ? b : {}, f = m(d), g = f.next(); !g.done; g = f.next()) c(g.value, e)
        }
    };
    var qg;

    function Ex() {
        var a = data.permissions || {};
        qg = new wg(C(5), a)
    }

    function Fx(a, b) {
        rg(a, b)
    };
    var Gx = gg(57, 5),
        Hx = gg(58, 50),
        Ix = ub();
    var Kx = function(a, b) {
            a && (Jx("sid", a.targetId, b), Jx("cc", a.clientCount, b), Jx("tl", a.totalLifeMs, b), Jx("hc", a.heartbeatCount, b), Jx("cl", a.clientLifeMs, b))
        },
        Jx = function(a, b, c) {
            b != null && c.push(a + "=" + b)
        },
        Lx = function() {
            var a = A.referrer;
            if (a) {
                var b;
                return ij(oj(a), "host") === ((b = w.location) == null ? void 0 : b.host) ? 1 : 2
            }
            return 0
        },
        Mx = "https://" + C(21) + "/a?",
        Ox = function() {
            this.V = Nx;
            this.P = 0
        };
    Ox.prototype.H = function(a, b, c, d) {
        var e = Lx(),
            f, g = [];
        f = w === w.top && e !== 0 && b ?
            (b == null ? void 0 : b.clientCount) > 1 ? e === 2 ? 1 : 2 : e === 2 ? 0 : 3 : 4;
        a && Jx("si", a.tg, g);
        Jx("m", 0, g);
        Jx("iss", f, g);
        Jx("if", c, g);
        Kx(b, g);
        d && Jx("fm", encodeURIComponent(d.substring(0, Hx)), g);
        this.T(g);
    };
    Ox.prototype.C = function(a, b, c, d, e) {
        var f = [];
        Jx("m", 1, f);
        Jx("s", a, f);
        Jx("po", Lx(), f);
        b && (Jx("st", b.state, f), Jx("si", b.tg, f), Jx("sm", b.Ag, f));
        Kx(c, f);
        Jx("c", d, f);
        e && Jx("fm", encodeURIComponent(e.substring(0, Hx)), f);
        this.T(f);
    };
    Ox.prototype.T = function(a) {
        a = a === void 0 ? [] : a;
        !ik || this.P >= Gx || (Jx("pid", Ix, a), Jx("bc", ++this.P, a), a.unshift("ctid=" + C(5) + "&t=s"), this.V("" + Mx + a.join("&")))
    };

    function Px(a) {
        return a.performance && a.performance.now() || Date.now()
    }
    var Rx = function(a, b) {
        var c = w,
            d = Qx,
            e;
        var f = function(g, h, l) {
            l = l === void 0 ? {
                jn: function() {},
                kn: function() {},
                hn: function() {},
                onFailure: function() {}
            } : l;
            this.Hp = g;
            this.C = h;
            this.P = l;
            this.la = this.xa = this.heartbeatCount = this.Gp = 0;
            this.uh = !1;
            this.H = {};
            this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
            this.state = 0;
            this.tg = Px(this.C);
            this.Ag = Px(this.C);
            this.V = 10
        };
        f.prototype.init = function() {
            this.T(1);
            this.Za()
        };
        f.prototype.getState = function() {
            return {
                state: this.state,
                tg: Math.round(Px(this.C) - this.tg),
                Ag: Math.round(Px(this.C) - this.Ag)
            }
        };
        f.prototype.T = function(g) {
            this.state !== g && (this.state = g, this.Ag = Px(this.C))
        };
        f.prototype.Fm = function() {
            return String(this.Gp++)
        };
        f.prototype.Za = function() {
            var g = this;
            this.heartbeatCount++;
            this.wb({
                type: 0,
                clientId: this.id,
                requestId: this.Fm(),
                maxDelay: this.wh()
            }, function(h) {
                if (h.type === 0) {
                    var l;
                    if (((l = h.failure) == null ? void 0 : l.failureType) != null)
                        if (h.stats && (g.stats = h.stats), g.la++, h.isDead || g.la > d.jm) {
                            var n = h.isDead && h.failure.failureType;
                            g.V = n || 10;
                            g.T(4);
                            g.Fp();
                            var p, q;
                            (q = (p = g.P).hn) == null || q.call(p, {
                                failureType: n || 10,
                                data: h.failure.data
                            })
                        } else g.T(3), g.Km();
                    else {
                        if (g.heartbeatCount > h.stats.heartbeatCount + d.jm) {
                            g.heartbeatCount = h.stats.heartbeatCount;
                            var r, v;
                            (v = (r = g.P).onFailure) == null || v.call(r, {
                                failureType: 13
                            })
                        }
                        g.stats = h.stats;
                        var t = g.state;
                        g.T(2);
                        if (t !== 2)
                            if (g.uh) {
                                var u, x;
                                (x = (u = g.P).kn) == null || x.call(u)
                            } else {
                                g.uh = !0;
                                var y, z;
                                (z = (y = g.P).jn) == null || z.call(y)
                            }
                        g.la = 0;
                        g.Ip();
                        g.Km()
                    }
                }
            })
        };
        f.prototype.wh = function() {
            return this.state ===
                2 ? d.kp : d.Dp
        };
        f.prototype.Km = function() {
            var g = this;
            this.C.setTimeout(function() {
                g.Za()
            }, Math.max(0, this.wh() - (Px(this.C) - this.xa)))
        };
        f.prototype.Mp = function(g, h, l) {
            var n = this;
            this.wb({
                type: 1,
                clientId: this.id,
                requestId: this.Fm(),
                command: g
            }, function(p) {
                if (p.type === 1)
                    if (p.result) h(p.result);
                    else {
                        var q, r, v, t = {
                                failureType: (v = (q = p.failure) == null ? void 0 : q.failureType) != null ? v : 12,
                                data: (r = p.failure) == null ? void 0 : r.data
                            },
                            u, x;
                        (x = (u = n.P).onFailure) == null || x.call(u, t);
                        l(t)
                    }
            })
        };
        f.prototype.wb = function(g, h) {
            var l =
                this;
            if (this.state === 4) g.failure = {
                failureType: this.V
            }, h(g);
            else {
                var n = this.state !== 2 && g.type !== 0,
                    p = g.requestId,
                    q, r = this.C.setTimeout(function() {
                        var t = l.H[p];
                        t && l.Xf(t, 7)
                    }, (q = g.maxDelay) != null ? q : d.Zn),
                    v = {
                        request: g,
                        wn: h,
                        rn: n,
                        Uq: r
                    };
                this.H[p] = v;
                n || this.sendRequest(v)
            }
        };
        f.prototype.sendRequest = function(g) {
            this.xa = Px(this.C);
            g.rn = !1;
            this.Hp(g.request)
        };
        f.prototype.Ip = function() {
            for (var g = m(Object.keys(this.H)), h = g.next(); !h.done; h = g.next()) {
                var l = this.H[h.value];
                l.rn && this.sendRequest(l)
            }
        };
        f.prototype.Fp =
            function() {
                for (var g = m(Object.keys(this.H)), h = g.next(); !h.done; h = g.next()) this.Xf(this.H[h.value], this.V)
            };
        f.prototype.Xf = function(g, h) {
            this.Oc(g);
            var l = g.request;
            l.failure = {
                failureType: h
            };
            g.wn(l)
        };
        f.prototype.Oc = function(g) {
            delete this.H[g.request.requestId];
            this.C.clearTimeout(g.Uq)
        };
        f.prototype.Dq = function(g) {
            this.xa = Px(this.C);
            var h = this.H[g.requestId];
            if (h) this.Oc(h), h.wn(g);
            else {
                var l, n;
                (n = (l = this.P).onFailure) == null || n.call(l, {
                    failureType: 14
                })
            }
        };
        e = new f(a, c, b);
        return e
    };
    var Sx;
    var Tx = function() {
            Sx || (Sx = new Ox);
            return Sx
        },
        Nx = function(a) {
            El(Gl(gl.aa.Nc), function() {
                Pc(a)
            })
        },
        Ux = function(a) {
            var b = a.substring(0, a.indexOf("/_/service_worker"));
            return "&1p=1" + (b ? "&path=" + encodeURIComponent(b) : "")
        },
        Vx = function(a) {
            var b = a,
                c, d = eg(11);
            d = eg(10);
            c = d;
            b ? (b.charAt(b.length - 1) !== "/" && (b += "/"), a = b + c) : a = "https://www.googletagmanager.com/static/service_worker/" + c + "/";
            var e;
            try {
                e = new URL(a)
            } catch (f) {
                return null
            }
            return e.protocol !==
                "https:" ? null : e
        },
        Wx = function(a) {
            var b = w.location.origin;
            if (!b) return null;
            bj() && !a && (a = "" + b + aj() + "/_/service_worker");
            return Vx(a)
        },
        Xx = function(a) {
            var b = Ll(Hl.Z.wm);
            return b && b[a]
        },
        Qx = {
            Dp: gg(53, 500),
            kp: gg(54, 5E3),
            jm: gg(8, 20),
            Zn: gg(55, 5E3)
        },
        Yx = function(a, b, c) {
            var d = this;
            this.H = b;
            this.V = this.T = !1;
            this.la = null;
            this.initTime = Math.round(Eb());
            this.C = 15;
            this.P = this.cq(a);
            w.setTimeout(function() {
                d.initialize()
            }, 1E3);
            Sc(function() {
                d.Lq(a, c)
            })
        };
    k = Yx.prototype;
    k.delegate = function(a, b, c) {
        this.getState() !== 2 ?
            (this.H.C(this.C, {
                state: this.getState(),
                tg: this.initTime,
                Ag: Math.round(Eb()) - this.initTime
            }, void 0, a.commandType), c({
                failureType: this.C
            })) : this.P.Mp(a, b, c)
    };
    k.getState = function() {
        return this.P.getState().state
    };
    k.Lq = function(a, b) {
        var c = w.location.origin,
            d = this,
            e = Nc();
        try {
            var f = e.contentDocument.createElement("iframe"),
                g = a.pathname,
                h = g[g.length - 1] === "/" ? a.toString() : a.toString() + "/",
                l = a.origin !== "https://www.googletagmanager.com" ? Ux(g) : "",
                n;
            H(133) && (n = {
                sandbox: "allow-same-origin allow-scripts"
            });
            Nc(h +
                "sw_iframe.html?origin=" + encodeURIComponent(c) + l + (b ? "&e=1" : ""), void 0, n, void 0, f);
            var p = function() {
                e.contentDocument.body.appendChild(f);
                f.addEventListener("load", function() {
                    d.la = f.contentWindow;
                    e.contentWindow.addEventListener("message", function(q) {
                        q.origin === a.origin && d.P.Dq(q.data)
                    });
                    d.initialize()
                })
            };
            e.contentDocument.readyState === "complete" ? p() : e.contentWindow.addEventListener("load", function() {
                p()
            })
        } catch (q) {
            e.parentElement.removeChild(e), this.C = 11, this.H.H(void 0, void 0, this.C, q.toString())
        }
    };
    k.cq = function(a) {
        var b = this,
            c = Rx(function(d) {
                var e;
                (e = b.la) == null || e.postMessage(d, a.origin)
            }, {
                jn: function() {
                    b.T = !0;
                    b.H.H(c.getState(), c.stats)
                },
                kn: function() {},
                hn: function(d) {
                    b.T ? (b.C = (d == null ? void 0 : d.failureType) || 10, b.H.C(b.C, c.getState(), c.stats, void 0, d == null ? void 0 : d.data)) : (b.C = (d == null ? void 0 : d.failureType) || 4, b.H.H(c.getState(), c.stats, b.C, d == null ? void 0 : d.data))
                },
                onFailure: function(d) {
                    b.C = d.failureType;
                    b.H.C(b.C, c.getState(), c.stats, d.command, d.data)
                }
            });
        return c
    };
    k.initialize = function() {
        this.V ||
            this.P.init();
        this.V = !0
    };

    function Zx() {
        var a = tg(qg.C, "", function() {
            return {}
        });
        try {
            return a("internal_sw_allowed"), !0
        } catch (b) {
            return !1
        }
    }

    function $x(a) {
        var b, c, d = a === void 0 ? {} : a;
        b = d.wr;
        c = d.Cn === void 0 ? !1 : d.Cn;
        var e = Wx(b);
        if (e === null || !Zx() || H(168) || Xx(e.origin)) return;
        if (!Ac()) {
            Tx().H(void 0, void 0, 6);
            return
        }
        var f = new Yx(e, Tx(), c);
        Ml(Hl.Z.wm, {})[e.origin] = f;
    }
    var ay = function(a, b, c, d) {
        var e;
        if ((e = Xx(a)) == null || !e.delegate) {
            var f = Ac() ? 16 : 6;
            Tx().C(f, void 0, void 0, b.commandType);
            d({
                failureType: f
            });
            return
        }
        Xx(a).delegate(b, c, d);
    };

    function by(a, b, c, d, e) {
        var f = H(277) ? Wx() : Vx();
        if (f === null) {
            d(Ac() ? 16 : 6);
            return
        }
        var g, h = (g = Xx(f.origin)) == null ? void 0 : g.initTime,
            l = Math.round(Eb()),
            n = {
                commandType: 0,
                params: {
                    url: a,
                    method: 0,
                    templates: b,
                    body: "",
                    processResponse: !1,
                    sinceInit: h ? l - h : void 0
                }
            };
        e && (n.params.encryptionKeyString = e);
        ay(f.origin, n, function(p) {
            c(p)
        }, function(p) {
            d(p.failureType)
        });
    }

    function cy(a, b, c, d) {
        var e = Wx(a);
        if (e === null) {
            d("_is_sw=f" + (Ac() ? 16 : 6) + "te");
            return
        }
        var f = b ? 1 : 0,
            g = Math.round(Eb()),
            h, l = (h = Xx(e.origin)) == null ? void 0 : h.initTime,
            n = l ? g - l : void 0,
            p = !1;
        H(169) && (p = !0);
        ay(e.origin, {
            commandType: 0,
            params: {
                url: a,
                method: f,
                templates: c,
                body: b || "",
                processResponse: !0,
                suppressSuccessCallback: p,
                sinceInit: n,
                attributionReporting: !0,
                referer: w.location.href
            }
        }, function() {}, function(q) {
            var r = "_is_sw=f" + q.failureType,
                v, t = (v = Xx(e.origin)) ==
                null ? void 0 : v.getState();
            t !== void 0 && (r += "s" + t);
            d(n ? r + ("t" + n) : r + "te")
        });
    };
    var dy = function(a, b) {
            this.Yq = a;
            this.timeoutMs = b;
            this.Ua = void 0
        },
        Rk = function(a) {
            a.Ua || (a.Ua = setTimeout(function() {
                a.Yq();
                a.Ua = void 0
            }, a.timeoutMs))
        },
        Sk = function(a) {
            a.Ua && (clearTimeout(a.Ua), a.Ua = void 0)
        };

    function Ny(a, b, c, d) {
        var e = Mc(),
            f;
        if (e === 1) a: {
            var g = C(3);g = g.toLowerCase();
            for (var h = "https://" + g, l = "http://" + g, n = 1, p = A.getElementsByTagName("script"), q = 0; q < p.length && q < 100; q++) {
                var r = p[q].src;
                if (r) {
                    r = r.toLowerCase();
                    if (r.indexOf(l) === 0) {
                        f = 3;
                        break a
                    }
                    n === 1 && r.indexOf(h) === 0 && (n = 2)
                }
            }
            f = n
        }
        else f = e;
        return (f === 2 || d || "http:" !== w.location.protocol ? a : b) + c
    };

    function Oy(a, b) {
        if (a === "") return "";
        var c = Rb(a),
            d = b.slice(-2),
            e = [].concat(Aa(d), Aa(c)).map(function(g, h) {
                return g ^ b[h % b.length]
            }),
            f = new Uint8Array([].concat(Aa(e), Aa(d)));
        return gb(String.fromCharCode.apply(String, Aa(f))).replace(/\.+$/, "")
    };

    function Py(a, b, c, d, e) {
        if (!Nj(a)) {
            d.loadExperiments = Mi();
            Pj(a, d, e);
            var f = Qy(a),
                g = function() {
                    xj().container[a] && (xj().container[a].state = 3);
                    Ry()
                },
                h = {
                    destinationId: a,
                    endpoint: 0
                };
            if (bj()) cl(h, aj() + "/" + Sy(f), void 0, g);
            else {
                var l = Jb(a, "GTM-"),
                    n = ak(),
                    p = c ? "/gtag/js" : "/gtm.js",
                    q = Zj(b, p + f);
                if (!q) {
                    var r = C(3) + p;
                    n && Cc && l && (r = Cc.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]);
                    q = Ny("https://", "http://", r + f)
                }
                cl(h, q, void 0, g)
            }
        }
    }

    function Ry() {
        Qj() || xb(Rj(), function(a, b) {
            Ty(a, b.transportUrl, b.context);
            N(92)
        })
    }

    function Ty(a, b, c, d) {
        if (!Oj(a))
            if (c.loadExperiments || (c.loadExperiments = Mi()), Qj()) {
                var e = xj(),
                    f = wj(a);
                f ? f.state = 0 : (f = {
                    state: 0,
                    transportUrl: b,
                    context: c,
                    parent: Ij()
                }, H(269) ? e.destinationArray[a] = [f] : e.destination[a] = f);
                yj({
                    ctid: a,
                    isDestination: !0
                }, d);
                N(91)
            } else {
                var g = xj(),
                    h = wj(a);
                h ? h.state = 1 : (h = {
                    context: c,
                    state: 1,
                    parent: Ij()
                }, H(269) ? g.destinationArray[a] = [h] : g.destination[a] = h);
                yj({
                    ctid: a,
                    isDestination: !0
                }, d);
                var l = {
                    destinationId: a,
                    endpoint: 0
                };
                if (bj()) {
                    var n = "gtd" + Qy(a, !0);
                    cl(l, aj() + "/" + Sy(n))
                } else {
                    var p =
                        "/gtag/destination" + Qy(a, !0),
                        q = Zj(b, p);
                    q || (q = Ny("https://", "http://", C(3) + p));
                    cl(l, q)
                }
            }
    }

    function Qy(a, b) {
        b = b === void 0 ? !1 : b;
        var c = "?id=" + encodeURIComponent(a),
            d = C(19);
        d !== "dataLayer" && (c += "&l=" + d);
        if (!Jb(a, "GTM-") || b) c = H(130) ? c + (bj() ? "&sc=1" : "&cx=c") : c + "&cx=c";
        var e = c,
            f, g = {
                un: dg(15),
                xn: C(14)
            };
        f = mf(g);
        c = e + ("&gtm=" + f);
        ak() && (c += "&sign=" + Oi.Ui);
        var h = dg(54);
        h === 1 ? c += "&fps=fc" : h === 2 && (c += "&fps=fe");
        return c
    }

    function Sy(a) {
        if (!H(274)) return a;
        var b = C(58);
        if (!b) return N(182), a;
        try {
            for (var c = hb(b), d = new Uint8Array(c.length), e = 0; e < c.length; e++) d[e] = c.charCodeAt(e);
            if (d.length !== 32) throw Error("Key is not 32 bytes.");
            return Oy(a, d)
        } catch (f) {
            return N(183), a
        }
    };
    var Uy = new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),
        Vy = {
            cl: ["ecl"],
            customPixels: ["nonGooglePixels"],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            customScripts: ["html", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            nonGooglePixels: [],
            nonGoogleScripts: ["nonGooglePixels"],
            nonGoogleIframes: ["nonGooglePixels"]
        },
        Wy = {
            cl: ["ecl"],
            customPixels: ["customScripts",
                "html"
            ],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts"],
            customScripts: ["html"],
            nonGooglePixels: ["customPixels", "customScripts", "html", "nonGoogleScripts", "nonGoogleIframes"],
            nonGoogleScripts: ["customScripts", "html"],
            nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"]
        },
        Xy = "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");

    function Yy() {
        var a = dp("gtm.allowlist") || dp("gtm.whitelist");
        a && N(9);
        Ti && !H(212) ? a = ["google", "gtagfl", "lcl", "zone", "cmpPartners"] : H(212) && (a = void 0);
        Uy.test(w.location && w.location.hostname) && (Ti ? N(116) : (N(117), cg(48) && (a = [], window.console && window.console.log && window.console.log("GTM blocked. See go/13687728."))));
        var b = a && Ib(Bb(a), Vy),
            c = dp("gtm.blocklist") || dp("gtm.blacklist");
        c || (c = dp("tagTypeBlacklist")) && N(3);
        c ? N(8) : c = [];
        Uy.test(w.location && w.location.hostname) && (c = Bb(c), c.push("nonGooglePixels",
            "nonGoogleScripts", "sandboxedScripts"));
        Bb(c).indexOf("google") >= 0 && N(2);
        var d = c && Ib(Bb(c), Wy),
            e = {};
        return function(f) {
            var g = f && f[nf.Ra];
            if (!g || typeof g !== "string") return !0;
            g = g.replace(/^_*/, "");
            if (e[g] !== void 0) return e[g];
            var h = Zi[g] || [],
                l = !0;
            if (a) {
                var n;
                if (n = l) a: {
                    if (b.indexOf(g) < 0) {
                        if (Ti && h.indexOf("cmpPartners") >= 0) {
                            n = !0;
                            break a
                        }
                        if (h && h.length > 0)
                            for (var p = 0; p < h.length; p++) {
                                if (b.indexOf(h[p]) < 0) {
                                    N(11);
                                    n = !1;
                                    break a
                                }
                            } else {
                                n = !1;
                                break a
                            }
                    }
                    n = !0
                }
                l = n
            }
            var q = !1;
            if (c) {
                var r = d.indexOf(g) >= 0;
                if (r) q = r;
                else {
                    var v =
                        vb(d, h || []);
                    v && N(10);
                    q = v
                }
            }
            var t = !l || q;
            !t && (h.indexOf("sandboxedScripts") === -1 ? 0 : Ti && h.indexOf("cmpPartners") >= 0 ? !Zy() : b && b.indexOf("sandboxedScripts") !== -1 ? 0 : vb(d, Xy)) && (t = !0);
            return e[g] = t
        }
    }

    function Zy() {
        var a = tg(qg.C, C(5), function() {
            return {}
        });
        try {
            return a("inject_cmp_banner"), !0
        } catch (b) {
            return !1
        }
    };
    var $y = function() {
        this.H = 0;
        this.C = {}
    };
    $y.prototype.addListener = function(a, b, c) {
        var d = ++this.H;
        this.C[a] = this.C[a] || {};
        this.C[a][String(d)] = {
            listener: b,
            Se: c
        };
        return d
    };
    $y.prototype.removeListener = function(a, b) {
        var c = this.C[a],
            d = String(b);
        if (!c || !c[d]) return !1;
        delete c[d];
        return !0
    };
    var bz = function(a, b) {
        var c = [];
        xb(az.C[a], function(d, e) {
            c.indexOf(e.listener) < 0 && (e.Se === void 0 || b.indexOf(e.Se) >= 0) && c.push(e.listener)
        });
        return c
    };

    function cz(a, b, c) {
        return {
            entityType: a,
            indexInOriginContainer: b,
            nameInOriginContainer: c,
            originContainerId: C(5)
        }
    };

    function dz(a, b) {
        if (data.entities) {
            var c = data.entities[a];
            if (c) return c[b]
        }
    };
    var fz = function(a, b) {
            this.C = !1;
            this.T = [];
            this.eventData = {
                tags: []
            };
            this.V = !1;
            this.H = this.P = 0;
            ez(this, a, b)
        },
        gz = function(a, b, c, d) {
            if (Qi.hasOwnProperty(b) || b === "__zone") return -1;
            var e = {};
            sd(d) && (e = td(d, e));
            e.id = c;
            e.status = "timeout";
            return a.eventData.tags.push(e) - 1
        },
        hz = function(a, b, c, d) {
            var e = a.eventData.tags[b];
            e && (e.status = c, e.executionTime = d)
        },
        iz = function(a) {
            if (!a.C) {
                for (var b = a.T, c = 0; c < b.length; c++) b[c]();
                a.C = !0;
                a.T.length = 0
            }
        },
        ez = function(a, b, c) {
            b !== void 0 && a.fg(b);
            c && w.setTimeout(function() {
                    iz(a)
                },
                Number(c))
        };
    fz.prototype.fg = function(a) {
        var b = this,
            c = Gb(function() {
                Sc(function() {
                    a(C(5), b.eventData)
                })
            });
        this.C ? c() : this.T.push(c)
    };
    var jz = function(a) {
            a.P++;
            return Gb(function() {
                a.H++;
                a.V && a.H >= a.P && iz(a)
            })
        },
        kz = function(a) {
            a.V = !0;
            a.H >= a.P && iz(a)
        };
    var lz = {};

    function mz() {
        return w[nz()]
    }

    function nz() {
        return w.GoogleAnalyticsObject || "ga"
    }

    function qz() {
        var a = C(5);
    }

    function rz(a, b) {
        return function() {
            var c = mz(),
                d = c && c.getByName && c.getByName(a);
            if (d) {
                var e = d.get("sendHitTask");
                d.set("sendHitTask", function(f) {
                    var g = f.get("hitPayload"),
                        h = f.get("hitCallback"),
                        l = g.indexOf("&tid=" + b) < 0;
                    l && (f.set("hitPayload", g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b), !0), f.set("hitCallback", void 0, !0));
                    e(f);
                    l && (f.set("hitPayload", g, !0), f.set("hitCallback", h, !0), f.set("_x_19", void 0, !0), e(f))
                })
            }
        }
    };
    var xz = ["es", "1"],
        yz = {},
        zz = {};

    function Az(a, b) {
        if (ik) {
            var c;
            c = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
            yz[a] = [
                ["e", c],
                ["eid", a]
            ];
            yp(a)
        }
    }

    function Bz(a) {
        var b = a.eventId,
            c = a.Vd;
        if (!yz[b]) return [];
        var d = [];
        zz[b] || d.push(xz);
        d.push.apply(d, Aa(yz[b]));
        c && (zz[b] = !0);
        return d
    };
    var Cz = {},
        Dz = {},
        Ez = {};

    function Fz(a, b, c, d) {
        ik && H(120) && ((d === void 0 ? 0 : d) ? (Ez[b] = Ez[b] || 0, ++Ez[b]) : c !== void 0 ? (Dz[a] = Dz[a] || {}, Dz[a][b] = Math.round(c)) : (Cz[a] = Cz[a] || {}, Cz[a][b] = (Cz[a][b] || 0) + 1))
    }

    function Gz(a) {
        var b = a.eventId,
            c = a.Vd,
            d = Cz[b] || {},
            e = [],
            f;
        for (f in d) d.hasOwnProperty(f) && e.push("" + f + d[f]);
        c && delete Cz[b];
        return e.length ? [
            ["md", e.join(".")]
        ] : []
    }

    function Hz(a) {
        var b = a.eventId,
            c = a.Vd,
            d = Dz[b] || {},
            e = [],
            f;
        for (f in d) d.hasOwnProperty(f) && e.push("" + f + d[f]);
        c && delete Dz[b];
        return e.length ? [
            ["mtd", e.join(".")]
        ] : []
    }

    function Iz() {
        for (var a = [], b = m(Object.keys(Ez)), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            a.push("" + d + Ez[d])
        }
        return a.length ? [
            ["mec", a.join(".")]
        ] : []
    };
    var Jz = {},
        Kz = {};

    function Lz(a, b, c) {
        if (ik && b) {
            var d = fk(b);
            Jz[a] = Jz[a] || [];
            Jz[a].push(c + d);
            var e = b[nf.Ra];
            if (!e) throw Error("Error: No function name given for function call.");
            var f = (Pf[e] ? "1" : "2") + d;
            Kz[a] = Kz[a] || [];
            Kz[a].push(f);
            yp(a)
        }
    }

    function Mz(a) {
        var b = a.eventId,
            c = a.Vd,
            d = [],
            e = Jz[b] || [];
        e.length && d.push(["tr", e.join(".")]);
        var f = Kz[b] || [];
        f.length && d.push(["ti", f.join(".")]);
        c && (delete Jz[b], delete Kz[b]);
        return d
    };

    function Nz(a, b, c) {
        c = c === void 0 ? !1 : c;
        Oz().addRestriction(0, a, b, c)
    }

    function Pz(a, b, c) {
        c = c === void 0 ? !1 : c;
        Oz().addRestriction(1, a, b, c)
    }

    function Qz() {
        var a = Ej();
        return Oz().getRestrictions(1, a)
    }
    var Rz = function() {
            this.container = {};
            this.C = {}
        },
        Sz = function(a, b) {
            var c = a.container[b];
            c || (c = {
                _entity: {
                    internal: [],
                    external: []
                },
                _event: {
                    internal: [],
                    external: []
                }
            }, a.container[b] = c);
            return c
        };
    Rz.prototype.addRestriction = function(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        if (!d || !this.C[b]) {
            var e = Sz(this, b);
            a === 0 ? d ? e._entity.external.push(c) : e._entity.internal.push(c) : a === 1 && (d ? e._event.external.push(c) : e._event.internal.push(c))
        }
    };
    Rz.prototype.getRestrictions = function(a, b) {
        var c = Sz(this, b);
        if (a === 0) {
            var d, e;
            return [].concat(Aa((c == null ? void 0 : (d = c._entity) == null ? void 0 : d.internal) || []), Aa((c == null ? void 0 : (e = c._entity) == null ? void 0 : e.external) || []))
        }
        if (a === 1) {
            var f, g;
            return [].concat(Aa((c == null ? void 0 : (f = c._event) == null ? void 0 : f.internal) || []), Aa((c == null ? void 0 : (g = c._event) == null ? void 0 : g.external) || []))
        }
        return []
    };
    Rz.prototype.getExternalRestrictions = function(a, b) {
        var c = Sz(this, b),
            d, e;
        return a === 0 ? (c == null ? void 0 : (d = c._entity) == null ? void 0 : d.external) || [] : (c == null ? void 0 : (e = c._event) == null ? void 0 : e.external) || []
    };
    Rz.prototype.removeExternalRestrictions = function(a) {
        var b = Sz(this, a);
        b._event && (b._event.external = []);
        b._entity && (b._entity.external = []);
        this.C[a] = !0
    };

    function Oz() {
        return go("r", function() {
            return new Rz
        })
    };

    function Tz(a, b, c, d) {
        var e = Nf[a],
            f = Uz(a, b, c, d);
        if (!f) return null;
        var g = ag(e[nf.xm], c, []);
        if (g && g.length) {
            var h = g[0];
            f = Tz(h.index, {
                onSuccess: f,
                onFailure: h.Vm === 1 ? b.terminate : f,
                terminate: b.terminate
            }, c, d)
        }
        return f
    }

    function Uz(a, b, c, d) {
        function e() {
            function x() {
                nm(3);
                var O = Eb() - G;
                cz(1, a, Nf[a][nf.oh]);
                Lz(c.id, f, "7");
                hz(c.Rc, E, "exception", O);
                H(109) && tx(c, f, Nw.N.Wi);
                L || (L = !0, h())
            }
            if (f[nf.rp]) h();
            else {
                var y = $f(f, c, []),
                    z = y[nf.Pn];
                if (z != null)
                    for (var D = 0; D < z.length; D++)
                        if (!xn(z[D])) {
                            h();
                            return
                        }
                var E = gz(c.Rc, String(f[nf.Ra]), Number(f[nf.yh]), y[nf.METADATA]),
                    L = !1;
                y.vtp_gtmOnSuccess = function() {
                    if (!L) {
                        L = !0;
                        var O = Eb() - G;
                        Lz(c.id, Nf[a], "5");
                        hz(c.Rc, E, "success", O);
                        H(109) && tx(c, f, Nw.N.Yi);
                        g()
                    }
                };
                y.vtp_gtmOnFailure = function() {
                    if (!L) {
                        L = !0;
                        var O = Eb() - G;
                        Lz(c.id, Nf[a], "6");
                        hz(c.Rc, E, "failure", O);
                        H(109) && tx(c, f, Nw.N.Xi);
                        h()
                    }
                };
                y.vtp_gtmTagId = f.tag_id;
                y.vtp_gtmEventId = c.id;
                c.priorityId && (y.vtp_gtmPriorityId = c.priorityId);
                Lz(c.id, f, "1");
                H(109) && sx(c, f);
                var G = Eb();
                try {
                    bg(y, {
                        event: c,
                        index: a,
                        type: 1
                    })
                } catch (O) {
                    x(O)
                }
                H(109) && tx(c, f, Nw.N.Gm)
            }
        }
        var f = Nf[a],
            g = b.onSuccess,
            h = b.onFailure,
            l = b.terminate;
        if (c.isBlocked(f)) return null;
        var n = ag(f[nf.Hm], c, []);
        if (n && n.length) {
            var p = n[0],
                q = Tz(p.index, {
                    onSuccess: g,
                    onFailure: h,
                    terminate: l
                }, c, d);
            if (!q) return null;
            g = q;
            h = p.Vm === 2 ? l : q
        }
        if (f[nf.om] || f[nf.up]) {
            var r = f[nf.om] ? Of : c.Jr,
                v = g,
                t = h;
            if (!r[a]) {
                var u = Vz(a, r, Gb(e));
                g = u.onSuccess;
                h = u.onFailure
            }
            return function() {
                r[a](v, t)
            }
        }
        return e
    }

    function Vz(a, b, c) {
        var d = [],
            e = [];
        b[a] = Wz(d, e, c);
        return {
            onSuccess: function() {
                b[a] = Xz;
                for (var f = 0; f < d.length; f++) d[f]()
            },
            onFailure: function() {
                b[a] = Yz;
                for (var f = 0; f < e.length; f++) e[f]()
            }
        }
    }

    function Wz(a, b, c) {
        return function(d, e) {
            a.push(d);
            b.push(e);
            c()
        }
    }

    function Xz(a) {
        a()
    }

    function Yz(a, b) {
        b()
    };
    var aA = function(a, b) {
        for (var c = [], d = 0; d < Nf.length; d++)
            if (a[d]) {
                var e = Nf[d];
                var f = jz(b.Rc);
                try {
                    var g = Tz(d, {
                        onSuccess: f,
                        onFailure: f,
                        terminate: f
                    }, b, d);
                    if (g) {
                        var h = e[nf.Ra];
                        if (!h) throw Error("Error: No function name given for function call.");
                        var l = Pf[h];
                        c.push({
                            Dn: d,
                            priorityOverride: (l ? l.priorityOverride || 0 : 0) || dz(e[nf.Ra], 1) || 0,
                            execute: g
                        })
                    } else Zz(d, b), f()
                } catch (p) {
                    f()
                }
            }
        c.sort($z);
        for (var n = 0; n < c.length; n++) c[n].execute();
        return c.length > 0
    };

    function bA(a, b) {
        if (!az) return !1;
        var c = a["gtm.triggers"] && String(a["gtm.triggers"]),
            d = bz(a.event, c ? String(c).split(",") : []);
        if (!d.length) return !1;
        for (var e = 0; e < d.length; ++e) {
            var f = jz(b);
            try {
                d[e](a, f)
            } catch (g) {
                f()
            }
        }
        return !0
    }

    function $z(a, b) {
        var c, d = b.priorityOverride,
            e = a.priorityOverride;
        c = d > e ? 1 : d < e ? -1 : 0;
        var f;
        if (c !== 0) f = c;
        else {
            var g = a.Dn,
                h = b.Dn;
            f = g > h ? 1 : g < h ? -1 : 0
        }
        return f
    }

    function Zz(a, b) {
        if (ik) {
            var c = function(d) {
                var e = b.isBlocked(Nf[d]) ? "3" : "4",
                    f = ag(Nf[d][nf.xm], b, []);
                f && f.length && c(f[0].index);
                Lz(b.id, Nf[d], e);
                var g = ag(Nf[d][nf.Hm], b, []);
                g && g.length && c(g[0].index)
            };
            c(a)
        }
    }
    var cA = !1,
        az;

    function dA() {
        az || (az = new $y);
        return az
    }

    function eA(a) {
        var b = a["gtm.uniqueEventId"],
            c = a["gtm.priorityId"],
            d = a.event;
        if (H(109)) {}
        if (d === "gtm.js") {
            if (cA) return !1;
            cA = !0
        }
        var e = !1,
            f = Qz(),
            g = td(a, null);
        if (!f.every(function(v) {
                return v({
                    originalEventData: g
                })
            })) {
            if (d !== "gtm.js" && d !== "gtm.init" && d !== "gtm.init_consent") return !1;
            e = !0
        }
        Az(b, d);
        var h = a.eventCallback,
            l =
            a.eventTimeout,
            n = {
                id: b,
                priorityId: c,
                name: d,
                isBlocked: fA(g, e),
                Jr: [],
                logMacroError: function(v, t, u) {
                    N(6);
                    nm(0);
                    cz(2, t, u)
                },
                cachedModelValues: gA(),
                Rc: new fz(function() {
                    if (H(109)) {}
                    h && h.apply(h, Array.prototype.slice.call(arguments,
                        0))
                }, l),
                originalEventData: g
            };
        H(120) && ik && (n.reportMacroDiscrepancy = Fz);
        H(109) && px(n.id);
        var p = lg(n);
        H(109) && qx(n.id);
        e && (p = hA(p));
        H(109) && ox(b);
        var q = aA(p, n),
            r = bA(a, n.Rc);
        kz(n.Rc);
        d !== "gtm.js" && d !== "gtm.sync" || qz();
        return iA(p, q) || r
    }

    function gA() {
        var a = {};
        a.event = ip("event", 1);
        a.ecommerce = ip("ecommerce", 1);
        a.gtm = ip("gtm");
        a.eventModel = ip("eventModel");
        return a
    }

    function fA(a, b) {
        var c = Yy();
        return function(d) {
            if (c(d)) return !0;
            var e = d && d[nf.Ra];
            if (!e || typeof e !== "string") return !0;
            e = e.replace(/^_*/, "");
            var f, g = Ej();
            f = Oz().getRestrictions(0, g);
            var h = a;
            b && (h = td(a, null), h["gtm.uniqueEventId"] = Number.MAX_SAFE_INTEGER);
            for (var l = Zi[e] || [], n = m(f), p = n.next(); !p.done; p = n.next()) {
                var q = p.value;
                try {
                    if (!q({
                            entityId: e,
                            securityGroups: l,
                            originalEventData: h
                        })) return !0
                } catch (r) {
                    return !0
                }
            }
            return !1
        }
    }

    function hA(a) {
        for (var b = [], c = 0; c < a.length; c++)
            if (a[c]) {
                var d = String(Nf[c][nf.Ra]);
                if (Pi[d] || Nf[c][nf.vp] !== void 0 || dz(d, 2)) b[c] = !0
            }
        return b
    }

    function iA(a, b) {
        if (!b) return b;
        for (var c = 0; c < a.length; c++)
            if (a[c] && Nf[c] && !Qi[String(Nf[c][nf.Ra])]) return !0;
        return !1
    };

    function jA() {
        dA().addListener("gtm.init", function(a, b) {
            Ki.H = !0;
            $l();
            b()
        })
    };

    function kA() {
        if (fo.pscdl !== void 0) Ll(Hl.Z.Uh) === void 0 && Kl(Hl.Z.Uh, fo.pscdl);
        else {
            var a = function(c) {
                    fo.pscdl = c;
                    Kl(Hl.Z.Uh, c)
                },
                b = function() {
                    a("error")
                };
            try {
                zc.cookieDeprecationLabel ? (a("pending"), zc.cookieDeprecationLabel.getValue().then(a).catch(b)) : a("noapi")
            } catch (c) {
                b(c)
            }
        }
    };
    var lA = !1,
        mA = 0,
        nA = [];

    function oA(a) {
        if (!lA) {
            var b = A.createEventObject,
                c = A.readyState === "complete",
                d = A.readyState === "interactive";
            if (!a || a.type !== "readystatechange" || c || !b && d) {
                lA = !0;
                for (var e = 0; e < nA.length; e++) Sc(nA[e])
            }
            nA.push = function() {
                for (var f = Ea.apply(0, arguments), g = 0; g < f.length; g++) Sc(f[g]);
                return 0
            }
        }
    }

    function pA() {
        if (!lA && mA < 140) {
            mA++;
            try {
                var a, b;
                (b = (a = A.documentElement).doScroll) == null || b.call(a, "left");
                oA()
            } catch (c) {
                w.setTimeout(pA, 50)
            }
        }
    }

    function qA() {
        var a = w;
        lA = !1;
        mA = 0;
        if (A.readyState === "interactive" && !A.createEventObject || A.readyState === "complete") oA();
        else {
            Qc(A, "DOMContentLoaded", oA);
            Qc(A, "readystatechange", oA);
            if (A.createEventObject && A.documentElement.doScroll) {
                var b = !0;
                try {
                    b = !a.frameElement
                } catch (c) {}
                b && pA()
            }
            Qc(a, "load", oA)
        }
    }

    function rA(a) {
        lA ? a() : nA.push(a)
    };

    function sA(a, b) {
        return arguments.length === 1 ? tA("set", a) : tA("set", a, b)
    }

    function uA(a, b) {
        return arguments.length === 1 ? tA("config", a) : tA("config", a, b)
    }

    function vA(a, b, c) {
        c = c || {};
        c[K.m.sd] = a;
        return tA("event", b, c)
    }

    function tA() {
        return arguments
    };
    var wA = function() {
        this.messages = [];
        this.C = []
    };
    wA.prototype.enqueue = function(a, b, c) {
        var d = this.messages.length + 1;
        a["gtm.uniqueEventId"] = b;
        a["gtm.priorityId"] = d;
        var e = na(Object, "assign").call(Object, {}, c, {
                eventId: b,
                priorityId: d,
                fromContainerExecution: !0
            }),
            f = {
                message: a,
                notBeforeEventId: b,
                priorityId: d,
                messageContext: e
            };
        this.messages.push(f);
        for (var g = 0; g < this.C.length; g++) try {
            this.C[g](f)
        } catch (h) {}
    };
    wA.prototype.listen = function(a) {
        this.C.push(a)
    };
    wA.prototype.get = function() {
        for (var a = {}, b = 0; b < this.messages.length; b++) {
            var c = this.messages[b],
                d = a[c.notBeforeEventId];
            d || (d = [], a[c.notBeforeEventId] = d);
            d.push(c)
        }
        return a
    };
    wA.prototype.prune = function(a) {
        for (var b = [], c = [], d = 0; d < this.messages.length; d++) {
            var e = this.messages[d];
            e.notBeforeEventId === a ? b.push(e) : c.push(e)
        }
        this.messages = c;
        return b
    };

    function xA(a, b, c) {
        c.eventMetadata = c.eventMetadata || {};
        c.eventMetadata[Q.A.Oa] = C(6);
        yA().enqueue(a, b, c)
    }

    function zA() {
        var a = AA;
        yA().listen(a)
    }

    function yA() {
        return go("mb", function() {
            return new wA
        })
    };
    var BA = 0,
        CA = 0;
    var DA = {},
        EA = {};

    function FA(a, b) {
        for (var c = [], d = [], e = {}, f = 0; f < a.length; e = {
                Lj: void 0,
                rj: void 0
            }, f++) {
            var g = a[f];
            if (g.indexOf("-") >= 0) {
                if (e.Lj = oo(g, b), e.Lj) {
                    var h = Cj();
                    tb(h, function(r) {
                        return function(v) {
                            return r.Lj.destinationId === v
                        }
                    }(e)) ? c.push(g) : d.push(g)
                }
            } else {
                var l = DA[g] || [];
                e.rj = {};
                l.forEach(function(r) {
                    return function(v) {
                        r.rj[v] = !0
                    }
                }(e));
                for (var n = Fj(), p = 0; p < n.length; p++)
                    if (e.rj[n[p]]) {
                        c = c.concat(Cj());
                        break
                    }
                var q = EA[g] || [];
                q.length && (c = c.concat(q))
            }
        }
        return {
            Fj: c,
            Wq: d
        }
    }

    function GA(a) {
        xb(DA, function(b, c) {
            var d = c.indexOf(a);
            d >= 0 && c.splice(d, 1)
        })
    }

    function HA(a) {
        xb(EA, function(b, c) {
            var d = c.indexOf(a);
            d >= 0 && c.splice(d, 1)
        })
    };
    var IA = !1,
        JA = !1;

    function KA(a, b) {
        var c = {},
            d = (c.event = a, c);
        b && (d.eventModel = td(b, null), b[K.m.vf] && (d.eventCallback = b[K.m.vf]), b[K.m.Wg] && (d.eventTimeout = b[K.m.Wg]));
        return d
    }

    function LA(a, b) {
        a.hasOwnProperty("gtm.uniqueEventId") || Object.defineProperty(a, "gtm.uniqueEventId", {
            value: lo()
        });
        b.eventId = a["gtm.uniqueEventId"];
        b.priorityId = a["gtm.priorityId"];
        return {
            eventId: b.eventId,
            priorityId: b.priorityId
        }
    }

    function MA(a, b) {
        var c = a && a[K.m.sd];
        c === void 0 && (c = dp(K.m.sd, 2), c === void 0 && (c = "default"));
        if (qb(c) || Array.isArray(c)) {
            var d;
            d = b.isGtmEvent ? qb(c) ? [c] : c : c.toString().replace(/\s+/g, "").split(",");
            var e = FA(d, b.isGtmEvent),
                f = e.Fj,
                g = e.Wq;
            if (g.length)
                for (var h = NA(a), l = 0; l < g.length; l++) {
                    var n = oo(g[l], b.isGtmEvent);
                    if (n) {
                        var p = n.destinationId,
                            q = void 0;
                        ((q = wj(n.destinationId)) == null ? void 0 : q.state) === 0 || Ty(p, h, {
                            source: 3,
                            fromContainerExecution: b.fromContainerExecution
                        })
                    }
                }
            var r = f.concat(g);
            return {
                Fj: po(f, b.isGtmEvent),
                Pp: po(r, b.isGtmEvent)
            }
        }
    }
    var OA = void 0,
        PA = void 0;

    function QA(a, b, c) {
        var d = td(a, null);
        d.eventId = void 0;
        d.inheritParentConfig = void 0;
        Object.keys(b).some(function(f) {
            return b[f] !== void 0
        }) && N(136);
        var e = td(b, null);
        td(c, e);
        xA(uA(Fj()[0], e), a.eventId, d)
    }

    function NA(a) {
        for (var b = m([K.m.ud, K.m.qc]), c = b.next(); !c.done; c = b.next()) {
            var d = c.value,
                e = a && a[d] || Gp.C[d];
            if (e) return e
        }
    }
    var RA = {
            config: function(a, b) {
                var c = LA(a, b);
                if (!(a.length < 2) && qb(a[1])) {
                    var d = {};
                    if (a.length > 2) {
                        if (a[2] !== void 0 && !sd(a[2]) || a.length > 3) return;
                        d = a[2]
                    }
                    var e = oo(a[1], b.isGtmEvent);
                    if (e) {
                        var f, g, h;
                        a: {
                            if (!cg(7)) {
                                var l = Hj(Ij());
                                if (Sj(l)) {
                                    var n = l.parent,
                                        p = n.isDestination;
                                    h = {
                                        ar: Hj(n),
                                        Tq: p
                                    };
                                    break a
                                }
                            }
                            h = void 0
                        }
                        var q = h;
                        q && (f = q.ar, g = q.Tq);
                        Az(c.eventId, "gtag.config");
                        var r = e.destinationId,
                            v = e.id !== r;
                        if (v ? Cj().indexOf(r) === -1 : Fj().indexOf(r) === -1) {
                            if (!b.inheritParentConfig && !d[K.m.Gc]) {
                                var t = NA(d);
                                if (v) Ty(r, t, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                });
                                else if (f !== void 0 && f.containers.indexOf(r) !== -1) {
                                    var u = d;
                                    OA ? QA(b, u, OA) : PA || (PA = td(u, null))
                                } else Py(r, t, !0, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                })
                            }
                        } else {
                            if (f && (N(128), g && N(130), b.inheritParentConfig)) {
                                var x;
                                var y = d;
                                PA ? (QA(b, PA, y), x = !1) : (!y[K.m.wd] && cg(11) && OA || (OA = td(y, null)), x = !0);
                                x && f.containers && f.containers.join(",");
                                return
                            }
                            kk && (Tn === 1 && (Sl.mcc = !1), Tn = 2);
                            if (cg(11) && !v && !d[K.m.wd]) {
                                var z = JA;
                                JA = !0;
                                var D = d;
                                if (H(278)) {
                                    var E = Object.keys(D).length >
                                        0 ? 2 : 1,
                                        L, G, O = (b == null ? void 0 : (G = b.originatingEntity) == null ? void 0 : G.originContainerId) || "";
                                    L = O ? O.indexOf("GTM-") === 0 ? 3 : 2 : 1;
                                    z ? (N(184), CA === L || CA !== 3 && L !== 3 || N(185), BA !== 2 && E !== 2 || N(186)) : (BA = E, CA = L)
                                }
                                if (z) return
                            }
                            IA || N(43);
                            if (!b.noTargetGroup)
                                if (v) {
                                    HA(e.id);
                                    var W = e.id,
                                        ia = d[K.m.Zg] || "default";
                                    ia = String(ia).split(",");
                                    for (var T = 0; T < ia.length; T++) {
                                        var ca = EA[ia[T]] || [];
                                        EA[ia[T]] = ca;
                                        ca.indexOf(W) < 0 && ca.push(W)
                                    }
                                } else {
                                    GA(e.id);
                                    var va = e.id,
                                        ka = d[K.m.Zg] || "default";
                                    ka = ka.toString().split(",");
                                    for (var Z = 0; Z < ka.length; Z++) {
                                        var V =
                                            DA[ka[Z]] || [];
                                        DA[ka[Z]] = V;
                                        V.indexOf(va) < 0 && V.push(va)
                                    }
                                }
                            delete d[K.m.Zg];
                            var ja = b.eventMetadata || {};
                            ja.hasOwnProperty(Q.A.Bd) || (ja[Q.A.Bd] = !b.fromContainerExecution);
                            b.eventMetadata = ja;
                            delete d[K.m.vf];
                            for (var ta = v ? [e.id] : Cj(), ua = 0; ua < ta.length; ua++) {
                                var Ta = d,
                                    Ya = ta[ua],
                                    Lb = td(b, null),
                                    Mb = oo(Ya, Lb.isGtmEvent);
                                Mb && Gp.push("config", [Ta], Mb, Lb)
                            }
                        }
                    }
                }
            },
            consent: function(a, b) {
                if (a.length === 3) {
                    N(39);
                    var c = LA(a, b),
                        d = a[1],
                        e = {},
                        f = Om(a[2]),
                        g;
                    for (g in f)
                        if (f.hasOwnProperty(g)) {
                            var h = f[g];
                            e[g] = g === K.m.Gg ? Array.isArray(h) ?
                                NaN : Number(h) : g === K.m.fc ? (Array.isArray(h) ? h : [h]).map(Pm) : Qm(h)
                        }
                    b.fromContainerExecution || (e[K.m.W] && N(139), e[K.m.La] && N(140));
                    d === "default" ? tn(e) : d === "update" ? vn(e, c) : d === "declare" && b.fromContainerExecution && sn(e)
                }
            },
            container_config: function(a, b) {
                if (H(240) && b.isGtmEvent && !(b.eventMetadata && b.eventMetadata[Q.A.nh] && b.eventMetadata[Q.A.Oa] !== Ej() || a.length !== 3) && qb(a[1]) && sd(a[2])) {
                    var c = a[2],
                        d = oo(a[1], !0);
                    if (d) {
                        var e = d.destinationId,
                            f = td(b, null),
                            g = oo(e, f.isGtmEvent);
                        g && Gp.push("container_config", [c], g, f)
                    }
                }
            },
            destination_config: function(a, b) {
                if (H(240) && b.isGtmEvent && !(b.eventMetadata && b.eventMetadata[Q.A.nh] && b.eventMetadata[Q.A.Oa] !== Ej() || a.length !== 3) && qb(a[1]) && sd(a[2])) {
                    var c = a[2],
                        d = oo(a[1], !0);
                    if (d) {
                        var e = d.destinationId,
                            f = td(b, null),
                            g = oo(e, f.isGtmEvent);
                        g && Gp.push("destination_config", [c], g, f)
                    }
                }
            },
            event: function(a, b) {
                var c = a[1];
                if (!(a.length < 2) && qb(c)) {
                    var d = void 0;
                    if (a.length > 2) {
                        if (!sd(a[2]) && a[2] !== void 0 || a.length > 3) return;
                        d = a[2]
                    }
                    var e = KA(c, d),
                        f = LA(a, b),
                        g = f.eventId,
                        h = f.priorityId;
                    e["gtm.uniqueEventId"] = g;
                    h && (e["gtm.priorityId"] = h);
                    if (c === "optimize.callback") return e.eventModel = e.eventModel || {}, e;
                    var l = MA(d, b);
                    if (l) {
                        for (var n = l.Fj, p = l.Pp, q = p.map(function(O) {
                                return O.id
                            }), r = p.map(function(O) {
                                return O.destinationId
                            }), v = n.map(function(O) {
                                return O.id
                            }), t = m(Cj()), u = t.next(); !u.done; u = t.next()) {
                            var x = u.value;
                            r.indexOf(x) < 0 && v.push(x)
                        }
                        Az(g, c);
                        for (var y = m(v), z = y.next(); !z.done; z = y.next()) {
                            var D = z.value,
                                E = td(b, null),
                                L = td(d, null);
                            delete L[K.m.vf];
                            var G = E.eventMetadata || {};
                            G.hasOwnProperty(Q.A.Bd) ||
                                (G[Q.A.Bd] = !E.fromContainerExecution);
                            G[Q.A.Ri] = q.slice();
                            G[Q.A.cg] = r.slice();
                            E.eventMetadata = G;
                            Fp(c, L, D, E)
                        }
                        e.eventModel = e.eventModel || {};
                        q.length > 0 ? e.eventModel[K.m.sd] = q.join(",") : delete e.eventModel[K.m.sd];
                        IA || N(43);
                        b.noGtmEvent === void 0 && b.eventMetadata && b.eventMetadata[Q.A.Em] && (b.noGtmEvent = !0);
                        e.eventModel[K.m.Fc] && (b.noGtmEvent = !0);
                        return b.noGtmEvent ? void 0 : e
                    }
                }
            },
            get: function(a, b) {
                N(53);
                if (a.length === 4 && qb(a[1]) && qb(a[2]) && pb(a[3])) {
                    var c = oo(a[1], b.isGtmEvent),
                        d = String(a[2]),
                        e = a[3];
                    if (c) {
                        IA ||
                            N(43);
                        var f = NA();
                        if (tb(Cj(), function(h) {
                                return c.destinationId === h
                            })) {
                            LA(a, b);
                            var g = {};
                            td((g[K.m.yf] = d, g[K.m.xf] = e, g), null);
                            Hp(d, function(h) {
                                Sc(function() {
                                    e(h)
                                })
                            }, c.id, b)
                        } else Ty(c.destinationId, f, {
                            source: 4,
                            fromContainerExecution: b.fromContainerExecution
                        })
                    }
                }
            },
            js: function(a, b) {
                if (a.length === 2 && a[1].getTime) {
                    IA = !0;
                    var c = LA(a, b),
                        d = c.eventId,
                        e = c.priorityId,
                        f = {};
                    return f.event = "gtm.js", f["gtm.start"] = a[1].getTime(), f["gtm.uniqueEventId"] = d, f["gtm.priorityId"] = e, f
                }
            },
            policy: function(a) {
                if (a.length === 3 &&
                    qb(a[1]) && pb(a[2])) {
                    if (rg(a[1], a[2]), N(74), a[1] === "all") {
                        N(75);
                        var b = !1;
                        try {
                            b = a[2](C(5), "unknown", {})
                        } catch (c) {}
                        b || N(76)
                    }
                } else N(73)
            },
            set: function(a, b) {
                var c = void 0;
                a.length === 2 && sd(a[1]) ? c = td(a[1], null) : a.length === 3 && qb(a[1]) && (c = {}, sd(a[2]) || Array.isArray(a[2]) ? c[a[1]] = td(a[2], null) : c[a[1]] = a[2]);
                if (c) {
                    var d = LA(a, b),
                        e = d.eventId,
                        f = d.priorityId;
                    td(c, null);
                    C(5);
                    var g = td(c, null);
                    Gp.push("set", [g], void 0, b);
                    c["gtm.uniqueEventId"] = e;
                    f && (c["gtm.priorityId"] = f);
                    delete c.event;
                    b.overwriteModelFields = !0;
                    return c
                }
            }
        },
        SA = {
            policy: !0
        };
    var UA = function(a) {
        if (TA(a)) return a;
        this.value = a
    };
    UA.prototype.getUntrustedMessageValue = function() {
        return this.value
    };
    var TA = function(a) {
        return !a || qd(a) !== "object" || sd(a) ? !1 : "getUntrustedMessageValue" in a
    };
    UA.prototype.getUntrustedMessageValue = UA.prototype.getUntrustedMessageValue;
    var VA = !1,
        WA = [];

    function XA() {
        if (!VA) {
            VA = !0;
            for (var a = 0; a < WA.length; a++) Sc(WA[a])
        }
    }

    function YA(a) {
        VA ? Sc(a) : WA.push(a)
    };
    var ZA = 0,
        $A = {},
        aB = [],
        bB = [],
        cB = !1,
        dB = !1;

    function eB(a, b) {
        return a.messageContext.eventId - b.messageContext.eventId || a.messageContext.priorityId - b.messageContext.priorityId
    }

    function fB(a, b, c) {
        a.eventCallback = b;
        c && (a.eventTimeout = c);
        return gB(a)
    }

    function hB(a, b) {
        if (!rb(b) || b < 0) b = 0;
        var c = ko(),
            d = 0,
            e = !1,
            f = void 0;
        f = w.setTimeout(function() {
            e || (e = !0, a());
            f = void 0
        }, b);
        return function() {
            var g = c ? c.subscribers : 1;
            ++d === g && (f && (w.clearTimeout(f), f = void 0), e || (a(), e = !0))
        }
    }

    function iB(a) {
        if (a == null || typeof a !== "object") return !1;
        if (a.event) return !0;
        if (yb(a)) {
            var b = a[0];
            if (b === "config" || b === "event" || b === "js" || b === "get") return !0
        }
        return !1
    }

    function jB() {
        var a;
        if (bB.length) a = bB.shift();
        else if (aB.length) a = aB.shift();
        else return;
        var b;
        var c = a;
        if (cB || !iB(c.message)) b = c;
        else {
            cB = !0;
            var d = c.message["gtm.uniqueEventId"],
                e, f;
            typeof d === "number" ? (e = d - 2, f = d - 1) : (e = lo(), f = lo(), c.message["gtm.uniqueEventId"] = lo());
            var g = {},
                h = {
                    message: (g.event = "gtm.init_consent", g["gtm.uniqueEventId"] = e, g),
                    messageContext: {
                        eventId: e
                    }
                },
                l = {},
                n = {
                    message: (l.event = "gtm.init", l["gtm.uniqueEventId"] = f, l),
                    messageContext: {
                        eventId: f
                    }
                };
            aB.unshift(n, c);
            b = h
        }
        return b
    }

    function kB() {
        for (var a = !1, b; !dB && (b = jB());) {
            dB = !0;
            delete ap.eventModel;
            cp();
            var c = b,
                d = c.message,
                e = c.messageContext;
            if (d == null) dB = !1;
            else {
                e.fromContainerExecution && hp();
                try {
                    if (pb(d)) try {
                        d.call(ep)
                    } catch (L) {} else if (Array.isArray(d)) {
                        if (qb(d[0])) {
                            var f = d[0].split("."),
                                g = f.pop(),
                                h = d.slice(1),
                                l = dp(f.join("."), 2);
                            if (l != null) try {
                                l[g].apply(l, h)
                            } catch (L) {}
                        }
                    } else {
                        var n = void 0;
                        if (yb(d)) a: {
                            if (d.length && qb(d[0])) {
                                var p = RA[d[0]];
                                if (p && (!e.fromContainerExecution || !SA[d[0]])) {
                                    n = p(d, e);
                                    break a
                                }
                            }
                            n = void 0
                        }
                        else n =
                            d;
                        if (n) {
                            var q;
                            for (var r = n, v = r._clear || e.overwriteModelFields, t = m(Object.keys(r)), u = t.next(); !u.done; u = t.next()) {
                                var x = u.value;
                                x !== "_clear" && (v && gp(x), gp(x, r[x]))
                            }
                            Wi || (Wi = r["gtm.start"]);
                            var y = r["gtm.uniqueEventId"];
                            r.event ? (typeof y !== "number" && (y = lo(), r["gtm.uniqueEventId"] = y, gp("gtm.uniqueEventId", y)), q = eA(r)) : q = !1;
                            a = q || a
                        }
                    }
                } finally {
                    e.fromContainerExecution && cp(!0);
                    var z = d["gtm.uniqueEventId"];
                    if (typeof z === "number") {
                        for (var D = $A[String(z)] || [], E = 0; E < D.length; E++) bB.push(lB(D[E]));
                        D.length && bB.sort(eB);
                        delete $A[String(z)];
                        z > ZA && (ZA = z)
                    }
                    dB = !1
                }
            }
        }
        return !a
    }

    function mB() {
        if (H(109)) {
            var a = !cg(51);
        }
        var c = kB();
        if (H(109)) {}
        try {
            var e = w[C(19)],
                f = C(5),
                g = e.hide;
            if (g && g[f] !== void 0 &&
                g.end) {
                g[f] = !1;
                var h = !0,
                    l;
                for (l in g)
                    if (g.hasOwnProperty(l) && g[l] === !0) {
                        h = !1;
                        break
                    }
                h && (g.end(), g.end = null)
            }
        } catch (n) {
            C(5)
        }
        return c
    }

    function AA(a) {
        if (ZA < a.notBeforeEventId) {
            var b = String(a.notBeforeEventId);
            $A[b] = $A[b] || [];
            $A[b].push(a)
        } else bB.push(lB(a)), bB.sort(eB), Sc(function() {
            dB || kB()
        })
    }

    function lB(a) {
        return {
            message: a.message,
            messageContext: a.messageContext
        }
    }

    function nB() {
        function a(f) {
            var g = {};
            if (TA(f)) {
                var h = f;
                f = TA(h) ? h.getUntrustedMessageValue() : void 0;
                g.fromContainerExecution = !0
            }
            return {
                message: f,
                messageContext: g
            }
        }
        var b = Dc(C(19), []),
            c = jo();
        c.pruned === !0 && N(83);
        $A = yA().get();
        zA();
        rA(function() {
            if (!c.gtmDom) {
                c.gtmDom = !0;
                var f = {};
                b.push((f.event = "gtm.dom", f))
            }
        });
        YA(function() {
            if (!c.gtmLoad) {
                c.gtmLoad = !0;
                var f = {};
                b.push((f.event = "gtm.load", f))
            }
        });
        c.subscribers = (c.subscribers || 0) + 1;
        var d = b.push;
        b.push = function() {
            var f;
            if (fo.SANDBOXED_JS_SEMAPHORE > 0) {
                f = [];
                for (var g = 0; g < arguments.length; g++) f[g] = new UA(arguments[g])
            } else f = [].slice.call(arguments, 0);
            var h = f.map(function(q) {
                return a(q)
            });
            aB.push.apply(aB, h);
            var l = d.apply(b, f),
                n = Math.max(100, gg(1, 300));
            if (this.length > n)
                for (N(4), c.pruned = !0; this.length > n;) this.shift();
            var p = typeof l !== "boolean" || l;
            return kB() && p
        };
        var e = b.slice(0).map(function(f) {
            return a(f)
        });
        aB.push.apply(aB, e);
        if (!cg(51)) {
            if (H(109)) {}
            Sc(mB)
        }
    }
    var gB = function(a) {
        return w[C(19)].push(a)
    };

    function oB(a) {
        gB(a)
    };

    function pB() {
        var a, b = oj(w.location.href);
        (a = b.hostname + b.pathname) && Vl("dl", encodeURIComponent(a));
        var c;
        var d = C(5);
        if (d) {
            var e = cg(7) ? 1 : 0,
                f, g = Ij(),
                h = Hj(g),
                l = (f = h && h.context) && f.fromContainerExecution ? 1 : 0,
                n = f && f.source || 0,
                p = C(6);
            c = d + ";" + p + ";" + l + ";" + n + ";" + e
        } else c = void 0;
        var q = c;
        q && Vl("tdp", q);
        var r = Xp(!0);
        r !== void 0 && Vl("frm", String(r))
    };
    var qB = {},
        rB = void 0;

    function sB() {
        if (an() || kk) Vl("csp", function() {
            return Object.keys(qB).map(function(a) {
                return [a === "undefined" ? "" : a].concat(Aa(qB[a])).join(";")
            }).join("~") || void 0
        }, !1), w.addEventListener("securitypolicyviolation", function(a) {
            if (a.disposition === "enforce") {
                N(179);
                var b = Yk(a.effectiveDirective);
                if (b) {
                    var c;
                    var d = Wk(b, a.blockedURI);
                    c = d ? Uk[b][d] : void 0;
                    if (c) {
                        var e;
                        a: {
                            try {
                                var f = new URL(a.blockedURI),
                                    g = f.pathname.indexOf(";");
                                e = g >= 0 ? f.origin + f.pathname.substring(0, g) : f.origin + f.pathname;
                                break a
                            } catch (u) {}
                            e =
                            void 0
                        }
                        var h = e;
                        if (h) {
                            for (var l = m(c), n = l.next(); !n.done; n = l.next()) {
                                var p = n.value;
                                if (!p.vn) {
                                    p.vn = !0;
                                    if (H(59)) {
                                        var q = {
                                            eventId: p.eventId,
                                            priorityId: p.priorityId
                                        };
                                        if (an()) {
                                            var r = q,
                                                v = {
                                                    type: 1,
                                                    blockedUrl: h,
                                                    endpoint: p.endpoint,
                                                    violation: a.effectiveDirective
                                                };
                                            if (an()) {
                                                var t = gn("TAG_DIAGNOSTICS", {
                                                    eventId: r == null ? void 0 : r.eventId,
                                                    priorityId: r == null ? void 0 : r.priorityId
                                                });
                                                t.tagDiagnostics = v;
                                                $m(t)
                                            }
                                        }
                                    }
                                    tB(p.destinationId, p.endpoint)
                                }
                            }
                            Xk(b, a.blockedURI)
                        }
                    }
                }
            }
        })
    }

    function tB(a, b) {
        var c = String(a);
        if (qB.hasOwnProperty(c)) {
            var d = qB[c],
                e = d.findIndex(function(f) {
                    return f >= b
                });
            if (e >= 0 && d[e] === b) return;
            e < 0 && (e = d.length);
            d.splice(e, 0, b)
        } else qB[c] = [b];
        Wl("csp", !0);
        rB === void 0 && H(171) && (rB = w.setTimeout(function() {
            var f;
            if (f = H(171)) a: {
                try {
                    if (Cc) {
                        f = new URL(Cc);
                        break a
                    }
                } catch (l) {}
                f = void 0
            }
            if (f) {
                var g = Sl.csp;
                Sl.csp = !0;
                Sl.seq = !1;
                var h = Xl(!1);
                Sl.csp = g;
                Sl.seq = !0;
                Lc("" + Cc + (Cc.indexOf("?") >= 0 ? "&" : "?") + "is_td=1" + h)
            }
            rB = void 0
        }, 500))
    };
    var uB = void 0;

    function vB() {
        H(236) && w.addEventListener("pageshow", function(a) {
            a && (Vl("bfc", function() {
                return uB ? "1" : "0"
            }), a.persisted ? (uB = !0, Wl("bfc", !0), $l()) : uB = !1)
        })
    };

    function wB() {
        var a;
        var b = Gj();
        if (b)
            if (b.canonicalContainerId) a = b.canonicalContainerId;
            else {
                var c, d = b.scriptContainerId || ((c = b.destinations) == null ? void 0 : c[0]);
                a = d ? "_" + d : void 0
            }
        else a = void 0;
        var e = a;
        e && Vl("pcid", e)
    };
    var xB = /^(https?:)?\/\//;

    function yB() {
        var a = Jj();
        if (a) {
            var b;
            a: {
                var c, d = (c = a.scriptElement) == null ? void 0 : c.src;
                if (d) {
                    var e;
                    try {
                        var f;
                        e = (f = hd()) == null ? void 0 : f.getEntriesByType("resource")
                    } catch (q) {}
                    if (e) {
                        for (var g = -1, h = m(e), l = h.next(); !l.done; l = h.next()) {
                            var n = l.value;
                            if (n.initiatorType === "script" && (g += 1, n.name.replace(xB, "") === d.replace(xB, ""))) {
                                b = g;
                                break a
                            }
                        }
                        N(146)
                    } else N(145)
                }
                b = void 0
            }
            var p = b;
            p !== void 0 && (a.canonicalContainerId && Vl("rtg", String(a.canonicalContainerId)), Vl("slo", String(p)), Vl("hlo", a.htmlLoadOrder || "-1"),
                Vl("lst", String(a.loadScriptType || "0")))
        } else N(144)
    };

    function TB() {};
    var UB = function() {};
    UB.prototype.toString = function() {
        return "undefined"
    };
    var VB = new UB;
    var bC = {};

    function cC(a) {
        ik && (bC[a] = (bC[a] || 0) + 1)
    }

    function dC() {
        var a = [];
        bC[1] && a.push("1." + bC[1]);
        bC[2] && a.push("2." + bC[2]);
        bC[3] && a.push("3." + bC[3]);
        return a.length ? [
            ["odp", a.join("~")]
        ] : []
    };

    function eC() {
        (H(212) || H(279)) && C(5).indexOf("GTM-") !== 0 && (Fx("detect_link_click_events", function(a, b, c) {
            var d = c.options;
            return H(279) ? ((d == null ? void 0 : d.waitForTags) === !0 && cC(1), !0) : (d == null ? void 0 : d.waitForTags) !== !0
        }), Fx("detect_form_submit_events", function(a, b, c) {
            var d = c.options;
            return H(279) ? ((d == null ? void 0 : d.waitForTags) === !0 && cC(2), !0) : (d == null ? void 0 : d.waitForTags) !== !0
        }), Fx("detect_youtube_activity_events", function(a, b, c) {
            var d = c.options;
            return H(279) ? ((d == null ? void 0 : d.fixMissingApi) ===
                !0 && cC(3), !0) : (d == null ? void 0 : d.fixMissingApi) !== !0
        }));
        H(212) && C(5).indexOf("GTM-") !== 0 && Nz(Ej(), function(a) {
            var b, c;
            b = a.entityId;
            c = a.securityGroups;
            var d = "__" + b;
            return dz(d, 5) || !(!Pf[d] || !Pf[d][5]) || c.includes("cmpPartners")
        })
    };

    function fC(a, b) {
        function c(g) {
            var h = oj(g),
                l = ij(h, "protocol"),
                n = ij(h, "host", !0),
                p = ij(h, "port"),
                q = ij(h, "path").toLowerCase().replace(/\/$/, "");
            if (l === void 0 || l === "http" && p === "80" || l === "https" && p === "443") l = "web", p = "default";
            return [l, n, p, q]
        }
        for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
            if (d[f] !== e[f]) return !1;
        return !0
    }

    function gC(a) {
        return hC(a) ? 1 : 0
    }

    function hC(a) {
        var b = a.arg0,
            c = a.arg1;
        if (a.any_of && Array.isArray(c)) {
            for (var d = 0; d < c.length; d++) {
                var e = td(a, {});
                td({
                    arg1: c[d],
                    any_of: void 0
                }, e);
                if (gC(e)) return !0
            }
            return !1
        }
        switch (a["function"]) {
            case "_cn":
                return Zg(b, c);
            case "_css":
                var f;
                a: {
                    if (b) try {
                        for (var g = 0; g < Ug.length; g++) {
                            var h = Ug[g];
                            if (b[h] != null) {
                                f = b[h](c);
                                break a
                            }
                        }
                    } catch (l) {}
                    f = !1
                }
                return f;
            case "_ew":
                return Vg(b, c);
            case "_eq":
                return $g(b, c);
            case "_ge":
                return ah(b, c);
            case "_gt":
                return ch(b, c);
            case "_lc":
                return Wg(b, c);
            case "_le":
                return bh(b,
                    c);
            case "_lt":
                return dh(b, c);
            case "_re":
                return Yg(b, c, a.ignore_case);
            case "_sw":
                return eh(b, c);
            case "_um":
                return fC(b, c)
        }
        return !1
    };
    var iC = function() {
        this.C = this.gppString = void 0
    };
    iC.prototype.reset = function() {
        this.C = this.gppString = void 0
    };
    var jC = new iC;
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    var kC = function(a, b, c, d) {
        dq.call(this);
        this.uh = b;
        this.Xf = c;
        this.Oc = d;
        this.wb = new Map;
        this.wh = 0;
        this.xa = new Map;
        this.Za = new Map;
        this.V = void 0;
        this.H = a
    };
    ya(kC, dq);
    kC.prototype.P = function() {
        delete this.C;
        this.wb.clear();
        this.xa.clear();
        this.Za.clear();
        this.V && ($p(this.H, "message", this.V), delete this.V);
        delete this.H;
        delete this.Oc;
        dq.prototype.P.call(this)
    };
    var lC = function(a) {
            if (a.C) return a.C;
            a.Xf && a.Xf(a.H) ? a.C = a.H : a.C = Wp(a.H, a.uh);
            var b;
            return (b = a.C) != null ? b : null
        },
        nC = function(a, b, c) {
            if (lC(a))
                if (a.C === a.H) {
                    var d = a.wb.get(b);
                    d && d(a.C, c)
                } else {
                    var e = a.xa.get(b);
                    if (e && e.Ej) {
                        mC(a);
                        var f = ++a.wh;
                        a.Za.set(f, {
                            Nh: e.Nh,
                            iq: e.fn(c),
                            persistent: b === "addEventListener"
                        });
                        a.C.postMessage(e.Ej(c, f), "*")
                    }
                }
        },
        mC = function(a) {
            a.V || (a.V = function(b) {
                try {
                    var c;
                    c = a.Oc ? a.Oc(b) : void 0;
                    if (c) {
                        var d = c.hr,
                            e = a.Za.get(d);
                        if (e) {
                            e.persistent || a.Za.delete(d);
                            var f;
                            (f = e.Nh) == null || f.call(e,
                                e.iq, c.payload)
                        }
                    }
                } catch (g) {}
            }, Zp(a.H, "message", a.V))
        };
    var oC = function(a, b) {
            var c = b.listener,
                d = (0, a.__gpp)("addEventListener", c);
            d && c(d, !0)
        },
        pC = function(a, b) {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        qC = {
            fn: function(a) {
                return a.listener
            },
            Ej: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }, c
            },
            Nh: function(a, b) {
                var c = b.__gppReturn;
                a(c.returnValue, c.success)
            }
        },
        rC = {
            fn: function(a) {
                return a.listener
            },
            Ej: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }, c
            },
            Nh: function(a, b) {
                var c = b.__gppReturn,
                    d = c.returnValue.data;
                a == null || a(d, c.success)
            }
        };

    function sC(a) {
        var b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            hr: b.__gppReturn.callId
        }
    }
    var tC = function(a, b) {
        var c;
        c = (b === void 0 ? {} : b).timeoutMs;
        dq.call(this);
        this.caller = new kC(a, "__gppLocator", function(d) {
            return typeof d.__gpp === "function"
        }, sC);
        this.caller.wb.set("addEventListener", oC);
        this.caller.xa.set("addEventListener", qC);
        this.caller.wb.set("removeEventListener", pC);
        this.caller.xa.set("removeEventListener", rC);
        this.timeoutMs = c != null ? c : 500
    };
    ya(tC, dq);
    tC.prototype.P = function() {
        this.caller.dispose();
        dq.prototype.P.call(this)
    };
    tC.prototype.addEventListener = function(a) {
        var b = this,
            c = Up(function() {
                a(uC, !0)
            }),
            d = this.timeoutMs === -1 ? void 0 : setTimeout(function() {
                c()
            }, this.timeoutMs);
        nC(this.caller, "addEventListener", {
            listener: function(e, f) {
                clearTimeout(d);
                try {
                    var g;
                    var h;
                    ((h = e.pingData) == null ? void 0 : h.gppVersion) === void 0 || e.pingData.gppVersion === "1" || e.pingData.gppVersion === "1.0" ? (b.removeEventListener(e.listenerId), g = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 1,
                            gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                            applicableSections: [-1]
                        }
                    }) : Array.isArray(e.pingData.applicableSections) ? g = e : (b.removeEventListener(e.listenerId), g = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 2,
                            gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                            applicableSections: [-1]
                        }
                    });
                    a(g, f)
                } catch (l) {
                    if (e == null ? 0 : e.listenerId) try {
                        b.removeEventListener(e.listenerId)
                    } catch (n) {
                        a(vC, !0);
                        return
                    }
                    a(wC, !0)
                }
            }
        })
    };
    tC.prototype.removeEventListener = function(a) {
        nC(this.caller, "removeEventListener", {
            listener: function() {},
            listenerId: a
        })
    };
    var wC = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        uC = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        vC = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function xC(a) {
        var b;
        if (!(b = a.pingData.signalStatus === "ready")) {
            var c = a.pingData.applicableSections;
            b = !c || c.length === 1 && c[0] === -1
        }
        if (b) {
            jC.gppString = a.pingData.gppString;
            var d = a.pingData.applicableSections.join(",");
            jC.C = d
        }
    }

    function yC() {
        try {
            var a = new tC(w, {
                timeoutMs: -1
            });
            lC(a.caller) && a.addEventListener(xC)
        } catch (b) {}
    };

    function zC() {
        var a = [
                ["cv", C(1)],
                ["rv", C(14)],
                ["tc", Nf.filter(function(c) {
                    return c
                }).length]
            ],
            b = dg(15);
        b && a.push(["x", b]);
        Uj() && a.push(["tag_exp", Uj()]);
        return a
    };
    var AC = {},
        BC = {};

    function CC(a) {
        var b = a.eventId,
            c = a.Vd,
            d = [],
            e = AC[b] || [];
        e.length && d.push(["hf", e.join(".")]);
        var f = BC[b] || [];
        f.length && d.push(["ht", f.join(".")]);
        c && (delete AC[b], delete BC[b]);
        return d
    };

    function DC() {
        return !1
    }

    function EC() {
        var a = {};
        return function(b, c, d) {}
    };

    function FC() {
        var a = GC;
        return function(b, c, d) {
            var e = d && d.event;
            HC(c);
            var f = Kh(b) ? void 0 : 1,
                g = new bb;
            xb(c, function(r, v) {
                var t = Id(v, void 0, f);
                t === void 0 && v !== void 0 && N(44);
                g.set(r, t)
            });
            a.Lb(jg());
            var h = {
                Pm: xg(b),
                eventId: e == null ? void 0 : e.id,
                priorityId: e !== void 0 ? e.priorityId : void 0,
                fg: e !== void 0 ? function(r) {
                    e.Rc.fg(r)
                } : void 0,
                Ib: function() {
                    return b
                },
                log: function() {},
                nq: {
                    index: d == null ? void 0 : d.index,
                    type: d == null ? void 0 : d.type,
                    name: d == null ? void 0 : d.name
                },
                rr: !!dz(b, 3),
                originalEventData: e == null ? void 0 : e.originalEventData
            };
            e && e.cachedModelValues && (h.cachedModelValues = {
                gtm: e.cachedModelValues.gtm,
                ecommerce: e.cachedModelValues.ecommerce
            });
            if (DC()) {
                var l = EC(),
                    n, p;
                h.pb = {
                    Sj: [],
                    gg: {},
                    Zb: function(r, v, t) {
                        v === 1 && (n = r);
                        v === 7 && (p = t);
                        l(r, v, t)
                    },
                    Mh: ei()
                };
                h.log = function(r) {
                    var v = Ea.apply(1, arguments);
                    n && l(n, 4, {
                        level: r,
                        source: p,
                        message: v
                    })
                }
            }
            var q = df(a, h, [b, g]);
            a.Lb();
            q instanceof Ha && (q.type === "return" ? q = q.data : q = void 0);
            return B(q, void 0, f)
        }
    }

    function HC(a) {
        var b = a.gtmOnSuccess,
            c = a.gtmOnFailure;
        pb(b) && (a.gtmOnSuccess = function() {
            Sc(b)
        });
        pb(c) && (a.gtmOnFailure = function() {
            Sc(c)
        })
    };

    function IC(a) {}
    IC.K = "internal.addAdsClickIds";

    function JC(a, b) {
        var c = this;
    }
    JC.publicName = "addConsentListener";
    var KC = !1;

    function LC(a) {
        for (var b = 0; b < a.length; ++b)
            if (KC) try {
                a[b]()
            } catch (c) {
                N(77)
            } else a[b]()
    }

    function MC(a, b, c) {
        var d = this,
            e;
        return e
    }
    MC.K = "internal.addDataLayerEventListener";

    function NC(a, b, c) {}
    NC.publicName = "addDocumentEventListener";

    function OC(a, b, c, d) {}
    OC.publicName = "addElementEventListener";

    function PC(a) {
        return a.J.nb()
    };

    function QC(a) {}
    QC.publicName = "addEventCallback";

    function eD(a) {}
    eD.K = "internal.addFormAbandonmentListener";

    function fD(a, b, c, d) {}
    fD.K = "internal.addFormData";
    var gD = {},
        hD = [],
        iD = {},
        jD = 0,
        kD = 0;

    function rD(a, b) {}
    rD.K = "internal.addFormInteractionListener";

    function yD(a, b) {}
    yD.K = "internal.addFormSubmitListener";

    function DD(a) {}
    DD.K = "internal.addGaSendListener";

    function ED(a) {
        if (!a) return {};
        var b = a.nq;
        return cz(b.type, b.index, b.name)
    }

    function FD(a) {
        return a ? {
            originatingEntity: ED(a)
        } : {}
    };

    function ND(a) {
        var b = fo.zones;
        return b ? b.getIsAllowedFn(Fj(), a) : function() {
            return !0
        }
    }

    function OD() {
        var a = fo.zones;
        a && a.unregisterChild(Fj())
    }

    function PD() {
        Pz(Ej(), function(a) {
            var b = a.originalEventData["gtm.uniqueEventId"],
                c = fo.zones;
            return c ? c.isActive(Fj(), b) : !0
        });
        Nz(Ej(), function(a) {
            var b, c;
            b = a.entityId;
            c = a.securityGroups;
            return ND(Number(a.originalEventData["gtm.uniqueEventId"]))(b, c)
        })
    };
    var QD = function(a, b) {
        this.tagId = a;
        this.canonicalId = b
    };

    function RD(a, b) {
        var c = this;
        return a
    }
    RD.K = "internal.loadGoogleTag";

    function SD(a) {
        return new Ad("", function(b) {
            var c = this.evaluate(b);
            if (c instanceof Ad) return new Ad("", function() {
                var d = Ea.apply(0, arguments),
                    e = this,
                    f = td(PC(this), null);
                f.eventId = a.eventId;
                f.priorityId = a.priorityId;
                f.originalEventData = a.originalEventData;
                var g = d.map(function(l) {
                        return e.evaluate(l)
                    }),
                    h = this.J.lb();
                h.Rd(f);
                return c.Jb.apply(c, [h].concat(Aa(g)))
            })
        })
    };

    function TD(a, b, c) {
        var d = this;
    }
    TD.K = "internal.addGoogleTagRestriction";
    var UD = {},
        VD = [];

    function bE(a, b) {}
    bE.K = "internal.addHistoryChangeListener";

    function cE(a, b, c) {}
    cE.publicName = "addWindowEventListener";

    function dE(a, b) {
        return !0
    }
    dE.publicName = "aliasInWindow";

    function eE(a, b, c) {}
    eE.K = "internal.appendRemoteConfigParameter";

    function fE(a) {
        var b;
        return b
    }
    fE.publicName = "callInWindow";

    function gE(a) {}
    gE.publicName = "callLater";

    function hE(a) {}
    hE.K = "callOnDomReady";

    function iE(a) {}
    iE.K = "callOnWindowLoad";

    function jE(a, b) {
        var c;
        return c
    }
    jE.K = "internal.computeGtmParameter";

    function kE(a, b) {
        var c = this;
    }
    kE.K = "internal.consentScheduleFirstTry";

    function lE(a, b) {
        var c = this;
    }
    lE.K = "internal.consentScheduleRetry";

    function mE(a) {
        var b;
        return b
    }
    mE.K = "internal.copyFromCrossContainerData";

    function nE(a, b) {
        var c;
        if (!vh(a) || !Ah(b) && b !== null && !qh(b)) throw I(this.getName(), ["string", "number|undefined"], arguments);
        J(this, "read_data_layer", a);
        c = (b || 2) !== 2 ? dp(a, 1) : fp(a, [w, A]);
        var d = Id(c, this.J, Kh(PC(this).Ib()) ? 2 : 1);
        d === void 0 && c !== void 0 && N(45);
        return d
    }
    nE.publicName = "copyFromDataLayer";

    function oE(a) {
        var b = void 0;
        return b
    }
    oE.K = "internal.copyFromDataLayerCache";

    function pE(a) {
        var b;
        return b
    }
    pE.publicName = "copyFromWindow";

    function qE(a) {
        var b = void 0;
        return Id(b, this.J, 1)
    }
    qE.K = "internal.copyKeyFromWindow";
    var rE = function(a) {
        return a === gl.aa.Qa && yl[a] === fl.Ja.De && !xn(K.m.X)
    };
    var sE = function() {
            return "0"
        },
        tE = function(a) {
            if (typeof a !== "string") return "";
            var b = ["gclid", "dclid", "wbraid", "_gl"];
            H(102) && b.push("gbraid");
            return pj(a, b, "0")
        };
    var uE = {},
        vE = {},
        wE = {},
        xE = {},
        yE = {},
        zE = {},
        AE = {},
        BE = {},
        CE = {},
        DE = {},
        EE = {},
        FE = {},
        GE = {},
        HE = {},
        IE = {},
        JE = {},
        KE = {},
        LE = {},
        ME = {},
        NE = {},
        OE = {},
        PE = {},
        QE = {},
        RE = {},
        SE = {},
        TE = {},
        UE = (TE[K.m.Na] = (uE[2] = [rE], uE), TE[K.m.Gf] = (vE[2] = [rE], vE), TE[K.m.wf] = (wE[2] = [rE], wE), TE[K.m.sl] = (xE[2] = [rE], xE), TE[K.m.tl] = (yE[2] = [rE], yE), TE[K.m.vl] = (zE[2] = [rE], zE), TE[K.m.wl] = (AE[2] = [rE], AE), TE[K.m.xl] = (BE[2] = [rE], BE), TE[K.m.Fb] = (CE[2] = [rE], CE), TE[K.m.Hf] = (DE[2] = [rE], DE), TE[K.m.If] = (EE[2] = [rE], EE), TE[K.m.Jf] = (FE[2] = [rE], FE), TE[K.m.Kf] = (GE[2] = [rE], GE), TE[K.m.Lf] = (HE[2] = [rE], HE), TE[K.m.Mf] = (IE[2] = [rE], IE), TE[K.m.Nf] = (JE[2] = [rE], JE), TE[K.m.Of] = (KE[2] = [rE], KE), TE[K.m.qb] = (LE[1] = [rE], LE), TE[K.m.hd] = (ME[1] = [rE], ME), TE[K.m.md] = (NE[1] = [rE], NE), TE[K.m.ke] = (OE[1] = [rE], OE), TE[K.m.bf] = (PE[1] = [function(a) {
            return H(102) && rE(a)
        }], PE), TE[K.m.zc] = (QE[1] = [rE], QE), TE[K.m.za] = (RE[1] = [rE], RE), TE[K.m.Ya] = (SE[1] = [rE], SE), TE),
        VE = {},
        WE = (VE[K.m.qb] = sE, VE[K.m.hd] = sE, VE[K.m.md] = sE, VE[K.m.ke] = sE, VE[K.m.bf] = sE, VE[K.m.zc] = function(a) {
            if (!sd(a)) return {};
            var b = td(a,
                null);
            delete b.match_id;
            return b
        }, VE[K.m.za] = tE, VE[K.m.Ya] = tE, VE),
        XE = {},
        YE = {},
        ZE = (YE[Q.A.Sa] = (XE[2] = [rE], XE), YE),
        $E = {};
    var aF = function(a, b, c, d) {
        this.C = a;
        this.P = b;
        this.T = c;
        this.V = d
    };
    aF.prototype.getValue = function(a) {
        a = a === void 0 ? gl.aa.Pc : a;
        if (!this.P.some(function(b) {
                return b(a)
            })) return this.T.some(function(b) {
            return b(a)
        }) ? this.V(this.C) : this.C
    };
    aF.prototype.H = function() {
        return qd(this.C) === "array" || sd(this.C) ? td(this.C, null) : this.C
    };
    var bF = function() {},
        cF = function(a, b) {
            this.conditions = a;
            this.C = b
        },
        dF = function(a, b, c) {
            var d, e = ((d = a.conditions[b]) == null ? void 0 : d[2]) || [],
                f, g = ((f = a.conditions[b]) == null ? void 0 : f[1]) || [];
            return new aF(c, e, g, a.C[b] || bF)
        },
        eF, fF;
    var gF, hF = !1;

    function iF() {
        hF = !0;
        cg(52) && (gF = productSettings, productSettings = void 0);
        gF = gF || {}
    }

    function jF(a) {
        hF || iF();
        return gF[a]
    };
    var kF = function(a, b, c) {
            this.eventName = b;
            this.D = c;
            this.C = {};
            this.isAborted = !1;
            this.target = a;
            this.metadata = {};
            for (var d = c.eventMetadata || {}, e = m(Object.keys(d)), f = e.next(); !f.done; f = e.next()) {
                var g = f.value;
                S(this, g, d[g])
            }
        },
        xu = function(a, b) {
            var c, d;
            return (c = a.C[b]) == null ? void 0 : (d = c.getValue) == null ? void 0 : d.call(c, R(a, Q.A.dg))
        },
        U = function(a, b, c) {
            var d = a.C,
                e;
            c === void 0 ? e = void 0 : (eF != null || (eF = new cF(UE, WE)), e = dF(eF, b, c));
            d[b] = e
        };
    kF.prototype.mergeHitDataForKey = function(a, b) {
        var c, d, e;
        c = (d = this.C[a]) == null ? void 0 : (e = d.H) == null ? void 0 : e.call(d);
        if (!c) return U(this, a, b), !0;
        if (!sd(c)) return !1;
        U(this, a, na(Object, "assign").call(Object, c, b));
        return !0
    };
    var lF = function(a, b) {
        b = b === void 0 ? {} : b;
        for (var c = m(Object.keys(a.C)), d = c.next(); !d.done; d = c.next()) {
            var e = d.value,
                f = void 0,
                g = void 0,
                h = void 0;
            b[e] = (f = a.C[e]) == null ? void 0 : (h = (g = f).H) == null ? void 0 : h.call(g)
        }
        return b
    };
    kF.prototype.copyToHitData = function(a, b, c) {
        var d = P(this.D, a);
        d === void 0 && (d = b);
        if (qb(d) && c !== void 0 && H(92)) try {
            d = c(d)
        } catch (e) {}
        d !== void 0 && U(this, a, d)
    };
    var R = function(a, b) {
            var c = a.metadata[b];
            if (b === Q.A.dg) {
                var d;
                return c == null ? void 0 : (d = c.H) == null ? void 0 : d.call(c)
            }
            var e;
            return c == null ? void 0 : (e = c.getValue) == null ? void 0 : e.call(c, R(a, Q.A.dg))
        },
        S = function(a, b, c) {
            var d = a.metadata,
                e;
            c === void 0 ? e = c : (fF != null || (fF = new cF(ZE, $E)), e = dF(fF, b, c));
            d[b] = e
        },
        mF = function(a, b) {
            b = b === void 0 ? {} : b;
            for (var c = m(Object.keys(a.metadata)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value,
                    f = void 0,
                    g = void 0,
                    h = void 0;
                b[e] = (f = a.metadata[e]) == null ? void 0 : (h = (g = f).H) == null ? void 0 :
                    h.call(g)
            }
            return b
        },
        Mu = function(a, b, c) {
            var d = jF(a.target.destinationId);
            return d && d[b] !== void 0 ? d[b] : c
        },
        nF = function(a) {
            for (var b = new kF(a.target, a.eventName, a.D), c = lF(a), d = m(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
                var f = e.value;
                U(b, f, c[f])
            }
            for (var g = mF(a), h = m(Object.keys(g)), l = h.next(); !l.done; l = h.next()) {
                var n = l.value;
                S(b, n, g[n])
            }
            b.isAborted = a.isAborted;
            return b
        },
        oF = function(a) {
            var b = a.D,
                c = b.eventId,
                d = b.priorityId;
            return d ? c + "_" + d : String(c)
        };
    kF.prototype.accept = function() {
        var a = Ml(Hl.Z.xi, {}),
            b = oF(this),
            c = this.target.destinationId;
        a[b] || (a[b] = {});
        a[b][c] = Ej();
        var d = Hl.Z.xi;
        if (Il(d)) {
            var e;
            (e = Jl(d)) == null || e.notify()
        }
    };
    kF.prototype.canBeAccepted = function(a) {
        var b = Ll(Hl.Z.xi);
        if (!b) return !0;
        var c = b[oF(this)];
        if (!c) return !0;
        var d = c[a != null ? a : this.target.destinationId];
        return d === void 0 || d === Ej()
    };

    function pF(a) {
        return {
            getDestinationId: function() {
                return a.target.destinationId
            },
            getEventName: function() {
                return a.eventName
            },
            setEventName: function(b) {
                a.eventName = b
            },
            getHitData: function(b) {
                return xu(a, b)
            },
            setHitData: function(b, c) {
                U(a, b, c)
            },
            setHitDataIfNotDefined: function(b, c) {
                xu(a, b) === void 0 && U(a, b, c)
            },
            copyToHitData: function(b, c) {
                a.copyToHitData(b, c)
            },
            getMetadata: function(b) {
                return R(a, b)
            },
            setMetadata: function(b, c) {
                S(a, b, c)
            },
            isAborted: function() {
                return a.isAborted
            },
            abort: function() {
                a.isAborted = !0
            },
            getFromEventContext: function(b) {
                return P(a.D, b)
            },
            mb: function() {
                return a
            },
            getHitKeys: function() {
                return Object.keys(a.C)
            },
            getMergedValues: function(b) {
                return a.D.getMergedValues(b, 3)
            },
            mergeHitDataForKey: function(b, c) {
                return sd(c) ? a.mergeHitDataForKey(b, c) : !1
            },
            accept: function() {
                a.accept()
            },
            canBeAccepted: function(b) {
                return a.canBeAccepted(b)
            }
        }
    };

    function qF(a, b) {
        var c;
        return c
    }
    qF.K = "internal.copyPreHit";

    function rF(a, b) {
        var c = null;
        return Id(c, this.J, 2)
    }
    rF.publicName = "createArgumentsQueue";

    function sF(a) {
        return Id(function(c) {
            var d = mz();
            if (typeof c === "function") d(function() {
                c(function(f, g, h) {
                    var l =
                        mz(),
                        n = l && l.getByName && l.getByName(f);
                    return (new w.gaplugins.Linker(n)).decorate(g, h)
                })
            });
            else if (Array.isArray(c)) {
                var e = String(c[0]).split(".");
                b[e.length === 1 ? e[0] : e[1]] && d.apply(null, c)
            } else if (c === "isLoaded") return !!d.loaded
        }, this.J, 1)
    }
    sF.K = "internal.createGaCommandQueue";

    function tF(a) {
        return Id(function() {
                if (!pb(e.push)) throw Error("Object at " + a + " in window is not an array.");
                e.push.apply(e, Array.prototype.slice.call(arguments, 0))
            }, this.J,
            Kh(PC(this).Ib()) ? 2 : 1)
    }
    tF.publicName = "createQueue";

    function uF(a, b) {
        var c = null;
        if (!vh(a) || !wh(b)) throw I(this.getName(), ["string", "string|undefined"], arguments);
        try {
            var d = (b || "").split("").filter(function(e) {
                return "ig".indexOf(e) >= 0
            }).join("");
            c = new Fd(new RegExp(a, d))
        } catch (e) {}
        return c
    }
    uF.K = "internal.createRegex";

    function vF(a) {}
    vF.K = "internal.declareConsentState";

    function wF(a) {
        var b = "";
        return b
    }
    wF.K = "internal.decodeUrlHtmlEntities";

    function xF(a, b, c) {
        var d;
        return d
    }
    xF.K = "internal.decorateUrlWithGaCookies";

    function yF() {}
    yF.K = "internal.deferCustomEvents";

    function zF(a) {
        return AF ? A.querySelector(a) : null
    }

    function BF(a, b) {
        if (!AF) return null;
        if (Element.prototype.closest) try {
            return a.closest(b)
        } catch (e) {
            return null
        }
        var c = Element.prototype.matches || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector,
            d = a;
        if (!A.documentElement.contains(d)) return null;
        do {
            try {
                if (c.call(d, b)) return d
            } catch (e) {
                break
            }
            d = d.parentElement || d.parentNode
        } while (d !== null && d.nodeType === 1);
        return null
    }
    var CF = !1;
    if (A.querySelectorAll) try {
        var DF = A.querySelectorAll(":root");
        DF && DF.length == 1 && DF[0] == A.documentElement && (CF = !0)
    } catch (a) {}
    var AF = CF;

    function EF() {
        var a = w.screen;
        return {
            width: a ? a.width : 0,
            height: a ? a.height : 0
        }
    }

    function FF(a) {
        if (A.hidden) return !0;
        var b = a.getBoundingClientRect();
        if (b.top === b.bottom || b.left === b.right || !w.getComputedStyle) return !0;
        var c = w.getComputedStyle(a, null);
        if (c.visibility === "hidden") return !0;
        for (var d = a, e = c; d;) {
            if (e.display === "none") return !0;
            var f = e.opacity,
                g = e.filter;
            if (g) {
                var h = g.indexOf("opacity(");
                h >= 0 && (g = g.substring(h + 8, g.indexOf(")", h)), g.charAt(g.length - 1) === "%" && (g = g.substring(0, g.length - 1)), f = String(Math.min(Number(g), Number(f))))
            }
            if (f !== void 0 && Number(f) <= 0) return !0;
            (d = d.parentElement) &&
            (e = w.getComputedStyle(d, null))
        }
        return !1
    }

    function KG(a) {
        var b;
        return b
    }
    KG.K = "internal.detectUserProvidedData";

    function PG(a, b) {
        return f
    }
    PG.K = "internal.enableAutoEventOnClick";

    function XG(a, b) {
        return p
    }
    XG.K = "internal.enableAutoEventOnElementVisibility";

    function YG() {}
    YG.K = "internal.enableAutoEventOnError";
    var ZG = {},
        $G = [],
        aH = {},
        bH = 0,
        AH = 0;

    function GH(a, b) {
        var c = this;
        return d
    }
    GH.K = "internal.enableAutoEventOnFormInteraction";

    function LH(a, b) {
        var c = this;
        return f
    }
    LH.K = "internal.enableAutoEventOnFormSubmit";

    function QH() {
        var a = this;
    }
    QH.K = "internal.enableAutoEventOnGaSend";
    var RH = {},
        SH = [];

    function ZH(a, b) {
        var c = this;
        return f
    }
    ZH.K = "internal.enableAutoEventOnHistoryChange";
    var $H = ["http://", "https://", "javascript:", "file://"];

    function dI(a, b) {
        var c = this;
        return h
    }
    dI.K = "internal.enableAutoEventOnLinkClick";
    var eI, fI;

    function qI(a, b) {
        var c = this;
        return d
    }
    qI.K = "internal.enableAutoEventOnScroll";

    function rI(a) {
        return function() {
            if (a.limit && a.Hj >= a.limit) a.Jh && w.clearInterval(a.Jh);
            else {
                a.Hj++;
                var b = Eb();
                gB({
                    event: a.eventName,
                    "gtm.timerId": a.Jh,
                    "gtm.timerEventNumber": a.Hj,
                    "gtm.timerInterval": a.interval,
                    "gtm.timerLimit": a.limit,
                    "gtm.timerStartTime": a.Bn,
                    "gtm.timerCurrentTime": b,
                    "gtm.timerElapsedTime": b - a.Bn,
                    "gtm.triggers": a.Or
                })
            }
        }
    }

    function sI(a, b) {
        return f
    }
    sI.K = "internal.enableAutoEventOnTimer";
    var tc = Ca(["data-gtm-yt-inspected-"]),
        uI = ["www.youtube.com", "www.youtube-nocookie.com"],
        vI, wI = !1;

    function GI(a, b) {
        var c = this;
        return e
    }
    GI.K = "internal.enableAutoEventOnYouTubeActivity";
    wI = !1;

    function HI(a, b) {
        if (!vh(a) || !ph(b)) throw I(this.getName(), ["string", "Object|undefined"], arguments);
        var c = b ? B(b) : {},
            d = a,
            e = !1;
        return e
    }
    HI.K = "internal.evaluateBooleanExpression";
    var II;

    function JI(a) {
        var b = !1;
        return b
    }
    JI.K = "internal.evaluateMatchingRules";
    var LI = [K.m.X, K.m.W];

    function VI(a) {
        if (H(10)) return;
        var b = bj() || cg(50) || !!bk(a.D);
        H(245) && (b = cg(50) || !!bk(a.D));
        if (b || H(168)) return;
        $x({
            Cn: H(131)
        });
    };
    var eJ = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
        fJ = /^www.googleadservices.com$/;

    function gJ(a) {
        a || (a = hJ());
        return a.Qr ? !1 : a.Fq || a.Gq || a.Iq || a.Hq || a.Me || a.Dh || a.sq || a.Xb === "aw.ds" || H(235) && a.Xb === "aw.dv" || a.xq ? !0 : !1
    }

    function hJ() {
        var a = {},
            b = Zr(!0);
        a.Qr = !!b._up;
        var c = Ct(),
            d = eu();
        a.Fq = c.aw !== void 0;
        a.Gq = c.dc !== void 0;
        a.Iq = c.wbraid !== void 0;
        a.Hq = c.gbraid !== void 0;
        a.Xb = typeof c.gclsrc === "string" ? c.gclsrc : void 0;
        a.Me = d.Me;
        a.Dh = d.Dh;
        var e = A.referrer ? ij(oj(A.referrer), "host") : "";
        a.xq = eJ.test(e);
        a.sq = fJ.test(e);
        return a
    };
    var AJ = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function BJ(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function CJ(a) {
        var b = a.google_tag_data,
            c;
        if (b != null && b.uach) {
            var d = b.uach,
                e = na(Object, "assign").call(Object, {}, d);
            d.fullVersionList && (e.fullVersionList = d.fullVersionList.slice(0));
            c = e
        } else c = null;
        return c
    }

    function DJ(a) {
        var b, c;
        return (c = (b = a.google_tag_data) == null ? void 0 : b.uach_promise) != null ? c : null
    }

    function EJ(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function FJ(a) {
        if (!EJ(a)) return null;
        var b = BJ(a);
        if (b.uach_promise) return b.uach_promise;
        var c = a.navigator.userAgentData.getHighEntropyValues(AJ).then(function(d) {
            b.uach != null || (b.uach = d);
            return d
        });
        return b.uach_promise = c
    };

    function PJ() {
        var a = w.__uspapi;
        if (pb(a)) {
            var b = "";
            try {
                a("getUSPData", 1, function(c, d) {
                    if (d && c) {
                        var e = c.uspString;
                        e && RegExp("^[\\da-zA-Z-]{1,20}$").test(e) && (b = e)
                    }
                })
            } catch (c) {}
            return b
        }
    };

    function WJ(a) {
        var b = nb("GTAG_EVENT_FEATURE_CHANNEL");
        b && (U(a, K.m.Bf, b), lb())
    };

    function FK() {
        return xq(7) && xq(9) && xq(10)
    };

    function AL(a, b, c, d) {}
    AL.K = "internal.executeEventProcessor";

    function BL(a) {
        var b;
        return Id(b, this.J, 1)
    }
    BL.K = "internal.executeJavascriptString";

    function CL(a) {
        var b;
        return b
    };

    function DL(a) {
        var b = "";
        return b
    }
    DL.K = "internal.generateClientId";

    function EL(a) {
        var b = {};
        return Id(b)
    }
    EL.K = "internal.getAdsCookieWritingOptions";

    function FL(a, b) {
        var c = !1;
        return c
    }
    FL.K = "internal.getAllowAdPersonalization";

    function GL() {
        var a;
        return a
    }
    GL.K = "internal.getAndResetEventUsage";

    function HL(a, b) {
        b = b === void 0 ? !0 : b;
        var c;
        return c
    }
    HL.K = "internal.getAuid";
    var IL = null;

    function JL() {
        var a = new bb;
        return a
    }
    JL.publicName = "getContainerVersion";

    function KL(a, b) {
        b = b === void 0 ? !0 : b;
        var c;
        return c
    }
    KL.publicName = "getCookieValues";

    function LL() {
        var a = "";
        return a
    }
    LL.K = "internal.getCorePlatformServicesParam";

    function ML() {
        return um()
    }
    ML.K = "internal.getCountryCode";

    function NL() {
        var a = [];
        return Id(a)
    }
    NL.K = "internal.getDestinationIds";

    function OL(a) {
        var b = new bb;
        return b
    }
    OL.K = "internal.getDeveloperIds";

    function PL(a) {
        var b;
        return b
    }
    PL.K = "internal.getEcsidCookieValue";

    function QL(a, b) {
        var c = null;
        return c
    }
    QL.K = "internal.getElementAttribute";

    function RL(a) {
        var b = null;
        return b
    }
    RL.K = "internal.getElementById";

    function SL(a) {
        var b = "";
        return b
    }
    SL.K = "internal.getElementInnerText";

    function TL(a, b) {
        var c = null;
        return Id(c)
    }
    TL.K = "internal.getElementProperty";

    function UL(a) {
        var b;
        return b
    }
    UL.K = "internal.getElementValue";

    function VL(a) {
        var b = 0;
        return b
    }
    VL.K = "internal.getElementVisibilityRatio";

    function WL(a) {
        var b = null;
        return b
    }
    WL.K = "internal.getElementsByCssSelector";

    function XL(a) {
        var b;
        if (!vh(a)) throw I(this.getName(), ["string"], arguments);
        J(this, "read_event_data", a);
        var c;
        a: {
            var d = a,
                e = PC(this).originalEventData;
            if (e) {
                for (var f = e, g = {}, h = {}, l = {}, n = [], p = d.split("\\\\"), q = 0; q < p.length; q++) {
                    for (var r = p[q].split("\\."), v = 0; v < r.length; v++) {
                        for (var t = r[v].split("."), u = 0; u < t.length; u++) n.push(t[u]), u !== t.length - 1 && n.push(l);
                        v !== r.length - 1 && n.push(h)
                    }
                    q !== p.length - 1 && n.push(g)
                }
                for (var x = [], y = "", z = m(n), D = z.next(); !D.done; D =
                    z.next()) {
                    var E = D.value;
                    E === l ? (x.push(y), y = "") : y = E === g ? y + "\\" : E === h ? y + "." : y + E
                }
                y && x.push(y);
                for (var L = m(x), G = L.next(); !G.done; G = L.next()) {
                    if (f == null) {
                        c = void 0;
                        break a
                    }
                    f = f[G.value]
                }
                c = f
            } else c = void 0
        }
        b = Id(c, this.J, 1);
        return b
    }
    XL.K = "internal.getEventData";

    function YL(a) {
        var b = null;
        return b
    }
    YL.K = "internal.getFirstElementByCssSelector";
    var ZL = {};
    ZL.disableUserDataWithoutCcd = H(223);
    ZL.enableDecodeUri = H(92);
    ZL.enableGaAdsConversions = H(122);
    ZL.enableGaAdsConversionsClientId = H(121);
    ZL.enableOverrideAdsCps = H(170);
    ZL.enableUrlDecodeEventUsage = H(139);

    function $L() {
        return Id(ZL)
    }
    $L.K = "internal.getFlags";

    function aM() {
        var a;
        return a
    }
    aM.K = "internal.getGsaExperimentId";

    function bM() {
        return new Fd(VB)
    }
    bM.K = "internal.getHtmlId";

    function cM(a) {
        var b;
        return b
    }
    cM.K = "internal.getIframingState";

    function dM(a, b) {
        var c = {};
        return Id(c)
    }
    dM.K = "internal.getLinkerValueFromLocation";

    function eM() {
        var a = new bb;
        return a
    }
    eM.K = "internal.getPrivacyStrings";

    function fM(a, b) {
        var c;
        return c
    }
    fM.K = "internal.getProductSettingsParameter";

    function gM(a, b) {
        var c;
        return c
    }
    gM.publicName = "getQueryParameters";

    function hM(a, b) {
        var c;
        return c
    }
    hM.publicName = "getReferrerQueryParameters";

    function iM(a) {
        var b = "";
        if (!wh(a)) throw I(this.getName(), ["string|undefined"], arguments);
        J(this, "get_referrer", a);
        b = kj(oj(A.referrer), a);
        return b
    }
    iM.publicName = "getReferrerUrl";

    function jM() {
        return vm()
    }
    jM.K = "internal.getRegionCode";

    function kM(a, b) {
        var c;
        return c
    }
    kM.K = "internal.getRemoteConfigParameter";

    function lM() {
        var a = new bb;
        a.set("width", 0);
        a.set("height", 0);
        return a
    }
    lM.K = "internal.getScreenDimensions";

    function mM() {
        var a = "";
        return a
    }
    mM.K = "internal.getTopSameDomainUrl";

    function nM() {
        var a = "";
        return a
    }
    nM.K = "internal.getTopWindowUrl";

    function oM(a) {
        var b = "";
        if (!wh(a)) throw I(this.getName(), ["string|undefined"], arguments);
        J(this, "get_url", a);
        b = ij(oj(w.location.href), a);
        return b
    }
    oM.publicName = "getUrl";

    function pM() {
        J(this, "get_user_agent");
        return zc.userAgent
    }
    pM.K = "internal.getUserAgent";

    function qM() {
        var a;
        return a ? Id(GJ(a)) : a
    }
    qM.K = "internal.getUserAgentClientHints";

    function xM() {
        var a = w;
        return a.gaGlobal = a.gaGlobal || {}
    }

    function yM() {
        var a = xM();
        a.hid = a.hid || ub();
        return a.hid
    }

    function zM(a, b) {
        var c = xM();
        if (c.vid === void 0 || b && !c.from_cookie) c.vid = a, c.from_cookie = b
    };

    function XM(a) {
        (TI(a) || bj()) && U(a, K.m.zl, vm() || um());
        !TI(a) && bj() && U(a, K.m.Ei, "::")
    }

    function YM(a) {
        if (bj() && !TI(a) && (ym() || U(a, K.m.fl, !0), H(78))) {
            Hu(a);
            Iu(a, eo.Qf.Tn, Rm(P(a.D, K.m.Wa)));
            var b = eo.Qf.Un;
            var c = P(a.D, K.m.xc);
            Iu(a, b, c === !0 ? 1 : c === !1 ? 0 : void 0);
            Iu(a, eo.Qf.Sn, Rm(P(a.D, K.m.Cb)));
            Iu(a, eo.Qf.Qn, Dr(Qm(P(a.D, K.m.sb)), Qm(P(a.D, K.m.Qb))))
        }
    };
    var sN = {
        AW: Hl.Z.In,
        G: Hl.Z.ep,
        DC: Hl.Z.Zo
    };

    function tN(a) {
        var b = Uv(a);
        return "" + Vh(b.map(function(c) {
            return c.value
        }).join("!"))
    }

    function uN(a) {
        var b = oo(a);
        return b && sN[b.prefix]
    }

    function vN(a, b) {
        var c = a[b];
        c && (c.clearTimerId && w.clearTimeout(c.clearTimerId), c.clearTimerId = w.setTimeout(function() {
            delete a[b]
        }, 36E5))
    };
    var aO = function(a) {
        for (var b = {}, c = String($N.cookie).split(";"), d = 0; d < c.length; d++) {
            var e = c[d].split("="),
                f = e[0].trim();
            if (f && a(f)) {
                var g = e.slice(1).join("=").trim();
                g && (g = decodeURIComponent(g));
                var h = void 0,
                    l = void 0;
                ((h = b)[l = f] || (h[l] = [])).push(g)
            }
        }
        return b
    };
    var bO = window,
        $N = document,
        cO = function(a) {
            var b = bO._gaUserPrefs;
            if (b && b.ioo && b.ioo() || $N.documentElement.hasAttribute("data-google-analytics-opt-out") || a && bO["ga-disable-" + a] === !0) return !0;
            try {
                var c = bO.external;
                if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0
            } catch (f) {}
            for (var d = aO(function(f) {
                    return f === "AMP_TOKEN"
                }).AMP_TOKEN || [], e = 0; e < d.length; e++)
                if (d[e] == "$OPT_OUT") return !0;
            return $N.getElementById("__gaOptOutExtension") ? !0 : !1
        };
    var dO = "gclid dclid gclsrc wbraid gbraid gad_source gad_campaignid utm_source utm_medium utm_campaign utm_term utm_content utm_id".split(" ");

    function eO() {
        var a = A.location,
            b, c = a == null ? void 0 : (b = a.search) == null ? void 0 : b.replace("?", ""),
            d;
        if (c) {
            for (var e = [], f = gj(c, !0), g = m(dO), h = g.next(); !h.done; h = g.next()) {
                var l = h.value,
                    n = f[l];
                if (n)
                    for (var p = 0; p < n.length; p++) {
                        var q = n[p];
                        q !== void 0 && e.push({
                            name: l,
                            value: q
                        })
                    }
            }
            d = e
        } else d = [];
        return d
    };

    function pO(a) {
        xb(a, function(c) {
            c.charAt(0) === "_" && delete a[c]
        });
        var b = a[K.m.Tb] || {};
        xb(b, function(c) {
            c.charAt(0) === "_" && delete b[c]
        })
    };

    function VO(a, b) {}

    function WO(a, b) {
        var c = function() {};
        return c
    }

    function XO(a, b, c) {}
    var YO = Jg.O.xk,
        ZO = Jg.O.yk;

    function $O(a, b) {
        if (H(240)) {
            var c = Cj();
            c && c.indexOf(b) > -1 && (a[Q.A.nh] = !0)
        }
    }

    function bP(a, b, c) {
        var d = this;
    }
    bP.K = "internal.gtagConfig";

    function cP(a, b, c) {
        var d = this;
    }
    cP.K = "internal.gtagDestinationConfig";

    function eP(a, b) {}
    eP.publicName = "gtagSet";

    function fP() {
        var a = {};
        return a
    };

    function gP(a) {}
    gP.K = "internal.initializeServiceWorker";

    function hP(a, b) {}
    hP.publicName = "injectHiddenIframe";
    var iP = function() {
        var a = 0;
        return function(b) {
            switch (b) {
                case 1:
                    a |= 1;
                    break;
                case 2:
                    a |= 2;
                    break;
                case 3:
                    a |= 4
            }
            return a
        }
    }();

    function jP(a, b, c, d, e) {}
    jP.K = "internal.injectHtml";
    var nP = {};

    function pP(a, b, c, d) {}
    var qP = {
            dl: 1,
            id: 1
        },
        rP = {};

    function sP(a, b, c, d) {}
    H(160) ? sP.publicName = "injectScript" : pP.publicName = "injectScript";
    sP.K = "internal.injectScript";

    function tP() {
        var a = !1;
        return a
    }
    tP.K = "internal.isAutoPiiEligible";

    function uP(a) {
        var b = !0;
        return b
    }
    uP.publicName = "isConsentGranted";

    function vP(a) {
        var b = !1;
        return b
    }
    vP.K = "internal.isDebugMode";

    function wP() {
        return xm()
    }
    wP.K = "internal.isDmaRegion";

    function xP(a) {
        var b = !1;
        return b
    }
    xP.K = "internal.isEntityInfrastructure";

    function yP(a) {
        var b = !1;
        return b
    }
    yP.K = "internal.isFeatureEnabled";

    function zP() {
        var a = !1;
        return a
    }
    zP.K = "internal.isFpfe";

    function AP() {
        var a = !1;
        return a
    }
    AP.K = "internal.isGcpConversion";

    function BP() {
        var a = !1;
        return a
    }
    BP.K = "internal.isLandingPage";

    function CP() {
        var a = !1;
        return a
    }
    CP.K = "internal.isOgt";

    function DP() {
        var a;
        return a
    }
    DP.K = "internal.isSafariPcmEligibleBrowser";

    function EP() {
        var a = $h(function(b) {
            PC(this).log("error", b)
        });
        a.publicName = "JSON";
        return a
    };

    function FP(a) {
        var b = void 0;
        if (!vh(a)) throw I(this.getName(), ["string"], arguments);
        b = oj(a);
        return Id(b)
    }
    FP.K = "internal.legacyParseUrl";

    function GP() {
        return !1
    }
    var HP = {
        getItem: function(a) {
            var b = null;
            return b
        },
        setItem: function(a, b) {
            return !1
        },
        removeItem: function(a) {}
    };

    function IP() {}
    IP.publicName = "logToConsole";

    function JP(a, b) {}
    JP.K = "internal.mergeRemoteConfig";

    function KP(a, b, c) {
        c = c === void 0 ? !0 : c;
        var d = [];
        return Id(d)
    }
    KP.K = "internal.parseCookieValuesFromString";

    function LP(a) {
        var b = void 0;
        if (typeof a !== "string") return;
        a && Jb(a, "//") && (a = A.location.protocol + a);
        if (typeof URL === "function") {
            var c;
            a: {
                var d;
                try {
                    d = new URL(a)
                } catch (x) {
                    c = void 0;
                    break a
                }
                for (var e = {}, f = Array.from(d.searchParams), g = 0; g < f.length; g++) {
                    var h = f[g][0],
                        l = f[g][1];
                    e.hasOwnProperty(h) ? typeof e[h] === "string" ? e[h] = [e[h], l] : e[h].push(l) : e[h] = l
                }
                c = Id({
                    href: d.href,
                    origin: d.origin,
                    protocol: d.protocol,
                    username: d.username,
                    password: d.password,
                    host: d.host,
                    hostname: d.hostname,
                    port: d.port,
                    pathname: d.pathname,
                    search: d.search,
                    searchParams: e,
                    hash: d.hash
                })
            }
            return c
        }
        var n;
        try {
            n = oj(a)
        } catch (x) {
            return
        }
        if (!n.protocol || !n.host) return;
        var p = {};
        if (n.search)
            for (var q = n.search.replace("?", "").split("&"), r = 0; r < q.length; r++) {
                var v = q[r].split("="),
                    t = v[0],
                    u = hj(v.splice(1).join("=")) || "";
                u = u.replace(/\+/g, " ");
                p.hasOwnProperty(t) ? typeof p[t] === "string" ? p[t] = [p[t], u] : p[t].push(u) : p[t] = u
            }
        n.searchParams = p;
        n.origin = n.protocol + "//" + n.host;
        n.username = "";
        n.password = "";
        b = Id(n);
        return b
    }
    LP.publicName = "parseUrl";

    function MP(a) {}
    MP.K = "internal.processAsNewEvent";

    function NP(a, b, c) {
        var d;
        return d
    }
    NP.K = "internal.pushToDataLayer";

    function OP(a) {
        var b = Ea.apply(1, arguments),
            c = !1;
        return c
    }
    OP.publicName = "queryPermission";

    function PP(a) {
        var b = this;
    }
    PP.K = "internal.queueAdsTransmission";

    function QP(a) {
        var b = void 0;
        return b
    }
    QP.publicName = "readAnalyticsStorage";

    function RP() {
        var a = "";
        return a
    }
    RP.publicName = "readCharacterSet";

    function SP() {
        return C(19)
    }
    SP.K = "internal.readDataLayerName";

    function TP() {
        var a = "";
        return a
    }
    TP.publicName = "readTitle";

    function UP(a, b) {
        var c = this;
    }
    UP.K = "internal.registerCcdCallback";

    function VP(a, b) {
        return !0
    }
    VP.K = "internal.registerDestination";
    var WP = ["config", "event", "get", "set"];

    function XP(a, b, c) {}
    XP.K = "internal.registerGtagCommandListener";

    function YP(a, b) {
        var c = !1;
        return c
    }
    YP.K = "internal.removeDataLayerEventListener";

    function ZP(a, b) {}
    ZP.K = "internal.removeFormData";

    function $P() {}
    $P.publicName = "resetDataLayer";

    function aQ(a, b, c) {
        var d = void 0;
        return d
    }
    aQ.K = "internal.scrubUrlParams";

    function bQ(a) {}
    bQ.K = "internal.sendAdsHit";

    function cQ(a, b, c, d) {}
    cQ.K = "internal.sendGtagEvent";

    function dQ(a, b, c) {}
    dQ.publicName = "sendPixel";

    function eQ(a, b) {}
    eQ.K = "internal.setAnchorHref";

    function fQ(a) {}
    fQ.K = "internal.setContainerConsentDefaults";

    function gQ(a, b, c, d) {
        var e = this;
        d = d === void 0 ? !0 : d;
        var f = !1;
        return f
    }
    gQ.publicName = "setCookie";

    function hQ(a) {}
    hQ.K = "internal.setCorePlatformServices";

    function iQ(a, b) {}
    iQ.K = "internal.setDataLayerValue";

    function jQ(a) {}
    jQ.publicName = "setDefaultConsentState";

    function kQ(a, b) {}
    kQ.K = "internal.setDelegatedConsentType";

    function lQ(a, b) {}
    lQ.K = "internal.setFormAction";

    function mQ(a, b, c) {
        c = c === void 0 ? !1 : c;
    }
    mQ.K = "internal.setInCrossContainerData";

    function nQ(a, b, c) {
        return !1
    }
    nQ.publicName = "setInWindow";

    function oQ(a, b, c) {}
    oQ.K = "internal.setProductSettingsParameter";

    function pQ(a, b, c) {}
    pQ.K = "internal.setRemoteConfigParameter";

    function qQ(a, b) {}
    qQ.K = "internal.setTransmissionMode";

    function rQ(a, b, c, d) {
        var e = this;
    }
    rQ.publicName = "sha256";

    function sQ(a, b, c) {}
    sQ.K = "internal.sortRemoteConfigParameters";

    function tQ(a) {}
    tQ.K = "internal.storeAdsBraidLabels";

    function uQ(a, b) {
        var c = void 0;
        return c
    }
    uQ.K = "internal.subscribeToCrossContainerData";

    function vQ(a) {}
    vQ.K = "internal.taskSendAdsHits";
    var wQ = {},
        xQ = {};
    wQ.getItem = function(a) {
        var b = null;
        return b
    };
    wQ.setItem = function(a, b) {};
    wQ.removeItem = function(a) {};
    wQ.clear = function() {};
    wQ.publicName = "templateStorage";
    wQ.resetForTest = function() {
        for (var a = m(Object.keys(xQ)), b = a.next(); !b.done; b = a.next()) delete xQ[b.value]
    };

    function yQ(a, b) {
        var c = !1;
        return c
    }
    yQ.K = "internal.testRegex";

    function zQ(a) {
        var b;
        return b
    };

    function AQ(a, b) {}
    AQ.K = "internal.trackUsage";

    function BQ(a, b) {
        var c;
        return c
    }
    BQ.K = "internal.unsubscribeFromCrossContainerData";

    function CQ(a) {}
    CQ.publicName = "updateConsentState";

    function DQ(a) {
        var b = !1;
        return b
    }
    DQ.K = "internal.userDataNeedsEncryption";
    var EQ;

    function FQ(a, b, c) {
        EQ = EQ || new ki;
        EQ.add(a, b, c)
    }

    function GQ(a, b) {
        var c = EQ = EQ || new ki;
        if (c.C.hasOwnProperty(a)) throw Error("Attempting to add a private function which already exists: " + a + ".");
        if (c.contains(a)) throw Error("Attempting to add a private function with an existing API name: " + a + ".");
        c.C[a] = pb(b) ? Dh(a, b) : Eh(a, b)
    }

    function HQ() {
        return function(a) {
            var b;
            var c = EQ;
            if (c.contains(a)) b = c.get(a, this);
            else {
                var d;
                if (d = c.C.hasOwnProperty(a)) {
                    var e = this.J.nb();
                    if (e) {
                        var f = !1,
                            g = e.Ib();
                        if (g) {
                            Kh(g) || (f = !0);
                        }
                        d = f
                    } else d = !0
                }
                if (d) {
                    var h = c.C.hasOwnProperty(a) ? c.C[a] : void 0;
                    b = h
                } else throw Error(a + " is not a valid API name.");
            }
            return b
        }
    };

    function IQ() {
        var a = function(c) {
                return void GQ(c.K, c)
            },
            b = function(c) {
                return void FQ(c.publicName, c)
            };
        b(JC);
        b(QC);
        b(dE);
        b(fE);
        b(gE);
        b(nE);
        b(pE);
        b(rF);
        b(EP());
        b(tF);
        b(JL);
        b(KL);
        b(gM);
        b(hM);
        b(iM);
        b(oM);
        b(eP);
        b(hP);
        b(uP);
        b(IP);
        b(LP);
        b(OP);
        b(RP);
        b(TP);
        b(dQ);
        b(gQ);
        b(jQ);
        b(nQ);
        b(rQ);
        b(wQ);
        b(CQ);
        FQ("Math", Ih());
        FQ("Object", ii);
        FQ("TestHelper", mi());
        FQ("assertApi", Fh);
        FQ("assertThat", Gh);
        FQ("decodeUri", Lh);
        FQ("decodeUriComponent", Mh);
        FQ("encodeUri", Nh);
        FQ("encodeUriComponent", Oh);
        FQ("fail", Uh);
        FQ("generateRandom",
            Xh);
        FQ("getTimestamp", Yh);
        FQ("getTimestampMillis", Yh);
        FQ("getType", Zh);
        FQ("makeInteger", ai);
        FQ("makeNumber", bi);
        FQ("makeString", ci);
        FQ("makeTableMap", di);
        FQ("mock", gi);
        FQ("mockObject", hi);
        FQ("fromBase64", CL, !("atob" in w));
        FQ("localStorage", HP, !GP());
        FQ("toBase64", zQ, !("btoa" in w));
        a(IC);
        a(MC);
        a(fD);
        a(rD);
        a(yD);
        a(DD);
        a(TD);
        a(bE);
        a(eE);
        a(hE);
        a(iE);
        a(jE);
        a(kE);
        a(lE);
        a(mE);
        a(oE);
        a(qE);
        a(qF);
        a(sF);
        a(uF);
        a(vF);
        a(wF);
        a(xF);
        a(yF);
        a(KG);
        a(PG);
        a(XG);
        a(YG);
        a(GH);
        a(LH);
        a(QH);
        a(ZH);
        a(dI);
        a(qI);
        a(sI);
        a(GI);
        a(HI);
        a(JI);
        a(AL);
        a(BL);
        a(DL);
        a(EL);
        a(FL);
        a(GL);
        a(HL);
        a(ML);
        a(NL);
        a(OL);
        a(PL);
        a(QL);
        a(RL);
        a(SL);
        a(TL);
        a(UL);
        a(VL);
        a(WL);
        a(XL);
        a(YL);
        a($L);
        a(aM);
        a(bM);
        a(cM);
        a(dM);
        a(eM);
        a(fM);
        a(jM);
        a(kM);
        a(lM);
        a(mM);
        a(nM);
        a(qM);
        a(bP);
        a(cP);
        a(gP);
        a(jP);
        a(sP);
        a(tP);
        a(vP);
        a(wP);
        a(xP);
        a(yP);
        a(zP);
        a(AP);
        a(BP);
        a(CP);
        a(DP);
        a(FP);
        a(RD);
        a(JP);
        a(KP);
        a(MP);
        a(NP);
        a(PP);
        a(SP);
        a(UP);
        a(VP);
        a(XP);
        a(YP);
        a(ZP);
        a(aQ);
        a(bQ);
        a(cQ);
        a(eQ);
        a(fQ);
        a(hQ);
        a(iQ);
        a(kQ);
        a(lQ);
        a(mQ);
        a(oQ);
        a(pQ);
        a(qQ);
        a(sQ);
        a(tQ);
        a(uQ);
        a(vQ);
        a(yQ);
        a(AQ);
        a(BQ);
        a(DQ);
        GQ("internal.IframingStateSchema",
            fP());
        GQ("internal.quickHash", Wh);
        H(104) && a(LL);
        H(160) ? b(sP) : b(pP);
        H(177) && b(QP);
        return HQ()
    };
    var GC;

    function JQ() {
        var a = data.sandboxed_scripts,
            b = data.security_groups;
        a: {
            var c = data.runtime || [],
                d = data.runtime_lines;GC = new bf;KQ();Jf = FC();
            var e = GC,
                f = IQ(),
                g = new Bd("require", f);g.Ta();e.C.C.set("require", g);Xa.set("require", g);
            for (var h = [], l = 0; l < c.length; l++) {
                var n = c[l];
                if (!Array.isArray(n) || n.length < 3) {
                    if (n.length === 0) continue;
                    break a
                }
                d && d[l] && d[l].length && ig(n, d[l]);
                try {
                    GC.execute(n), H(120) && ik && n[0] === 50 && h.push(n[1])
                } catch (r) {}
            }
            H(120) && (Wf = h)
        }
        if (a && a.length)
            for (var p = 0; p < a.length; p++) {
                var q = a[p].replace(/^_*/,
                    "");
                Zi[q] = ["sandboxedScripts"]
            }
        LQ(b)
    }

    function KQ() {
        GC.Yc(function(a, b, c) {
            fo.SANDBOXED_JS_SEMAPHORE = fo.SANDBOXED_JS_SEMAPHORE || 0;
            fo.SANDBOXED_JS_SEMAPHORE++;
            try {
                return a.apply(b, c)
            } finally {
                fo.SANDBOXED_JS_SEMAPHORE--
            }
        })
    }

    function LQ(a) {
        a && xb(a, function(b, c) {
            for (var d = 0; d < c.length; d++) {
                var e = c[d].replace(/^_*/, "");
                Zi[e] = Zi[e] || [];
                Zi[e].push(b)
            }
        })
    };

    function MQ(a) {
        xA(sA("developer_id." + a, !0), 0, {})
    };
    var NQ = Array.isArray;

    function OQ(a, b) {
        return td(a, b || null)
    }

    function X(a) {
        return window.encodeURIComponent(a)
    }

    function PQ(a, b, c) {
        Pc(a, b, c)
    }

    function QQ(a) {
        var b = ["veinteractive.com", "ve-interactive.cn"];
        if (!a) return !1;
        var c = ij(oj(a), "host");
        if (!c) return !1;
        for (var d = 0; b && d < b.length; d++) {
            var e = b[d] && b[d].toLowerCase();
            if (e) {
                var f = c.length - e.length;
                f > 0 && e.charAt(0) !== "." && (f--, e = "." + e);
                if (f >= 0 && c.indexOf(e, f) === f) return !0
            }
        }
        return !1
    }

    function RQ(a, b, c) {
        for (var d = {}, e = !1, f = 0; a && f < a.length; f++) a[f] && a[f].hasOwnProperty(b) && a[f].hasOwnProperty(c) && (d[a[f][b]] = a[f][c], e = !0);
        return e ? d : null
    }

    function SQ(a, b) {
        var c = {};
        if (a)
            for (var d in a) a.hasOwnProperty(d) && (c[d] = a[d]);
        if (b) {
            var e = RQ(b, "parameter", "parameterValue");
            e && (c = OQ(e, c))
        }
        return c
    }

    function TQ(a, b, c) {
        return a === void 0 || a === c ? b : a
    }

    function UQ() {
        try {
            if (!H(243)) return null;
            var a = [],
                b;
            a: {
                try {
                    b = !!zF('script[data-requiremodule^="mage/"]');
                    break a
                } catch (g) {}
                b = !1
            }
            b && a.push("ac");
            var c;
            a: {
                try {
                    c = !!zF('script[src^="//assets.squarespace.com/"]');
                    break a
                } catch (g) {}
                c = !1
            }
            c && a.push("sqs");
            var d;
            a: {
                try {
                    d = !!zF('script[id="d-js-core"]');
                    break a
                } catch (g) {}
                d = !1
            }
            d && a.push("dud");
            var e;
            a: {
                try {
                    e = !!zF('script[src*="woocommerce"],link[href*="woocommerce"],[class|="woocommerce"]');
                    break a
                } catch (g) {}
                e = !1
            }
            e && a.push("woo");
            var f;
            a: {
                try {
                    f = !!zF('meta[content*="fourthwall"],script[src*="fourthwall"],link[href*="fourthwall"]');
                    break a
                } catch (g) {}
                f = !1
            }
            f && a.push("fw");
            if (a.length > 0) return {
                plf: a.join(".")
            }
        } catch (g) {}
        return null
    };

    function VQ(a, b, c) {
        return Lc(a, b, c, void 0)
    }

    function WQ(a, b) {
        return dp(a, b || 2)
    }

    function XQ(a, b) {
        w[a] = b
    }

    function YQ(a, b, c) {
        var d = w;
        b && (d[a] === void 0 || c && !d[a]) && (d[a] = b);
        return d[a]
    }
    var ZQ = {};
    var Y = {
        securityGroups: {}
    };

    Y.securityGroups.get_referrer = ["google"],
        function() {
            function a(b, c, d) {
                return {
                    component: c,
                    queryKey: d
                }
            }(function(b) {
                Y.__get_referrer = b;
                Y.__get_referrer.F = "get_referrer";
                Y.__get_referrer.isVendorTemplate = !0;
                Y.__get_referrer.priorityOverride = 0;
                Y.__get_referrer.isInfrastructure = !1;
                Y.__get_referrer["5"] = !1
            })(function(b) {
                var c = b.vtp_urlParts === "any" ? null : [];
                c && (b.vtp_protocol && c.push("protocol"), b.vtp_host && c.push("host"), b.vtp_port && c.push("port"), b.vtp_path && c.push("path"), b.vtp_extension && c.push("extension"),
                    b.vtp_query && c.push("query"));
                var d = c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g, h) {
                        if (g) {
                            if (!qb(g)) throw e(f, {}, "URL component must be a string.");
                            if (c && c.indexOf(g) < 0) throw e(f, {}, "Prohibited URL component: " + g);
                            if (g === "query" && d) {
                                if (!h) throw e(f, {}, "Prohibited from getting entire URL query when query keys are specified.");
                                if (!qb(h)) throw e(f, {}, "Query key must be a string.");
                                if (d.indexOf(h) < 0) throw e(f, {}, "Prohibited query key: " +
                                    h);
                            }
                        } else if (c) throw e(f, {}, "Prohibited from getting entire URL when components are specified.");
                    },
                    U: a
                }
            })
        }();
    Y.securityGroups.read_event_data = ["google"],
        function() {
            function a(b, c) {
                return {
                    key: c
                }
            }(function(b) {
                Y.__read_event_data = b;
                Y.__read_event_data.F = "read_event_data";
                Y.__read_event_data.isVendorTemplate = !0;
                Y.__read_event_data.priorityOverride = 0;
                Y.__read_event_data.isInfrastructure = !1;
                Y.__read_event_data["5"] = !1
            })(function(b) {
                var c = b.vtp_eventDataAccess,
                    d = b.vtp_keyPatterns || [],
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g) {
                        if (g != null && !qb(g)) throw e(f, {
                            key: g
                        }, "Key must be a string.");
                        if (c !== "any") {
                            try {
                                if (c ===
                                    "specific" && g != null && Tg(g, d)) return
                            } catch (h) {
                                throw e(f, {
                                    key: g
                                }, "Invalid key filter.");
                            }
                            throw e(f, {
                                key: g
                            }, "Prohibited read from event data.");
                        }
                    },
                    U: a
                }
            })
        }();


    Y.securityGroups.read_data_layer = ["google"],
        function() {
            function a(b, c) {
                return {
                    key: c
                }
            }(function(b) {
                Y.__read_data_layer = b;
                Y.__read_data_layer.F = "read_data_layer";
                Y.__read_data_layer.isVendorTemplate = !0;
                Y.__read_data_layer.priorityOverride = 0;
                Y.__read_data_layer.isInfrastructure = !1;
                Y.__read_data_layer["5"] = !1
            })(function(b) {
                var c = b.vtp_allowedKeys || "specific",
                    d = b.vtp_keyPatterns || [],
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g) {
                        if (!qb(g)) throw e(f, {}, "Keys must be strings.");
                        if (c !== "any") {
                            try {
                                if (Tg(g,
                                        d)) return
                            } catch (h) {
                                throw e(f, {}, "Invalid key filter.");
                            }
                            throw e(f, {}, "Prohibited read from data layer variable: " + g + ".");
                        }
                    },
                    U: a
                }
            })
        }();








    Y.securityGroups.get_url = ["google"],
        function() {
            function a(b, c, d) {
                return {
                    component: c,
                    queryKey: d
                }
            }(function(b) {
                Y.__get_url = b;
                Y.__get_url.F = "get_url";
                Y.__get_url.isVendorTemplate = !0;
                Y.__get_url.priorityOverride = 0;
                Y.__get_url.isInfrastructure = !1;
                Y.__get_url["5"] = !1
            })(function(b) {
                var c = b.vtp_urlParts === "any" ? null : [];
                c && (b.vtp_protocol && c.push("protocol"), b.vtp_host && c.push("host"), b.vtp_port && c.push("port"), b.vtp_path && c.push("path"), b.vtp_extension && c.push("extension"), b.vtp_query && c.push("query"), b.vtp_fragment &&
                    c.push("fragment"));
                var d = c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g, h) {
                        if (g) {
                            if (!qb(g)) throw e(f, {}, "URL component must be a string.");
                            if (c && c.indexOf(g) < 0) throw e(f, {}, "Prohibited URL component: " + g);
                            if (g === "query" && d) {
                                if (!h) throw e(f, {}, "Prohibited from getting entire URL query when query keys are specified.");
                                if (!qb(h)) throw e(f, {}, "Query key must be a string.");
                                if (d.indexOf(h) < 0) throw e(f, {}, "Prohibited query key: " + h);
                            }
                        } else if (c) throw e(f, {}, "Prohibited from getting entire URL when components are specified.");
                    },
                    U: a
                }
            })
        }();











    var io = {
        dataLayer: ep,
        callback: function(a) {
            Yi.hasOwnProperty(a) && pb(Yi[a]) && Yi[a]();
            delete Yi[a]
        },
        bootstrap: 0
    };

    function $Q() {
        ho();
        Lj();
        Ry();
        Hb(Zi, Y.securityGroups);
        var a = Hj(Ij()),
            b, c = a == null ? void 0 : (b = a.context) == null ? void 0 : b.source;
        fn(c, a == null ? void 0 : a.parent);
        c !== 2 && c !== 4 && c !== 3 || N(142);
        Vf = {
            Yp: og
        }
    }

    function rm() {
        try {
            if (cg(47) || !Tj()) {
                Ni();
                if (H(109)) {}
                Va[7] = !0;
                var a = go("debugGroupId", function() {
                    return String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()))
                });
                on(a);
                Sn();
                yC();
                qq();
                kA();
                if (Mj()) {
                    C(5);
                    OD();
                    Oz().removeExternalRestrictions(Ej());
                } else {
                    co();
                    Tf();
                    Pf = Y;
                    Qf = gC;
                    Ex();
                    JQ();
                    $Q();
                    eC();
                    pm || (om = tm(), om["0"] && Ml(Hl.Z.Be, JSON.stringify(om)));
                    Pn();
                    nB();
                    qA();
                    VA = !1;
                    A.readyState === "complete" ? XA() : Qc(w, "load", XA);
                    jA();
                    ik && (op(Bp), w.setInterval(Ap, 864E5), op(zC), op(Bz), op(Sw), op(Ep), op(CC), op(Mz), H(120) && (op(Gz), op(Hz), op(Iz)), bC = {}, op(dC));
                    kk && (dm(), Co(), pB(), yB(), wB(), Vl("bt", String(cg(47) ? 2 : cg(50) ? 1 : 0)), Vl("ct", String(cg(47) ?
                        0 : cg(50) ? 1 : 3)), sB(), vB());
                    TB();
                    nm(1);
                    PD();
                    Xi = Eb();
                    io.bootstrap = Xi;
                    cg(51) && mB();
                    H(109) && nx();
                    H(134) && (typeof w.name === "string" && Jb(w.name, "web-pixel-sandbox-CUSTOM") && id() ? MQ("dMDg0Yz") : w.Shopify && (MQ("dN2ZkMj"), id() && MQ("dNTU0Yz")))
                }
            }
        } catch (b) {
            nm(4), xp()
        }
    }
    (function(a) {
        function b() {
            n = A.documentElement.getAttribute("data-tag-assistant-present");
            Tm(n) && (l = h.Gl)
        }

        function c() {
            l && Cc ? g(l) : a()
        }
        if (!w[C(37)]) {
            var d = !1;
            if (A.referrer) {
                var e = oj(A.referrer);
                d = kj(e, "host") === C(38)
            }
            if (!d) {
                var f = mr(C(39));
                d = !(!f.length || !f[0].length)
            }
            d && (w[C(37)] = !0, Lc(C(40)))
        }
        var g = function(t) {
                var u = "GTM",
                    x = "GTM";
                Ti && (u = "OGT", x = "GTAG");
                var y = C(23),
                    z = w[y];
                z || (z = [], w[y] = z, Lc("https://" + C(3) + "/debug/bootstrap?id=" + C(5) + "&src=" + x + "&cond=" + String(t) + "&gtm=" + kp()));
                var D = {
                    messageType: "CONTAINER_STARTING",
                    data: {
                        scriptSource: Cc,
                        containerProduct: u,
                        debug: !1,
                        id: C(5),
                        targetRef: {
                            ctid: C(5),
                            isDestination: Bj(),
                            canonicalId: C(6)
                        },
                        aliases: Fj(),
                        destinations: Cj()
                    }
                };
                D.data.resume = function() {
                    a()
                };
                cg(2) && (D.data.initialPublish = !0);
                z.push(D)
            },
            h = {
                jp: 1,
                Vl: 2,
                sm: 3,
                sk: 4,
                Gl: 5
            };
        h[h.jp] = "GTM_DEBUG_LEGACY_PARAM";
        h[h.Vl] = "GTM_DEBUG_PARAM";
        h[h.sm] = "REFERRER";
        h[h.sk] = "COOKIE";
        h[h.Gl] = "EXTENSION_PARAM";
        var l = void 0,
            n = void 0,
            p = ij(w.location, "query", !1, void 0, "gtm_debug");
        Tm(p) && (l = h.Vl);
        if (!l && A.referrer) {
            var q = oj(A.referrer);
            kj(q,
                "host") === C(24) && (l = h.sm)
        }
        if (!l) {
            var r = mr("__TAG_ASSISTANT");
            r.length && r[0].length && (l = h.sk)
        }
        l || b();
        if (!l && Sm(n)) {
            var v = !1;
            Qc(A, "TADebugSignal", function() {
                v || (v = !0, b(), c())
            }, !1);
            w.setTimeout(function() {
                v || (v = !0, b(), c())
            }, 200)
        } else c()
    })(function() {
        !cg(47) || tm()["0"] ? rm() : qm()
    });

})()